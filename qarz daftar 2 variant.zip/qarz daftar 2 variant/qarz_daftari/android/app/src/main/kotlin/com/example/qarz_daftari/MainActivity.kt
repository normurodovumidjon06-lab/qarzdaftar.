package com.example.qarz_daftari

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
