# Qarz Daftari Backend

Enterprise Debt Management CRM & Automated Collection System Backend

## Features

- **Secure Authentication**: JWT with Access/Refresh tokens
- **Automated Collection**: 7-day pipeline with SMS & FCM notifications
- **Role-Based Access**: Super Admin & Client roles
- **Audit Logging**: Complete audit trail for security
- **Rate Limiting**: Protection against abuse
- **Background Processing**: Automated debt collection via cron jobs

## Tech Stack

- **Framework**: NestJS (TypeScript)
- **Database**: PostgreSQL with Prisma ORM
- **Security**: JWT, Argon2 hashing, Helmet, Rate Limiting
- **Notifications**: Firebase Cloud Messaging, SMS Gateway
- **Scheduling**: Cron jobs for automated collection

## Installation

```bash
# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Run database migrations
npx prisma db push

# Start development server
npm run start:dev
```

## Environment Variables

See `.env.example` for required environment variables:

- `DATABASE_URL`: PostgreSQL connection string
- `JWT_*`: JWT configuration
- `FIREBASE_*`: Firebase Admin SDK configuration
- `SMS_*`: SMS gateway configuration

## API Documentation

The API follows RESTful conventions with the following main endpoints:

- `/auth` - Authentication endpoints
- `/users` - User management
- `/debts` - Debt management
- `/admin` - Admin dashboard endpoints

## Security Features

- Password hashing with Argon2
- JWT with short-lived access tokens
- Refresh token rotation
- Rate limiting on all endpoints
- SQL injection prevention via Prisma
- XSS protection with Helmet
- Audit logging for all admin actions

## Automated Collection Pipeline

The system runs automated collection checks daily at 8:00 AM:

1. Queries debts due in exactly 7 days
2. Sends SMS notifications via Eskiz.uz
3. Sends FCM high-priority messages to client devices
4. Triggers "Hardware Shock" on client devices

## Development

```bash
# Run in development mode
npm run start:dev

# Run tests
npm run test

# Build for production
npm run build

# Start production server
npm run start:prod
```
