import { Module } from '@nestjs/common';
import { DebtController } from './debt.controller';
import { DebtService } from './debt.service';
import { NotificationModule } from '../services/notification.module';
import { AuditModule } from '../common/audit/audit.module';

@Module({
  imports: [NotificationModule, AuditModule],
  controllers: [DebtController],
  providers: [DebtService],
  exports: [DebtService],
})
export class DebtModule {}
