import { IsString, IsNotEmpty, IsArray, IsNumber, IsDateString, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class DebtItemDto {
  @ApiProperty({
    description: 'Item name',
    example: 'iPhone 13 Pro',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'Item quantity',
    example: 1,
  })
  @IsNumber()
  @Min(1)
  quantity: number;

  @ApiProperty({
    description: 'Item price',
    example: 999.99,
  })
  @IsNumber()
  @Min(0)
  price: number;
}

export class CreateDebtDto {
  @ApiProperty({
    description: 'Client ID',
    example: 'client-id-here',
  })
  @IsString()
  @IsNotEmpty()
  clientId: string;

  @ApiProperty({
    description: 'List of debt items',
    type: [DebtItemDto],
  })
  @IsArray()
  @IsNotEmpty()
  items: DebtItemDto[];

  @ApiProperty({
    description: 'Total debt amount',
    example: 1500.00,
  })
  @IsNumber()
  @Min(0.01)
  totalAmount: number;

  @ApiProperty({
    description: 'Date when debt was issued',
    example: '2024-01-15',
  })
  @IsDateString()
  dateIssued: string;

  @ApiProperty({
    description: 'Due date for debt payment',
    example: '2024-02-15',
  })
  @IsDateString()
  dueDate: string;
}
