import { IsString, IsArray, IsNumber, IsDateString, IsOptional, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { DebtItemDto } from './create-debt.dto';
import { DebtStatus } from '@prisma/client';

export class UpdateDebtDto {
  @ApiProperty({
    description: 'Client ID',
    example: 'client-id-here',
    required: false,
  })
  @IsString()
  @IsOptional()
  clientId?: string;

  @ApiProperty({
    description: 'List of debt items',
    type: [DebtItemDto],
    required: false,
  })
  @IsArray()
  @IsOptional()
  items?: DebtItemDto[];

  @ApiProperty({
    description: 'Total debt amount',
    example: 1500.00,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  @Min(0.01)
  totalAmount?: number;

  @ApiProperty({
    description: 'Date when debt was issued',
    example: '2024-01-15',
    required: false,
  })
  @IsDateString()
  @IsOptional()
  dateIssued?: string;

  @ApiProperty({
    description: 'Due date for debt payment',
    example: '2024-02-15',
    required: false,
  })
  @IsDateString()
  @IsOptional()
  dueDate?: string;

  @ApiProperty({
    description: 'Debt status',
    enum: DebtStatus,
    required: false,
  })
  @IsOptional()
  status?: DebtStatus;
}
