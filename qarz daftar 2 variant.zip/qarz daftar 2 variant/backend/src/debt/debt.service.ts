import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../config/prisma.service';
import { CreateDebtDto } from './dto/create-debt.dto';
import { UpdateDebtDto } from './dto/update-debt.dto';
import { DebtStatus, UserRole } from '@prisma/client';
import { AuditService } from '../common/audit/audit.service';
import { NotificationService } from '../services/notification.service';

@Injectable()
export class DebtService {
  constructor(
    private prisma: PrismaService,
    private auditService: AuditService,
    private notificationService: NotificationService,
  ) {}

  async create(createDebtDto: CreateDebtDto, adminId: string, request?: any) {
    const { clientId, items, totalAmount, dateIssued, dueDate } = createDebtDto;

    // Validate client exists and is active
    const client = await this.prisma.user.findUnique({
      where: { id: clientId },
      select: { id: true, fullName: true, phone: true, isActive: true },
    });

    if (!client) {
      throw new NotFoundException('Client not found');
    }

    if (!client.isActive) {
      throw new BadRequestException('Client is not active');
    }

    // Validate dates
    const issuedDate = new Date(dateIssued);
    const dueDateTime = new Date(dueDate);

    if (dueDateTime <= issuedDate) {
      throw new BadRequestException('Due date must be after issue date');
    }

    // Create debt
    const debt = await this.prisma.debt.create({
      data: {
        clientId,
        items: JSON.stringify(items),
        totalAmount,
        dateIssued: issuedDate,
        dueDate: dueDateTime,
      },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
      },
    });

    // Log the action
    await this.auditService.logAction(
      adminId,
      'CREATE_DEBT',
      'DEBT',
      debt.id,
      null,
      {
        clientId,
        items,
        totalAmount,
        dateIssued,
        dueDate,
      },
      request,
    );

    return debt;
  }

  async findAll(
    page = 1,
    limit = 50,
    clientId?: string,
    status?: DebtStatus,
    search?: string,
    dateFrom?: string,
    dateTo?: string,
  ) {
    const skip = (page - 1) * limit;
    const where: any = {};

    if (clientId) where.clientId = clientId;
    if (status) where.status = status;

    if (search) {
      where.OR = [
        { client: { fullName: { contains: search, mode: 'insensitive' } } },
        { client: { phone: { contains: search, mode: 'insensitive' } } },
        { items: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (dateFrom || dateTo) {
      where.dateIssued = {};
      if (dateFrom) where.dateIssued.gte = new Date(dateFrom);
      if (dateTo) where.dateIssued.lte = new Date(dateTo);
    }

    const [debts, total] = await Promise.all([
      this.prisma.debt.findMany({
        where,
        include: {
          client: {
            select: {
              id: true,
              fullName: true,
              phone: true,
              mahalla: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.debt.count({ where }),
    ]);

    return {
      debts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const debt = await this.prisma.debt.findUnique({
      where: { id },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            mahalla: true,
            deviceToken: true,
          },
        },
        auditLogs: {
          include: {
            user: {
              select: {
                id: true,
                fullName: true,
                role: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!debt) {
      throw new NotFoundException('Debt not found');
    }

    // Parse items JSON
    debt.items = JSON.parse(debt.items as string);

    return debt;
  }

  async update(id: string, updateDebtDto: UpdateDebtDto, adminId: string, request?: any) {
    // Get existing debt for audit
    const existingDebt = await this.prisma.debt.findUnique({
      where: { id },
      select: {
        id: true,
        clientId: true,
        items: true,
        totalAmount: true,
        dateIssued: true,
        dueDate: true,
        status: true,
      },
    });

    if (!existingDebt) {
      throw new NotFoundException('Debt not found');
    }

    // Prepare update data
    const updateData: any = { ...updateDebtDto };

    // Handle items JSON
    if (updateDebtDto.items) {
      updateData.items = JSON.stringify(updateDebtDto.items);
    }

    // Handle dates
    if (updateDebtDto.dateIssued) {
      updateData.dateIssued = new Date(updateDebtDto.dateIssued);
    }

    if (updateDebtDto.dueDate) {
      updateData.dueDate = new Date(updateDebtDto.dueDate);
    }

    // Update debt
    const debt = await this.prisma.debt.update({
      where: { id },
      data: updateData,
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
      },
    });

    // Log the action
    await this.auditService.logAction(
      adminId,
      'UPDATE_DEBT',
      'DEBT',
      id,
      {
        items: existingDebt.items,
        totalAmount: existingDebt.totalAmount,
        dateIssued: existingDebt.dateIssued,
        dueDate: existingDebt.dueDate,
        status: existingDebt.status,
      },
      updateData,
      request,
    );

    return debt;
  }

  async markAsPaid(id: string, adminId: string, request?: any) {
    const existingDebt = await this.prisma.debt.findUnique({
      where: { id },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            deviceToken: true,
          },
        },
      },
    });

    if (!existingDebt) {
      throw new NotFoundException('Debt not found');
    }

    if (existingDebt.status === DebtStatus.PAID) {
      throw new ConflictException('Debt is already marked as paid');
    }

    // Update debt status
    const debt = await this.prisma.debt.update({
      where: { id },
      data: { status: DebtStatus.PAID },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
      },
    });

    // Log the action
    await this.auditService.logAction(
      adminId,
      'MARK_PAID',
      'DEBT',
      id,
      { status: existingDebt.status },
      { status: DebtStatus.PAID },
      request,
    );

    // Send notification to client
    if (existingDebt.client.deviceToken) {
      await this.notificationService.sendPaymentConfirmation(
        existingDebt.client.deviceToken,
        existingDebt.client.fullName,
        existingDebt.totalAmount,
      );
    }

    return debt;
  }

  async markAsDefaulted(id: string, adminId: string, request?: any) {
    const existingDebt = await this.prisma.debt.findUnique({
      where: { id },
      select: { id: true, status: true },
    });

    if (!existingDebt) {
      throw new NotFoundException('Debt not found');
    }

    if (existingDebt.status === DebtStatus.DEFAULTED) {
      throw new ConflictException('Debt is already marked as defaulted');
    }

    // Update debt status
    const debt = await this.prisma.debt.update({
      where: { id },
      data: { status: DebtStatus.DEFAULTED },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
      },
    });

    // Log the action
    await this.auditService.logAction(
      adminId,
      'MARK_DEFAULTED',
      'DEBT',
      id,
      { status: existingDebt.status },
      { status: DebtStatus.DEFAULTED },
      request,
    );

    return debt;
  }

  async getDebtsByClient(clientId: string) {
    const debts = await this.prisma.debt.findMany({
      where: { clientId },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Parse items JSON for each debt
    return debts.map(debt => ({
      ...debt,
      items: JSON.parse(debt.items as string),
    }));
  }

  async getOverdueDebts() {
    const now = new Date();
    
    const debts = await this.prisma.debt.findMany({
      where: {
        dueDate: { lt: now },
        status: DebtStatus.ACTIVE,
      },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            mahalla: true,
            deviceToken: true,
          },
        },
      },
      orderBy: { dueDate: 'asc' },
    });

    // Parse items JSON for each debt
    return debts.map(debt => ({
      ...debt,
      items: JSON.parse(debt.items as string),
    }));
  }

  async getDebtsDueInDays(days: number) {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + days);
    
    const debts = await this.prisma.debt.findMany({
      where: {
        dueDate: {
          gte: new Date(),
          lte: targetDate,
        },
        status: DebtStatus.ACTIVE,
      },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            mahalla: true,
            deviceToken: true,
          },
        },
      },
      orderBy: { dueDate: 'asc' },
    });

    // Parse items JSON for each debt
    return debts.map(debt => ({
      ...debt,
      items: JSON.parse(debt.items as string),
    }));
  }

  async getStats() {
    const [
      totalDebts,
      activeDebts,
      paidDebts,
      defaultedDebts,
      overdueDebts,
      totalAmount,
      totalPaidAmount,
      totalOutstandingAmount,
    ] = await Promise.all([
      this.prisma.debt.count(),
      this.prisma.debt.count({ where: { status: DebtStatus.ACTIVE } }),
      this.prisma.debt.count({ where: { status: DebtStatus.PAID } }),
      this.prisma.debt.count({ where: { status: DebtStatus.DEFAULTED } }),
      this.prisma.debt.count({
        where: {
          dueDate: { lt: new Date() },
          status: DebtStatus.ACTIVE,
        },
      }),
      this.prisma.debt.aggregate({
        _sum: { totalAmount: true },
      }),
      this.prisma.debt.aggregate({
        where: { status: DebtStatus.PAID },
        _sum: { totalAmount: true },
      }),
      this.prisma.debt.aggregate({
        where: { status: DebtStatus.ACTIVE },
        _sum: { totalAmount: true },
      }),
    ]);

    return {
      totalDebts,
      activeDebts,
      paidDebts,
      defaultedDebts,
      overdueDebts,
      totalAmount: totalAmount._sum.totalAmount || 0,
      totalPaidAmount: totalPaidAmount._sum.totalAmount || 0,
      totalOutstandingAmount: totalOutstandingAmount._sum.totalAmount || 0,
    };
  }

  async triggerHardwareShock(debtId: string, adminId: string, request?: any) {
    const debt = await this.prisma.debt.findUnique({
      where: { id: debtId },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            deviceToken: true,
          },
        },
      },
    });

    if (!debt) {
      throw new NotFoundException('Debt not found');
    }

    if (!debt.client.deviceToken) {
      throw new BadRequestException('Client has no device token registered');
    }

    // Send hardware shock notification
    await this.notificationService.sendHardwareShock(
      debt.client.deviceToken,
      debt.client.fullName,
      debt.totalAmount,
      debt.dueDate,
    );

    // Log the action
    await this.auditService.logAction(
      adminId,
      'TRIGGER_HARDWARE_SHOCK',
      'DEBT',
      debtId,
      null,
      {
        clientId: debt.client.id,
        clientName: debt.client.fullName,
        amount: debt.totalAmount,
        dueDate: debt.dueDate,
      },
      request,
    );

    return { message: 'Hardware shock triggered successfully' };
  }
}
