import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { DebtService } from './debt.service';
import { CreateDebtDto } from './dto/create-debt.dto';
import { UpdateDebtDto } from './dto/update-debt.dto';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { RolesGuard } from '../guards/roles.guard';
import { Roles } from '../decorators/roles.decorator';
import { UserRole, DebtStatus } from '@prisma/client';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';

@ApiTags('debts')
@Controller('debts')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class DebtController {
  constructor(private readonly debtService: DebtService) {}

  @Post()
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Create a new debt' })
  @ApiResponse({ status: 201, description: 'Debt created successfully' })
  @ApiResponse({ status: 404, description: 'Client not found' })
  create(@Body() createDebtDto: CreateDebtDto, @Request() req) {
    return this.debtService.create(createDebtDto, req.user.id, req);
  }

  @Get()
  @ApiOperation({ summary: 'Get all debts with pagination and filtering' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'clientId', required: false, type: String })
  @ApiQuery({ name: 'status', required: false, enum: DebtStatus })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'dateFrom', required: false, type: String })
  @ApiQuery({ name: 'dateTo', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Debts retrieved successfully' })
  findAll(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('clientId') clientId?: string,
    @Query('status') status?: DebtStatus,
    @Query('search') search?: string,
    @Query('dateFrom') dateFrom?: string,
    @Query('dateTo') dateTo?: string,
  ) {
    return this.debtService.findAll(
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 50,
      clientId,
      status,
      search,
      dateFrom,
      dateTo,
    );
  }

  @Get('stats')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get debt statistics' })
  @ApiResponse({ status: 200, description: 'Debt statistics retrieved successfully' })
  getStats() {
    return this.debtService.getStats();
  }

  @Get('overdue')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get overdue debts' })
  @ApiResponse({ status: 200, description: 'Overdue debts retrieved successfully' })
  getOverdueDebts() {
    return this.debtService.getOverdueDebts();
  }

  @Get('due-in-7-days')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get debts due in 7 days' })
  @ApiResponse({ status: 200, description: 'Upcoming debts retrieved successfully' })
  getDebtsDueIn7Days() {
    return this.debtService.getDebtsDueInDays(7);
  }

  @Get('client/:clientId')
  @ApiOperation({ summary: 'Get debts by client' })
  @ApiResponse({ status: 200, description: 'Client debts retrieved successfully' })
  getDebtsByClient(@Param('clientId') clientId: string) {
    return this.debtService.getDebtsByClient(clientId);
  }

  @Get('my-debts')
  @Roles(UserRole.CLIENT)
  @ApiOperation({ summary: 'Get current user debts' })
  @ApiResponse({ status: 200, description: 'User debts retrieved successfully' })
  getMyDebts(@Request() req) {
    return this.debtService.getDebtsByClient(req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get debt by ID' })
  @ApiResponse({ status: 200, description: 'Debt retrieved successfully' })
  @ApiResponse({ status: 404, description: 'Debt not found' })
  findOne(@Param('id') id: string) {
    return this.debtService.findOne(id);
  }

  @Patch(':id')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Update debt' })
  @ApiResponse({ status: 200, description: 'Debt updated successfully' })
  @ApiResponse({ status: 404, description: 'Debt not found' })
  update(@Param('id') id: string, @Body() updateDebtDto: UpdateDebtDto, @Request() req) {
    return this.debtService.update(id, updateDebtDto, req.user.id, req);
  }

  @Patch(':id/mark-paid')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Mark debt as paid' })
  @ApiResponse({ status: 200, description: 'Debt marked as paid' })
  @ApiResponse({ status: 404, description: 'Debt not found' })
  @ApiResponse({ status: 409, description: 'Debt already paid' })
  markAsPaid(@Param('id') id: string, @Request() req) {
    return this.debtService.markAsPaid(id, req.user.id, req);
  }

  @Patch(':id/mark-defaulted')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Mark debt as defaulted' })
  @ApiResponse({ status: 200, description: 'Debt marked as defaulted' })
  @ApiResponse({ status: 404, description: 'Debt not found' })
  @ApiResponse({ status: 409, description: 'Debt already defaulted' })
  markAsDefaulted(@Param('id') id: string, @Request() req) {
    return this.debtService.markAsDefaulted(id, req.user.id, req);
  }

  @Post(':id/trigger-hardware-shock')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Trigger hardware shock notification' })
  @ApiResponse({ status: 200, description: 'Hardware shock triggered successfully' })
  @ApiResponse({ status: 404, description: 'Debt not found' })
  @ApiResponse({ status: 400, description: 'Client has no device token' })
  triggerHardwareShock(@Param('id') id: string, @Request() req) {
    return this.debtService.triggerHardwareShock(id, req.user.id, req);
  }
}
