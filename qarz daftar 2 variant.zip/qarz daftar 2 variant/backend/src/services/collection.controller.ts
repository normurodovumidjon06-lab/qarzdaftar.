import { Controller, Get, Post, Query, UseGuards, Request } from '@nestjs/common';
import { CollectionService } from './collection.service';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { RolesGuard } from '../guards/roles.guard';
import { Roles } from '../decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';

@ApiTags('collection')
@Controller('collection')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class CollectionController {
  constructor(private readonly collectionService: CollectionService) {}

  @Post('trigger')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Manually trigger collection pipeline' })
  @ApiQuery({ name: 'daysAhead', required: false, type: Number, example: 7 })
  @ApiResponse({ status: 200, description: 'Collection pipeline triggered successfully' })
  async triggerPipeline(@Query('daysAhead') daysAhead?: string) {
    const days = daysAhead ? parseInt(daysAhead) : 7;
    return this.collectionService.triggerCollectionPipeline(days);
  }

  @Get('stats')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get collection statistics' })
  @ApiResponse({ status: 200, description: 'Collection statistics retrieved successfully' })
  async getStats() {
    return this.collectionService.getCollectionStats();
  }
}
