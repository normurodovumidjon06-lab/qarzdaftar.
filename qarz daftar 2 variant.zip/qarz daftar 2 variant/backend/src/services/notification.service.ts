import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as admin from 'firebase-admin';
import axios from 'axios';

@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);
  private fcmInitialized = false;

  constructor(private configService: ConfigService) {
    this.initializeFirebase();
  }

  private initializeFirebase() {
    try {
      const serviceAccount = {
        projectId: this.configService.get<string>('FIREBASE_PROJECT_ID'),
        clientEmail: this.configService.get<string>('FIREBASE_CLIENT_EMAIL'),
        privateKey: this.configService.get<string>('FIREBASE_PRIVATE_KEY')?.replace(/\\n/g, '\n'),
      };

      if (serviceAccount.projectId && serviceAccount.clientEmail && serviceAccount.privateKey) {
        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
        });
        this.fcmInitialized = true;
        this.logger.log('Firebase Admin initialized successfully');
      } else {
        this.logger.warn('Firebase configuration incomplete. FCM notifications will be disabled.');
      }
    } catch (error) {
      this.logger.error('Failed to initialize Firebase Admin:', error);
    }
  }

  async sendFCMNotification(
    deviceToken: string,
    title: string,
    body: string,
    data?: Record<string, any>,
    priority: 'high' | 'normal' = 'high',
  ) {
    if (!this.fcmInitialized) {
      this.logger.warn('FCM not initialized, skipping notification');
      return { success: false, message: 'FCM not initialized' };
    }

    try {
      const message: admin.messaging.Message = {
        token: deviceToken,
        notification: {
          title,
          body,
        },
        data: data || {},
        android: {
          priority,
          notification: {
            sound: 'default',
            icon: 'ic_notification',
            color: '#FF0000',
            priority,
          },
        },
        apns: {
          payload: {
            aps: {
              sound: 'default',
              badge: 1,
              priority,
            },
          },
        },
      };

      const response = await admin.messaging().send(message);
      this.logger.log(`FCM notification sent successfully: ${response}`);
      return { success: true, messageId: response };
    } catch (error) {
      this.logger.error(`Failed to send FCM notification: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  async sendHardwareShock(
    deviceToken: string,
    clientName: string,
    amount: number,
    dueDate: Date,
  ) {
    const title = 'Qarz Daftari - Muhim Ogohlantirish!';
    const body = `${clientName}, sizning ${amount} so\'m qarzingiz muddati yaqinlashmoqda!`;

    const data = {
      type: 'HARDWARE_SHOCK',
      clientName,
      amount: amount.toString(),
      dueDate: dueDate.toISOString(),
      vibrationPattern: '1000,500,1000,500,2000',
      ttsMessage: `Hurmatli ${clientName}, iltimos qarzlaringizni to\'lab qo\'ying.`,
    };

    return this.sendFCMNotification(deviceToken, title, body, data, 'high');
  }

  async sendPaymentConfirmation(
    deviceToken: string,
    clientName: string,
    amount: number,
  ) {
    const title = 'Qarz Daftari - To\'lov Tasdiqlandi';
    const body = `${clientName}, ${amount} so\'m qarzingiz muvaffaqiyatli to\'landi!`;

    const data = {
      type: 'PAYMENT_CONFIRMATION',
      clientName,
      amount: amount.toString(),
    };

    return this.sendFCMNotification(deviceToken, title, body, data, 'normal');
  }

  async sendDebtReminder(
    deviceToken: string,
    clientName: string,
    amount: number,
    dueDate: Date,
  ) {
    const title = 'Qarz Daftari - Eslatma';
    const body = `${clientName}, ${amount} so\'m qarzingiz ${dueDate.toLocaleDateString('uz-UZ')} kuni to\'lanishi kerak.`;

    const data = {
      type: 'DEBT_REMINDER',
      clientName,
      amount: amount.toString(),
      dueDate: dueDate.toISOString(),
    };

    return this.sendFCMNotification(deviceToken, title, body, data, 'high');
  }

  async sendSMS(phone: string, message: string) {
    try {
      const smsGatewayUrl = this.configService.get<string>('SMS_GATEWAY_URL');
      const smsEmail = this.configService.get<string>('SMS_EMAIL');
      const smsPassword = this.configService.get<string>('SMS_PASSWORD');

      if (!smsGatewayUrl || !smsEmail || !smsPassword) {
        this.logger.warn('SMS gateway configuration incomplete');
        return { success: false, message: 'SMS gateway not configured' };
      }

      // First, authenticate with SMS gateway
      const authResponse = await axios.post(`${smsGatewayUrl}/auth/login`, {
        email: smsEmail,
        password: smsPassword,
      });

      const token = authResponse.data.data.token;

      // Send SMS
      const smsResponse = await axios.post(
        `${smsGatewayUrl}/message/sms/send`,
        {
          mobile_phone: phone.replace(/\D/g, ''), // Remove all non-digit characters
          message: message,
          from: '3700',
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      this.logger.log(`SMS sent successfully to ${phone}: ${smsResponse.data}`);
      return { success: true, messageId: smsResponse.data.data.id };
    } catch (error) {
      this.logger.error(`Failed to send SMS to ${phone}: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  async sendDebtSMS(phone: string, clientName: string, amount: number, dueDate: Date) {
    const message = `Hurmatli ${clientName}, sizning ${amount} so\'m qarzingizni ${dueDate.toLocaleDateString('uz-UZ')} sanasigacha to\'lashni unutmang. Qarz Daftari.`;
    return this.sendSMS(phone, message);
  }

  async sendUrgentDebtSMS(phone: string, clientName: string, amount: number, dueDate: Date) {
    const message = `URGENT: ${clientName}, sizning ${amount} so\'m qarzingiz ${dueDate.toLocaleDateString('uz-UZ')} kuni tugaydi! Darhol to\'lang. Qarz Daftari.`;
    return this.sendSMS(phone, message);
  }

  async sendPaymentConfirmationSMS(phone: string, clientName: string, amount: number) {
    const message = `${clientName}, ${amount} so\'m qarzingiz muvaffaqiyatli to\'landi. Rahmat! Qarz Daftari.`;
    return this.sendSMS(phone, message);
  }
}
