import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../config/prisma.service';
import { NotificationService } from './notification.service';
import { DebtStatus } from '@prisma/client';

@Injectable()
export class CollectionService {
  private readonly logger = new Logger(CollectionService.name);

  constructor(
    private prisma: PrismaService,
    private notificationService: NotificationService,
  ) {}

  // Run every day at 8:00 AM
  @Cron('0 8 * * *', {
    name: 'daily-collection-check',
    timeZone: 'Asia/Tashkent',
  })
  async handleDailyCollectionCheck() {
    this.logger.log('Starting daily collection check...');
    
    try {
      const stats = await this.process7DayCollectionPipeline();
      this.logger.log(`Daily collection check completed: ${JSON.stringify(stats)}`);
    } catch (error) {
      this.logger.error('Daily collection check failed:', error);
    }
  }

  // Run every 4 hours for urgent reminders
  @Cron('0 */4 * * *', {
    name: 'urgent-reminders',
    timeZone: 'Asia/Tashkent',
  })
  async handleUrgentReminders() {
    this.logger.log('Starting urgent reminders check...');
    
    try {
      const stats = await this.processUrgentReminders();
      this.logger.log(`Urgent reminders completed: ${JSON.stringify(stats)}`);
    } catch (error) {
      this.logger.error('Urgent reminders failed:', error);
    }
  }

  // Main 7-day collection pipeline
  async process7DayCollectionPipeline() {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + 7);
    
    // Set to start of day for accurate comparison
    targetDate.setHours(0, 0, 0, 0);

    const debts = await this.prisma.debt.findMany({
      where: {
        dueDate: {
          gte: targetDate,
          lt: new Date(targetDate.getTime() + 24 * 60 * 60 * 1000), // Next day
        },
        status: DebtStatus.ACTIVE,
      },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            deviceToken: true,
            isActive: true,
          },
        },
      },
    });

    this.logger.log(`Found ${debts.length} debts due in exactly 7 days`);

    let smsSent = 0;
    let fcmSent = 0;
    let errors = 0;

    // Process each debt concurrently
    const promises = debts.map(async (debt) => {
      try {
        // Skip if client is inactive
        if (!debt.client.isActive) {
          this.logger.warn(`Skipping inactive client: ${debt.client.fullName}`);
          return;
        }

        const results = await Promise.allSettled([
          // Send SMS
          this.notificationService.sendDebtSMS(
            debt.client.phone,
            debt.client.fullName,
            Number(debt.totalAmount),
            debt.dueDate,
          ),
          
          // Send FCM notification
          debt.client.deviceToken
            ? this.notificationService.sendDebtReminder(
                debt.client.deviceToken,
                debt.client.fullName,
                Number(debt.totalAmount),
                debt.dueDate,
              )
            : Promise.resolve({ success: false, message: 'No device token' }),
        ]);

        // Count successful sends
        if (results[0].status === 'fulfilled' && results[0].value.success) {
          smsSent++;
        }
        if (results[1].status === 'fulfilled' && results[1].value.success) {
          fcmSent++;
        }

        // Log any errors
        results.forEach((result, index) => {
          if (result.status === 'rejected' || !result.value.success) {
            this.logger.error(
              `Failed to send ${index === 0 ? 'SMS' : 'FCM'} to ${debt.client.fullName}:`,
              result.status === 'rejected' ? result.reason : result.value.error,
            );
            errors++;
          }
        });

        this.logger.log(
          `Processed 7-day reminder for ${debt.client.fullName} (${debt.client.phone})`,
        );
      } catch (error) {
        this.logger.error(
          `Error processing debt ${debt.id} for client ${debt.client.fullName}:`,
          error,
        );
        errors++;
      }
    });

    await Promise.all(promises);

    return {
      totalDebts: debts.length,
      smsSent,
      fcmSent,
      errors,
      processedAt: new Date().toISOString(),
    };
  }

  // Process urgent reminders for debts due in 1-3 days
  async processUrgentReminders() {
    const now = new Date();
    const startDate = new Date(now);
    startDate.setDate(startDate.getDate() + 1);
    startDate.setHours(0, 0, 0, 0);

    const endDate = new Date(now);
    endDate.setDate(endDate.getDate() + 3);
    endDate.setHours(23, 59, 59, 999);

    const debts = await this.prisma.debt.findMany({
      where: {
        dueDate: {
          gte: startDate,
          lte: endDate,
        },
        status: DebtStatus.ACTIVE,
      },
      include: {
        client: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            deviceToken: true,
            isActive: true,
          },
        },
      },
    });

    this.logger.log(`Found ${debts.length} urgent debts (1-3 days)`);

    let smsSent = 0;
    let fcmSent = 0;
    let errors = 0;

    const promises = debts.map(async (debt) => {
      try {
        if (!debt.client.isActive) return;

        const daysUntilDue = Math.ceil(
          (debt.dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24),
        );

        const results = await Promise.allSettled([
          // Send urgent SMS
          this.notificationService.sendUrgentDebtSMS(
            debt.client.phone,
            debt.client.fullName,
            Number(debt.totalAmount),
            debt.dueDate,
          ),
          
          // Send urgent FCM
          debt.client.deviceToken
            ? this.notificationService.sendHardwareShock(
                debt.client.deviceToken,
                debt.client.fullName,
                Number(debt.totalAmount),
                debt.dueDate,
              )
            : Promise.resolve({ success: false, message: 'No device token' }),
        ]);

        if (results[0].status === 'fulfilled' && results[0].value.success) {
          smsSent++;
        }
        if (results[1].status === 'fulfilled' && results[1].value.success) {
          fcmSent++;
        }

        results.forEach((result, index) => {
          if (result.status === 'rejected' || !result.value.success) {
            this.logger.error(
              `Failed to send urgent ${index === 0 ? 'SMS' : 'FCM'} to ${debt.client.fullName}:`,
              result.status === 'rejected' ? result.reason : result.value.error,
            );
            errors++;
          }
        });

        this.logger.log(
          `Processed urgent reminder (${daysUntilDue} days) for ${debt.client.fullName}`,
        );
      } catch (error) {
        this.logger.error(
          `Error processing urgent debt ${debt.id} for client ${debt.client.fullName}:`,
          error,
        );
        errors++;
      }
    });

    await Promise.all(promises);

    return {
      totalDebts: debts.length,
      smsSent,
      fcmSent,
      errors,
      processedAt: new Date().toISOString(),
    };
  }

  // Manual trigger for testing
  async triggerCollectionPipeline(daysAhead = 7) {
    this.logger.log(`Manually triggering collection pipeline for ${daysAhead} days ahead`);
    
    if (daysAhead === 7) {
      return this.process7DayCollectionPipeline();
    } else if (daysAhead >= 1 && daysAhead <= 3) {
      return this.processUrgentReminders();
    } else {
      throw new Error('Invalid daysAhead value. Use 7 for regular pipeline or 1-3 for urgent reminders.');
    }
  }

  // Get collection statistics
  async getCollectionStats() {
    const now = new Date();
    
    const [
      totalActiveDebts,
      debtsDueIn7Days,
      debtsDueIn3Days,
      overdueDebts,
      totalOutstanding,
    ] = await Promise.all([
      this.prisma.debt.count({ where: { status: DebtStatus.ACTIVE } }),
      
      this.prisma.debt.count({
        where: {
          status: DebtStatus.ACTIVE,
          dueDate: {
            gte: new Date(now.getTime() + 6 * 24 * 60 * 60 * 1000),
            lte: new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000),
          },
        },
      }),
      
      this.prisma.debt.count({
        where: {
          status: DebtStatus.ACTIVE,
          dueDate: {
            gte: new Date(now.getTime() + 24 * 60 * 60 * 1000),
            lte: new Date(now.getTime() + 4 * 24 * 60 * 60 * 1000),
          },
        },
      }),
      
      this.prisma.debt.count({
        where: {
          status: DebtStatus.ACTIVE,
          dueDate: { lt: now },
        },
      }),
      
      this.prisma.debt.aggregate({
        where: { status: DebtStatus.ACTIVE },
        _sum: { totalAmount: true },
      }),
    ]);

    return {
      totalActiveDebts,
      debtsDueIn7Days,
      debtsDueIn3Days,
      overdueDebts,
      totalOutstanding: totalOutstanding._sum.totalAmount || 0,
      lastPipelineRun: new Date().toISOString(),
    };
  }
}
