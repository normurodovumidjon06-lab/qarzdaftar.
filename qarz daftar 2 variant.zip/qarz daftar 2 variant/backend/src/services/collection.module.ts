import { Module } from '@nestjs/common';
import { CollectionService } from './collection.service';
import { CollectionController } from './collection.controller';
import { NotificationModule } from './notification.module';
import { DebtModule } from '../debt/debt.module';
import { AuditModule } from '../common/audit/audit.module';

@Module({
  imports: [NotificationModule, DebtModule, AuditModule],
  controllers: [CollectionController],
  providers: [CollectionService],
  exports: [CollectionService],
})
export class CollectionModule {}
