import {
  Controller,
  Get,
  Post,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { RolesGuard } from '../guards/roles.guard';
import { Roles } from '../decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { UsersService } from '../users/users.service';
import { DebtService } from '../debt/debt.service';
import { CollectionService } from '../services/collection.service';
import { AuditService } from '../common/audit/audit.service';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';

@ApiTags('admin')
@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class AdminController {
  constructor(
    private readonly usersService: UsersService,
    private readonly debtService: DebtService,
    private readonly collectionService: CollectionService,
    private readonly auditService: AuditService,
  ) {}

  @Get('dashboard')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get admin dashboard data' })
  @ApiResponse({ status: 200, description: 'Dashboard data retrieved successfully' })
  async getDashboard() {
    const [userStats, debtStats, collectionStats] = await Promise.all([
      this.usersService.getStats(),
      this.debtService.getStats(),
      this.collectionService.getCollectionStats(),
    ]);

    return {
      users: userStats,
      debts: debtStats,
      collection: collectionStats,
      lastUpdated: new Date().toISOString(),
    };
  }

  @Get('audit-logs')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get audit logs' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'userId', required: false, type: String })
  @ApiQuery({ name: 'entity', required: false, type: String })
  @ApiQuery({ name: 'entityId', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Audit logs retrieved successfully' })
  async getAuditLogs(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('userId') userId?: string,
    @Query('entity') entity?: string,
    @Query('entityId') entityId?: string,
  ) {
    return this.auditService.getAuditLogs(
      userId,
      entity,
      entityId,
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 50,
    );
  }

  @Post('panic-button')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Trigger panic button - send hardware shock to all overdue debts' })
  @ApiResponse({ status: 200, description: 'Panic button triggered successfully' })
  async triggerPanicButton(@Request() req) {
    const overdueDebts = await this.debtService.getOverdueDebts();
    
    let successCount = 0;
    let errorCount = 0;
    const errors = [];

    for (const debt of overdueDebts) {
      try {
        if (debt.client.deviceToken) {
          await this.debtService.triggerHardwareShock(debt.id, req.user.id, req);
          successCount++;
        } else {
          errors.push(`Client ${debt.client.fullName} has no device token`);
          errorCount++;
        }
      } catch (error) {
        errors.push(`Failed to send to ${debt.client.fullName}: ${error.message}`);
        errorCount++;
      }
    }

    return {
      message: 'Panic button executed',
      totalDebts: overdueDebts.length,
      successCount,
      errorCount,
      errors,
      executedAt: new Date().toISOString(),
    };
  }

  @Get('health')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get system health status' })
  @ApiResponse({ status: 200, description: 'System health retrieved successfully' })
  async getHealth() {
    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: process.version,
    };
  }
}
