import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { UsersModule } from '../users/users.module';
import { DebtModule } from '../debt/debt.module';
import { CollectionModule } from '../services/collection.module';
import { AuditModule } from '../common/audit/audit.module';

@Module({
  imports: [UsersModule, DebtModule, CollectionModule, AuditModule],
  controllers: [AdminController],
})
export class AdminModule {}
