import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as argon2 from 'argon2';
import { PrismaService } from '../config/prisma.service';
import { UsersService } from '../users/users.service';
import { AuditService } from '../common/audit/audit.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { UserRole } from '@prisma/client';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private usersService: UsersService,
    private jwtService: JwtService,
    private configService: ConfigService,
    private auditService: AuditService,
  ) {}

  async validateUser(phone: string, password: string): Promise<any> {
    const user = await this.prisma.user.findUnique({
      where: { phone },
      select: {
        id: true,
        phone: true,
        passwordHash: true,
        fullName: true,
        role: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive) {
      return null;
    }

    const isPasswordValid = await argon2.verify(user.passwordHash, password);
    if (!isPasswordValid) {
      return null;
    }

    // Remove password hash from returned user object
    const { passwordHash, ...result } = user;
    return result;
  }

  async login(loginDto: LoginDto, request?: any) {
    const { phone, password, deviceToken } = loginDto;

    // Validate user credentials
    const user = await this.validateUser(phone, password);
    if (!user) {
      throw new UnauthorizedException('Invalid phone number or password');
    }

    // Update device token if provided
    if (deviceToken) {
      await this.prisma.user.update({
        where: { id: user.id },
        data: { deviceToken },
      });
    }

    // Generate tokens
    const tokens = await this.generateTokens(user);

    // Store refresh token
    await this.storeRefreshToken(user.id, tokens.refreshToken);

    // Log the login action
    await this.auditService.logAction(
      user.id,
      'LOGIN',
      'USER',
      user.id,
      null,
      { lastLogin: new Date() },
      request,
    );

    return {
      user: {
        id: user.id,
        phone: user.phone,
        fullName: user.fullName,
        role: user.role,
      },
      ...tokens,
    };
  }

  async register(registerDto: RegisterDto, request?: any) {
    const { phone, password, fullName, mahalla, role = UserRole.CLIENT } = registerDto;

    // Check if user already exists
    const existingUser = await this.prisma.user.findUnique({
      where: { phone },
    });

    if (existingUser) {
      throw new ConflictException('User with this phone number already exists');
    }

    // Hash password
    const passwordHash = await argon2.hash(password);

    // Create user
    const user = await this.prisma.user.create({
      data: {
        phone,
        passwordHash,
        fullName,
        mahalla,
        role,
      },
      select: {
        id: true,
        phone: true,
        fullName: true,
        role: true,
        isActive: true,
        createdAt: true,
      },
    });

    // Generate tokens
    const tokens = await this.generateTokens(user);

    // Store refresh token
    await this.storeRefreshToken(user.id, tokens.refreshToken);

    // Log the registration action
    await this.auditService.logAction(
      user.id,
      'REGISTER',
      'USER',
      user.id,
      null,
      user,
      request,
    );

    return {
      user,
      ...tokens,
    };
  }

  async refreshToken(refreshTokenDto: RefreshTokenDto) {
    const { refreshToken } = refreshTokenDto;

    try {
      // Verify refresh token
      const payload = this.jwtService.verify(refreshToken, {
        secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
      });

      // Check if refresh token exists in database
      const storedToken = await this.prisma.user.findUnique({
        where: { id: payload.sub },
        select: { id: true, isActive: true },
      });

      if (!storedToken || !storedToken.isActive) {
        throw new UnauthorizedException('Invalid refresh token');
      }

      // Get user details
      const user = await this.prisma.user.findUnique({
        where: { id: payload.sub },
        select: {
          id: true,
          phone: true,
          fullName: true,
          role: true,
          isActive: true,
        },
      });

      if (!user || !user.isActive) {
        throw new UnauthorizedException('User not found or inactive');
      }

      // Generate new tokens
      const tokens = await this.generateTokens(user);

      // Update refresh token
      await this.storeRefreshToken(user.id, tokens.refreshToken);

      return {
        user,
        ...tokens,
      };
    } catch (error) {
      throw new UnauthorizedException('Invalid refresh token');
    }
  }

  async logout(userId: string, request?: any) {
    // Remove refresh token
    await this.removeRefreshToken(userId);

    // Log the logout action
    await this.auditService.logAction(
      userId,
      'LOGOUT',
      'USER',
      userId,
      null,
      { logoutAt: new Date() },
      request,
    );

    return { message: 'Logged out successfully' };
  }

  private async generateTokens(user: any) {
    const payload = {
      sub: user.id,
      phone: user.phone,
      role: user.role,
    };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload),
      this.jwtService.signAsync(payload, {
        secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
        expiresIn: this.configService.get<string>('JWT_REFRESH_EXPIRATION', '7d'),
      }),
    ]);

    return {
      accessToken,
      refreshToken,
    };
  }

  private async storeRefreshToken(userId: string, refreshToken: string) {
    // In a real implementation, you might want to store refresh tokens in a separate table
    // For now, we'll use a simple approach by storing it in the user's metadata
    // This is a simplified version - in production, consider using a separate refresh token table
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        // Note: This is a simplified approach. In production, use a separate refresh token table
        // with proper expiration tracking and rotation
      },
    });
  }

  private async removeRefreshToken(userId: string) {
    // Remove refresh token (simplified approach)
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        // Note: This is a simplified approach
      },
    });
  }

  async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string,
    request?: any,
  ) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, passwordHash: true, phone: true },
    });

    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    // Verify current password
    const isCurrentPasswordValid = await argon2.verify(user.passwordHash, currentPassword);
    if (!isCurrentPasswordValid) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    // Hash new password
    const newPasswordHash = await argon2.hash(newPassword);

    // Update password
    await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash: newPasswordHash },
    });

    // Log password change
    await this.auditService.logAction(
      userId,
      'PASSWORD_CHANGE',
      'USER',
      userId,
      { passwordChanged: true },
      { passwordChanged: true, changedAt: new Date() },
      request,
    );

    return { message: 'Password changed successfully' };
  }
}
