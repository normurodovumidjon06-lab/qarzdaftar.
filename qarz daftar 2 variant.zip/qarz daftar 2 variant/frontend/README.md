# Qarz Daftari Frontend

Enterprise Debt Management CRM & Automated Collection System Frontend

## Features

- **Clean Architecture**: Separation of concerns with Domain/Data/Presentation layers
- **State Management**: Riverpod for reactive state management
- **Background Services**: Persistent background execution with WorkManager
- **Hardware Integration**: Vibration, TTS, and device admin capabilities
- **Kiosk Mode**: Undeletable app with device administrator privileges
- **Offline Support**: Local SQLite caching with sqflite
- **Push Notifications**: Firebase Cloud Messaging integration

## Tech Stack

- **Framework**: Flutter with Clean Architecture
- **State Management**: Riverpod
- **Navigation**: GoRouter
- **Data Classes**: Freezed for immutable models
- **HTTP**: Dio with interceptors
- **Local DB**: SQLite with sqflite
- **Background**: flutter_background_service, workmanager
- **Security**: flutter_secure_storage, crypto
- **Hardware**: vibration, flutter_tts, permission_handler

## Architecture

```
lib/
├── src/
│   ├── data/           # Data layer
│   │   ├── datasources/ # API and local DB
│   │   ├── models/     # Data transfer objects
│   │   └── repositories/ # Repository implementations
│   ├── domain/         # Business logic
│   │   ├── entities/   # Business objects
│   │   ├── repositories/ # Repository interfaces
│   │   └── usecases/   # Use cases
│   └── presentation/   # UI layer
│       ├── pages/      # Screens
│       ├── widgets/    # Reusable components
│       ├── providers/  # Riverpod providers
│       └── router/     # Navigation
└── core/               # Shared utilities
```

## Installation

```bash
# Install dependencies
flutter pub get

# Run code generation
flutter packages pub run build_runner build --delete-conflicting-outputs

# Run the app
flutter run
```

## Android Setup for Kiosk Mode

1. **Device Administrator**: The app requests device admin privileges for kiosk mode
2. **Background Service**: Configured to run persistently in background
3. **Boot Receiver**: Auto-starts on device boot
4. **System Overlay**: Permission to show alerts over other apps

## Key Features Implementation

### Background Service
- Persistent background execution using `flutter_background_service`
- WorkManager integration for scheduled tasks
- Auto-restart on app termination

### Hardware Shock Protocol
When FCM notification is received:
1. **Vibration**: Custom pattern `[1000, 500, 1000, 500, 2000]`
2. **TTS**: Uzbek language warning message
3. **UI Takeover**: Full-screen non-dismissible modal

### Kiosk Mode
- Device administrator privileges
- Lock task mode to prevent app switching
- Auto-start on boot
- Protection against force-stop and uninstallation

### Security
- AES-256 encryption for sensitive data
- Secure token storage
- Certificate pinning (recommended for production)
- Root detection (optional)

## Environment Configuration

Create `.env` file in the root:

```env
API_BASE_URL=https://your-backend-url.com
FCM_SERVER_KEY=your-fcm-server-key
ENCRYPTION_KEY=your-32-character-key
```

## Build for Production

```bash
# Build APK
flutter build apk --release

# Build App Bundle
flutter build appbundle --release
```

## Testing

```bash
# Run unit tests
flutter test

# Run widget tests
flutter test integration_test/
```

## Deployment

For enterprise deployment:

1. **Device Enrollment**: Use Android Enterprise for managed devices
2. **Kiosk Deployment**: Configure as dedicated device
3. **OTA Updates**: Implement update mechanism
4. **Remote Management**: Consider MDM integration

## Troubleshooting

### Background Service Issues
- Check battery optimization settings
- Verify auto-start permissions
- Ensure proper foreground service configuration

### Kiosk Mode Problems
- Verify device admin permissions are granted
- Check lock task mode permissions
- Ensure proper AndroidManifest.xml configuration

### FCM Not Working
- Verify Firebase configuration
- Check notification permissions
- Ensure proper service registration
