import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/services/hardware_shock_service.dart';
import '../../../core/services/kiosk_mode_service.dart';
import '../../../core/utils/logger.dart';
import '../../widgets/common/loading_widget.dart';

class HardwareShockPage extends ConsumerStatefulWidget {
  final String clientName;
  final double amount;
  final String? vibrationPattern;
  final String? ttsMessage;

  const HardwareShockPage({
    super.key,
    required this.clientName,
    required this.amount,
    this.vibrationPattern,
    this.ttsMessage,
  });

  @override
  ConsumerState<HardwareShockPage> createState() => _HardwareShockPageState();
}

class _HardwareShockPageState extends ConsumerState<HardwareShockPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<Color?> _colorAnimation;
  bool _isExecuting = false;
  int _executionCount = 0;

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));

    _colorAnimation = ColorTween(
      begin: Colors.red,
      end: Colors.orange,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    // Start animation
    _animationController.repeat(reverse: true);

    // Execute hardware shock
    _executeHardwareShock();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _executeHardwareShock() async {
    if (_isExecuting) return;

    setState(() {
      _isExecuting = true;
      _executionCount++;
    });

    try {
      Logger.hardware('Executing hardware shock for $clientName');

      // Execute the actual hardware shock
      await HardwareShockService.executeHardwareShock(
        clientName: clientName,
        amount: amount,
        vibrationPattern: vibrationPattern,
        ttsMessage: ttsMessage,
      );

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ogohlantirish muvaffaqiyatli amalga oshirildi'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      Logger.error('Hardware shock execution failed: $e');
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ogohlantirishni amalga oshirishda xatolik yuz berdi'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isExecuting = false;
        });
      }
    }
  }

  Future<void> _repeatHardwareShock() async {
    await _executeHardwareShock();
  }

  Future<void> _acknowledgeDebt() async {
    try {
      // Navigate to debt details or dashboard
      if (mounted) {
        context.pop();
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Qarzni tanlandingiz'),
            backgroundColor: Colors.blue,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      Logger.error('Failed to acknowledge debt: $e');
    }
  }

  Future<void> _enableKioskMode() async {
    try {
      setState(() => _isExecuting = true);
      
      await KioskModeService.enableFullKioskMode();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Kiosk rejimi yoqildi'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      Logger.error('Failed to enable kiosk mode: $e');
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Kiosk rejimini yoqib bo\'lmadi'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isExecuting = false);
      }
    }
  }

  Future<void> _emergencyExit() async {
    try {
      setState(() => _isExecuting = true);
      
      await KioskModeService.emergencyExit();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Kiosk rejimidan chiqildi'),
            backgroundColor: Colors.orange,
            duration: const Duration(seconds: 2),
          ),
        );
        
        // Close the page
        context.pop();
      }
    } catch (e) {
      Logger.error('Failed emergency exit: $e');
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Favqul chiqib bo\'lmadi'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isExecuting = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Prevent back button while executing
        if (_isExecuting) {
          return false;
        }
        
        // Show confirmation dialog
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Chiqish'),
            content: const Text('Ogohlantirishni to\'xtatlasizmi hohlaysiz?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Yo\'q'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Ha'),
              ),
            ],
          ),
        );

        return shouldPop ?? false;
      },
      child: Scaffold(
        backgroundColor: Colors.red.withOpacity(0.1),
        body: SafeArea(
          child: Stack(
            children: [
              // Background animation
              AnimatedBuilder(
                animation: _colorAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          _colorAnimation.value ?? Colors.red,
                          Colors.red.withOpacity(0.8),
                          Colors.red.withOpacity(0.6),
                        ],
                      ),
                    ),
                  );
                },
              ),
              
              // Main content
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Warning icon with animation
                      AnimatedBuilder(
                        animation: _scaleAnimation,
                        builder: (context, child) {
                          return Transform.scale(
                            scale: _scaleAnimation.value,
                            child: Container(
                              padding: const EdgeInsets.all(24),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.3),
                                    blurRadius: 20,
                                    spreadRadius: 10,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.warning_amber,
                                size: 80,
                                color: Colors.red,
                              ),
                            ),
                          );
                        },
                      ),
                      
                      const SizedBox(height: 32),
                      
                      // Warning text
                      Text(
                        'MUHIM OGohlANTIRISH!',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 28,
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Client name and amount
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.3),
                            width: 2,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              clientName,
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Qarz miqdori: ${amount.toStringAsFixed(0)} so\'m',
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: Colors.red[800],
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 32),
                      
                      // Action buttons
                      if (_isExecuting) ...[
                        const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          strokeWidth: 3,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Ogohlantirish amalga oshirilmoqda...',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ] else ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton.icon(
                              onPressed: _repeatHardwareShock,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Qaytarish'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 24,
                                  vertical: 12,
                                ),
                              ),
                            ),
                            ElevatedButton.icon(
                              onPressed: _acknowledgeDebt,
                              icon: const Icon(Icons.check),
                              label: const Text('Tanladim'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 24,
                                  vertical: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          onPressed: _enableKioskMode,
                          icon: const Icon(Icons.lock),
                          label: const Text('Kiosk rejimini yoqish'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                        ),
                      ],
                      
                      const SizedBox(height: 16),
                      
                      // Emergency exit button
                      TextButton.icon(
                        onPressed: _emergencyExit,
                        icon: const Icon(Icons.exit_to_app),
                        label: Text('Favqul chiqish ($_executionCount)'),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white.withOpacity(0.7),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Execution count
                      Text(
                        'Ishlatishlar soni: $_executionCount',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.white.withOpacity(0.6),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Loading overlay
              if (_isExecuting)
                Container(
                  color: Colors.black.withOpacity(0.5),
                  child: const Center(
                    child: LoadingWidget(),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
