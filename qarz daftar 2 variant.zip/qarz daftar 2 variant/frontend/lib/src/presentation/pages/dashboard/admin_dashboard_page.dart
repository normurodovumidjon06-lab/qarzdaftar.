import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:go_router/go_router.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../../data/repositories/debt_repository.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/logger.dart';
import '../../providers/auth_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/common/loading_widget.dart';
import '../../widgets/common/error_widget.dart';
import '../../widgets/charts/debt_chart.dart';
import '../../widgets/charts/user_chart.dart';
import '../../widgets/cards/stats_card.dart';
import '../../widgets/cards/recent_debts_card.dart';
import '../../widgets/buttons/panic_button.dart';

class AdminDashboardPage extends ConsumerStatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  ConsumerState<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends ConsumerState<AdminDashboardPage> {
  bool _isLoading = false;
  String? _error;
  Map<String, dynamic>? _dashboardData;
  Map<String, dynamic>? _debtStats;
  Map<String, dynamic>? _userStats;
  Map<String, dynamic>? _collectionStats;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final authRepository = ref.read(authRepositoryProvider);
      final debtRepository = ref.read(debtRepositoryProvider);

      final results = await Future.wait([
        authRepository.getProfile(),
        debtRepository.getDebtStats(),
        debtRepository.getOverdueDebts(),
        debtRepository.getDebtsDueIn7Days(),
        debtRepository.getDebts(limit: 5),
      ]);

      final profileResponse = results[0];
      final debtStatsResponse = results[1];
      final overdueDebtsResponse = results[2];
      final dueIn7DaysResponse = results[3];
      final recentDebtsResponse = results[4];

      if (mounted) {
        setState(() {
          _dashboardData = {
            'user': profileResponse['data'],
            'overdueDebts': overdueDebtsResponse['data'] ?? [],
            'debtsDueIn7Days': dueIn7DaysResponse['data'] ?? [],
            'recentDebts': recentDebtsResponse['data']?['debts'] ?? [],
          };
          _debtStats = debtStatsResponse['data'];
          _isLoading = false;
        });
      }
    } catch (e) {
      Logger.error('Failed to load dashboard data: $e');
      if (mounted) {
        setState(() {
          _error = 'Dashboard ma\'lumotlarini yuklashda xatolik yuz berdi';
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _refreshData() async {
    await _loadDashboardData();
  }

  Future<void> _triggerPanicButton() async {
    try {
      final debtRepository = ref.read(debtRepositoryProvider);
      
      setState(() => _isLoading = true);
      
      final response = await debtRepository.triggerHardwareShock('all');
      
      if (response['success'] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Barch mijozlarga ogohlantirish yuborildi!'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(response['message'] ?? 'Xatolik yuz berdi'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      Logger.error('Failed to trigger panic button: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ogohlantirishni yuborishda xatolik yuz berdi'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);
    final isDark = themeMode == ThemeMode.dark;

    if (_isLoading) {
      return const Scaffold(
        body: LoadingWidget(),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Admin Dashboard'),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: AppErrorWidget(
          error: _error!,
          onRetry: _refreshData,
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshData,
          ),
          IconButton(
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () {
              ref.read(themeProvider.notifier).toggleTheme();
            },
          ),
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'profile',
                child: const Text('Profil'),
              ),
              PopupMenuItem(
                value: 'settings',
                child: const Text('Sozlamalar'),
              ),
              PopupMenuItem(
                value: 'audit',
                child: const Text('Audit loglar'),
              ),
              PopupMenuItem(
                value: 'logout',
                child: const Text('Chiqish'),
              ),
            ],
            onSelected: (value) {
              switch (value) {
                case 'profile':
                  context.go('/admin/profile');
                  break;
                case 'settings':
                  context.go('/admin/settings');
                  break;
                case 'audit':
                  context.go('/admin/audit-logs');
                  break;
                case 'logout':
                  ref.read(authProvider.notifier).logout();
                  break;
              }
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshData,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with user info
              _buildUserHeader(),
              const SizedBox(height: 24),
              
              // Stats Cards Row
              Row(
                children: [
                  Expanded(
                    child: StatsCard(
                      title: 'Jami Foydalanuvchilar',
                      value: _userStats?['totalUsers']?.toString() ?? '0',
                      icon: Icons.people,
                      color: Colors.blue,
                      onTap: () => context.go('/admin/users'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: StatsCard(
                      title: 'Faol Foydalanuvchilar',
                      value: _userStats?['activeUsers']?.toString() ?? '0',
                      icon: Icons.person,
                      color: Colors.green,
                      onTap: () => context.go('/admin/users'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              
              Row(
                children: [
                  Expanded(
                    child: StatsCard(
                      title: 'Jami Qarzlar',
                      value: _debtStats?['totalDebts']?.toString() ?? '0',
                      icon: Icons.account_balance,
                      color: Colors.orange,
                      onTap: () => context.go('/admin/debts'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: StatsCard(
                      title: 'Faol Qarzlar',
                      value: _debtStats?['activeDebts']?.toString() ?? '0',
                      icon: Icons.pending_actions,
                      color: Colors.purple,
                      onTap: () => context.go('/admin/debts'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              
              Row(
                children: [
                  Expanded(
                    child: StatsCard(
                      title: 'To\'langan Qarzlar',
                      value: _debtStats?['paidDebts']?.toString() ?? '0',
                      icon: Icons.check_circle,
                      color: Colors.green,
                      onTap: () => context.go('/admin/debts'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: StatsCard(
                      title: 'Muddati O\'tgan Qarzlar',
                      value: _debtStats?['overdueDebts']?.toString() ?? '0',
                      icon: Icons.warning,
                      color: Colors.red,
                      onTap: () => context.go('/admin/debts'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Charts Section
              Text(
                'Statistika',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              // Debt Chart
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Qarzlar Holati',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 200,
                        child: DebtChart(
                          totalDebts: _debtStats?['totalDebts'] ?? 0,
                          activeDebts: _debtStats?['activeDebts'] ?? 0,
                          paidDebts: _debtStats?['paidDebts'] ?? 0,
                          defaultedDebts: _debtStats?['defaultedDebts'] ?? 0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              // User Chart
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Foydalanuvchilar Holati',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 200,
                        child: UserChart(
                          totalUsers: _userStats?['totalUsers'] ?? 0,
                          activeUsers: _userStats?['activeUsers'] ?? 0,
                          clientUsers: _userStats?['clientUsers'] ?? 0,
                          adminUsers: _userStats?['adminUsers'] ?? 0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              
              // Recent Debts
              Text(
                'So\'nggi Qarzlar',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              RecentDebtsCard(
                debts: _dashboardData?['recentDebts'] ?? [],
                onTap: (debtId) {
                  context.go('/admin/debts/$debtId');
                },
              ),
              const SizedBox(height: 24),
              
              // Panic Button
              PanicButton(
                onPressed: _triggerPanicButton,
                isLoading: _isLoading,
              ),
              const SizedBox(height: 24),
              
              // Collection Stats
              if (_collectionStats != null) ...[
                Text(
                  'Yig\'ish Statistikasi',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildCollectionStat(
                          '7 kun ichida qarzlar',
                          _collectionStats!['debtsDueIn7Days']?.toString() ?? '0',
                          Icons.schedule,
                          Colors.orange,
                        ),
                        const SizedBox(height: 12),
                        _buildCollectionStat(
                          'Muddati o\'tgan qarzlar',
                          _collectionStats!['overdueDebts']?.toString() ?? '0',
                          Icons.warning,
                          Colors.red,
                        ),
                        const SizedBox(height: 12),
                        _buildCollectionStat(
                          'Oxirgi sinxronizatsiya',
                          _collectionStats!['lastSync'] ?? 'Hech qachon',
                          Icons.sync,
                          Colors.blue,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserHeader() {
    final user = _dashboardData?['user'];
    
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: Theme.of(context).primaryColor,
              child: Text(
                user?['fullName']?.substring(0, 2).toUpperCase() ?? 'A',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user?['fullName'] ?? 'Admin',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    user?['role'] ?? 'SUPER_ADMIN',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                  Text(
                    user?['phone'] ?? '',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.admin_panel_settings,
              color: Theme.of(context).primaryColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCollectionStat(String label, String value, IconData icon, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
