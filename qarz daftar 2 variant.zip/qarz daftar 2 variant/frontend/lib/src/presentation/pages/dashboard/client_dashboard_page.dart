import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../../data/repositories/debt_repository.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/logger.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/common/loading_widget.dart';
import '../../widgets/common/error_widget.dart';
import '../../widgets/cards/stats_card.dart';
import '../../widgets/charts/debt_chart.dart';

class ClientDashboardPage extends ConsumerStatefulWidget {
  const ClientDashboardPage({super.key});

  @override
  ConsumerState<ClientDashboardPage> createState() => _ClientDashboardPageState();
}

class _ClientDashboardPageState extends ConsumerState<ClientDashboardPage> {
  bool _isLoading = false;
  String? _error;
  Map<String, dynamic>? _dashboardData;
  Map<String, dynamic>? _debtStats;
  List<dynamic>? _myDebts;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final authRepository = ref.read(authRepositoryProvider);
      final debtRepository = ref.read(debtRepositoryProvider);

      final results = await Future.wait([
        authRepository.getProfile(),
        debtRepository.getMyDebts(),
        debtRepository.getDebtStats(),
      ]);

      final profileResponse = results[0];
      final myDebtsResponse = results[1];
      final debtStatsResponse = results[2];

      if (mounted) {
        setState(() {
          _dashboardData = {
            'user': profileResponse['data'],
          };
          _myDebts = myDebtsResponse['data']?['debts'] ?? [];
          _debtStats = debtStatsResponse['data'];
          _isLoading = false;
        });
      }
    } catch (e) {
      Logger.error('Failed to load client dashboard: $e');
      if (mounted) {
        setState(() {
          _error = 'Dashboard ma\'lumotlarini yuklashda xatolik yuz berdi';
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _refreshData() async {
    await _loadDashboardData();
  }

  double get _totalDebtAmount {
    if (_myDebts == null || _myDebts!.isEmpty) return 0.0;
    
    return _myDebts!
        .where((debt) => debt['status'] == AppConstants.debtStatusActive)
        .fold<double>(0.0, (sum, debt) => sum + (debt['totalAmount'] as num).toDouble());
  }

  int get _activeDebtsCount {
    if (_myDebts == null) return 0;
    
    return _myDebts!
        .where((debt) => debt['status'] == AppConstants.debtStatusActive)
        .length;
  }

  int get _overdueDebtsCount {
    if (_myDebts == null) return 0;
    
    final now = DateTime.now();
    return _myDebts!
        .where((debt) {
          final dueDate = DateTime.parse(debt['dueDate']);
          return debt['status'] == AppConstants.debtStatusActive && dueDate.isBefore(now);
        })
        .length;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: LoadingWidget(message: 'Dashboard yuklanmoqda...'),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Mening Qarzlarim'),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: AppErrorWidget(
          error: _error!,
          onRetry: _refreshData,
        ),
      );
    }

    final user = _dashboardData?['user'];
    final totalAmount = _totalDebtAmount;
    final activeCount = _activeDebtsCount;
    final overdueCount = _overdueDebtsCount;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mening Qarzlarim'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshData,
          ),
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'profile',
                child: const Text('Profil'),
              ),
              PopupMenuItem(
                value: 'settings',
                child: const Text('Sozlamalar'),
              ),
              PopupMenuItem(
                value: 'logout',
                child: const Text('Chiqish'),
              ),
            ],
            onSelected: (value) {
              switch (value) {
                case 'profile':
                  context.go('/client/profile');
                  break;
                case 'settings':
                  context.go('/client/settings');
                  break;
                case 'logout':
                  ref.read(authProvider.notifier).logout();
                  break;
              }
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshData,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // User info card
              Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 35,
                        backgroundColor: Theme.of(context).primaryColor,
                        child: Text(
                          user?['fullName']?.substring(0, 2).toUpperCase() ?? 'M',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              user?['fullName'] ?? 'Mijoz',
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              user?['phone'] ?? '',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Colors.grey[600],
                              ),
                            ),
                            if (user?['mahalla'] != null)
                              Text(
                                user!['mahalla'],
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Colors.grey[500],
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Warning for overdue debts
              if (overdueCount > 0) ...[
                Card(
                  color: Colors.red.shade50,
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Icon(Icons.warning, color: Colors.red.shade700, size: 32),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'DIQQAT! Muddati o\'tgan qarzlar mavjud',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Colors.red.shade700,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Sizda $overdueCount ta muddati o\'tgan qarz bor. Iltimos, ularni tezroq to\'lang.',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Colors.red.shade600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
              ],
              
              // Stats Cards
              Text(
                'Qarzlar Statistikasi',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              // Total Debt Amount Card (Large)
              Card(
                elevation: 6,
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.account_balance_wallet_outlined,
                        size: 48,
                        color: Theme.of(context).primaryColor,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Jami Qarz Miqdori',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${totalAmount.toStringAsFixed(0)} so\'m',
                        style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          color: Theme.of(context).primaryColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 32,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              Row(
                children: [
                  Expanded(
                    child: StatsCard(
                      title: 'Faol Qarzlar',
                      value: activeCount.toString(),
                      icon: Icons.pending_actions,
                      color: Colors.orange,
                      onTap: () => context.go('/client/debts'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: StatsCard(
                      title: 'Muddati O\'tgan',
                      value: overdueCount.toString(),
                      icon: Icons.warning,
                      color: Colors.red,
                      onTap: () => context.go('/client/debts'),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Recent Debts
              Text(
                'Qarzlar Ro\'yxati',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              if (_myDebts == null || _myDebts!.isEmpty)
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.account_balance_wallet_outlined,
                            size: 64,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Sizda hozircha qarzlar yo\'q',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _myDebts!.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    final debt = _myDebts![index];
                    final dueDate = DateTime.parse(debt['dueDate']);
                    final isOverdue = dueDate.isBefore(DateTime.now());
                    final status = debt['status'];
                    
                    return Card(
                      elevation: 2,
                      child: ListTile(
                        onTap: () {
                          context.go('/client/debts/${debt['id']}');
                        },
                        title: Text(
                          'Qarz #${debt['id'].substring(0, 8)}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Miqdor: ${debt['totalAmount']} so\'m'),
                            Text('Muddati: ${DateFormat('dd.MM.yyyy').format(dueDate)}'),
                          ],
                        ),
                        trailing: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getStatusColor(status, isOverdue),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            _getStatusText(status, isOverdue),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              
              const SizedBox(height: 24),
              
              // View all debts button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    context.go('/client/debts');
                  },
                  icon: const Icon(Icons.list),
                  label: const Text('Barcha qarzlarni ko\'rish'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status, bool isOverdue) {
    if (isOverdue) return Colors.red;
    
    switch (status) {
      case AppConstants.debtStatusActive:
        return Colors.orange;
      case AppConstants.debtStatusPaid:
        return Colors.green;
      case AppConstants.debtStatusDefaulted:
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText(String status, bool isOverdue) {
    if (isOverdue) return 'Muddati o\'tgan';
    
    switch (status) {
      case AppConstants.debtStatusActive:
        return 'Faol';
      case AppConstants.debtStatusPaid:
        return 'To\'langan';
      case AppConstants.debtStatusDefaulted:
        return 'Muddati o\'tgan';
      default:
        return 'Noma\'lum';
    }
  }
}
