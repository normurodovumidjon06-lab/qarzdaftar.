import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../states/auth_state.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/datasources/local/storage_service.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/logger.dart';

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _authRepository;
  
  AuthNotifier(this._authRepository) : super(const AuthState.initial()) {
    _initializeAuth();
  }

  Future<void> _initializeAuth() async {
    try {
      state = const AuthState.loading();
      
      final isLoggedIn = await StorageService.isLoggedIn();
      
      if (isLoggedIn) {
        final authTokens = await StorageService.getAuthTokens();
        final userId = authTokens['userId'];
        final userRole = authTokens['userRole'];
        
        if (userId != null && userRole != null) {
          // Validate tokens with backend
          final isValid = await _validateTokens();
          
          if (isValid) {
            state = AuthState.authenticated(
              userId: userId,
              userRole: userRole!,
            );
            Logger.auth('User authenticated from storage');
          } else {
            // Tokens are invalid, clear them
            await StorageService.clearAuthTokens();
            state = const AuthState.unauthenticated();
            Logger.auth('Invalid tokens, cleared storage');
          }
        } else {
          state = const AuthState.unauthenticated();
        }
      } else {
        state = const AuthState.unauthenticated();
      }
    } catch (e) {
      Logger.error('Error initializing auth: $e');
      state = AuthState.error(e.toString());
    }
  }

  Future<bool> _validateTokens() async {
    try {
      final response = await _authRepository.validateTokens();
      return response['success'] == true;
    } catch (e) {
      Logger.error('Error validating tokens: $e');
      return false;
    }
  }

  Future<void> login({
    required String phone,
    required String password,
    String? deviceToken,
  }) async {
    try {
      state = const AuthState.loading();
      
      final response = await _authRepository.login(
        phone: phone,
        password: password,
        deviceToken: deviceToken,
      );
      
      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        final tokens = userData;
        
        // Save tokens to storage
        await StorageService.saveAuthTokens(
          accessToken: tokens['accessToken'],
          refreshToken: tokens['refreshToken'],
          userId: user['id'],
          userRole: user['role'],
        );
        
        state = AuthState.authenticated(
          userId: user['id'],
          userRole: user['role'],
          user: user,
        );
        
        Logger.auth('User logged in successfully');
      } else {
        state = AuthState.error(response['message'] ?? 'Login failed');
      }
    } catch (e) {
      Logger.error('Login error: $e');
      state = AuthState.error(e.toString());
    }
  }

  Future<void> register({
    required String phone,
    required String password,
    required String fullName,
    String? mahalla,
    String? role,
  }) async {
    try {
      state = const AuthState.loading();
      
      final response = await _authRepository.register(
        phone: phone,
        password: password,
        fullName: fullName,
        mahalla: mahalla,
        role: role ?? AppConstants.clientRole,
      );
      
      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        final tokens = userData;
        
        // Save tokens to storage
        await StorageService.saveAuthTokens(
          accessToken: tokens['accessToken'],
          refreshToken: tokens['refreshToken'],
          userId: user['id'],
          userRole: user['role'],
        );
        
        state = AuthState.authenticated(
          userId: user['id'],
          userRole: user['role'],
          user: user,
        );
        
        Logger.auth('User registered successfully');
      } else {
        state = AuthState.error(response['message'] ?? 'Registration failed');
      }
    } catch (e) {
      Logger.error('Registration error: $e');
      state = AuthState.error(e.toString());
    }
  }

  Future<void> logout() async {
    try {
      state = const AuthState.loading();
      
      // Call logout API
      await _authRepository.logout();
      
      // Clear local storage
      await StorageService.clearAuthTokens();
      
      state = const AuthState.unauthenticated();
      
      Logger.auth('User logged out successfully');
    } catch (e) {
      Logger.error('Logout error: $e');
      // Even if API call fails, clear local storage
      await StorageService.clearAuthTokens();
      state = const AuthState.unauthenticated();
    }
  }

  Future<void> refreshToken() async {
    try {
      final refreshToken = await StorageService.getSecureString(AppConstants.refreshTokenKey);
      
      if (refreshToken == null) {
        state = const AuthState.unauthenticated();
        return;
      }
      
      final response = await _authRepository.refreshToken(refreshToken);
      
      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        final tokens = userData;
        
        // Update tokens in storage
        await StorageService.saveAuthTokens(
          accessToken: tokens['accessToken'],
          refreshToken: tokens['refreshToken'],
          userId: user['id'],
          userRole: user['role'],
        );
        
        state = AuthState.authenticated(
          userId: user['id'],
          userRole: user['role'],
          user: user,
        );
        
        Logger.auth('Tokens refreshed successfully');
      } else {
        // Refresh failed, clear tokens and logout
        await StorageService.clearAuthTokens();
        state = const AuthState.unauthenticated();
        Logger.auth('Token refresh failed, logged out');
      }
    } catch (e) {
      Logger.error('Token refresh error: $e');
      await StorageService.clearAuthTokens();
      state = const AuthState.unauthenticated();
    }
  }

  Future<void> updateProfile({
    String? fullName,
    String? mahalla,
  }) async {
    try {
      final userId = state.user?.id;
      if (userId == null) return;
      
      final response = await _authRepository.updateProfile(
        userId: userId,
        fullName: fullName,
        mahalla: mahalla,
      );
      
      if (response['success'] == true) {
        final updatedUser = response['data'];
        
        state = state.copyWith(user: updatedUser);
        
        Logger.auth('Profile updated successfully');
      } else {
        state = AuthState.error(response['message'] ?? 'Profile update failed');
      }
    } catch (e) {
      Logger.error('Profile update error: $e');
      state = AuthState.error(e.toString());
    }
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      final response = await _authRepository.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );
      
      if (response['success'] != true) {
        state = AuthState.error(response['message'] ?? 'Password change failed');
      } else {
        Logger.auth('Password changed successfully');
      }
    } catch (e) {
      Logger.error('Password change error: $e');
      state = AuthState.error(e.toString());
    }
  }

  void setOfflineMode(bool isOffline) {
    state = state.copyWith(isOffline: isOffline);
    Logger.auth('Offline mode: $isOffline');
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

// Provider
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.watch(authRepositoryProvider));
});

// Additional providers
final userProvider = Provider((ref) {
  return ref.watch(authProvider).user;
});

final userIdProvider = Provider((ref) {
  return ref.watch(authProvider).user?.id;
});

final userRoleProvider = Provider((ref) {
  return ref.watch(authProvider).user?.role;
});

final isLoggedInProvider = Provider((ref) {
  return ref.watch(authProvider).isLoggedIn;
});

final isAdminProvider = Provider((ref) {
  return ref.watch(authProvider).user?.role == AppConstants.superAdminRole;
});

final isClientProvider = Provider((ref) {
  return ref.watch(authProvider).user?.role == AppConstants.clientRole;
});

final isOfflineProvider = Provider((ref) {
  return ref.watch(authProvider).isOffline;
});

final authErrorProvider = Provider((ref) {
  return ref.watch(authProvider).error;
});
