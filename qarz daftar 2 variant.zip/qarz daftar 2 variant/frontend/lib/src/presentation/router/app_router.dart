import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/local/storage_service.dart';
import '../../core/constants/app_constants.dart';
import '../providers/auth_provider.dart';
import '../pages/auth/login_page.dart';
import '../pages/auth/register_page.dart';
import '../pages/dashboard/admin_dashboard_page.dart';
import '../pages/dashboard/client_dashboard_page.dart';
import '../pages/debt/debt_list_page.dart';
import '../pages/debt/debt_details_page.dart';
import '../pages/debt/create_debt_page.dart';
import '../pages/auth/splash_page.dart';
import '../pages/debt/hardware_shock_page.dart';
import '../pages/settings/settings_page.dart';
import '../pages/profile/profile_page.dart';
import '../pages/audit/audit_logs_page.dart';
import '../widgets/common/loading_widget.dart';
import '../widgets/common/error_widget.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authProvider);
  
  return GoRouter(
    initialLocation: '/splash',
    debugLogDiagnostics: true,
    redirect: (context, state) {
      final isLoggedIn = authState.isLoggedIn;
      final userRole = authState.user?.role;
      final isSplash = state.location == '/splash';
      final isAuth = state.location.startsWith('/auth');
      final isAdmin = state.location.startsWith('/admin');
      
      // If not logged in and not on splash or auth page, redirect to splash
      if (!isLoggedIn && !isSplash && !isAuth) {
        return '/splash';
      }
      
      // If logged in and on splash or auth page, redirect to appropriate dashboard
      if (isLoggedIn && (isSplash || isAuth)) {
        if (userRole == AppConstants.superAdminRole) {
          return '/admin/dashboard';
        } else if (userRole == AppConstants.clientRole) {
          return '/client/dashboard';
        }
      }
      
      // If not admin but trying to access admin routes, redirect to client dashboard
      if (isLoggedIn && userRole != AppConstants.superAdminRole && isAdmin) {
        return '/client/dashboard';
      }
      
      // If client but trying to access admin-only routes, redirect to client dashboard
      if (isLoggedIn && userRole == AppConstants.clientRole && isAdmin) {
        return '/client/dashboard';
      }
      
      return null;
    },
    refreshListenable: authState,
    routes: [
      // Splash Screen
      GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashPage(),
      ),
      
      // Authentication Routes
      GoRoute(
        path: '/auth',
        name: 'auth',
        builder: (context, state) => const LoginPage(),
        routes: [
          GoRoute(
            path: '/login',
            name: 'login',
            builder: (context, state) => const LoginPage(),
          ),
          GoRoute(
            path: '/register',
            name: 'register',
            builder: (context, state) => const RegisterPage(),
          ),
        ],
      ),
      
      // Admin Routes
      GoRoute(
        path: '/admin',
        name: 'admin',
        builder: (context, state) => const AdminDashboardPage(),
        routes: [
          GoRoute(
            path: '/dashboard',
            name: 'admin-dashboard',
            builder: (context, state) => const AdminDashboardPage(),
          ),
          GoRoute(
            path: '/debts',
            name: 'admin-debts',
            builder: (context, state) => const DebtListPage(isAdmin: true),
            routes: [
              GoRoute(
                path: '/create',
                name: 'create-debt',
                builder: (context, state) => const CreateDebtPage(),
              ),
              GoRoute(
                path: '/:id',
                name: 'debt-details',
                builder: (context, state) {
                  final debtId = state.pathParameters['id']!;
                  return DebtDetailsPage(debtId: debtId, isAdmin: true);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/audit-logs',
            name: 'audit-logs',
            builder: (context, state) => const AuditLogsPage(),
          ),
          GoRoute(
            path: '/profile',
            name: 'admin-profile',
            builder: (context, state) => const ProfilePage(isAdmin: true),
          ),
          GoRoute(
            path: '/settings',
            name: 'admin-settings',
            builder: (context, state) => const SettingsPage(isAdmin: true),
          ),
        ],
      ),
      
      // Client Routes
      GoRoute(
        path: '/client',
        name: 'client',
        builder: (context, state) => const ClientDashboardPage(),
        routes: [
          GoRoute(
            path: '/dashboard',
            name: 'client-dashboard',
            builder: (context, state) => const ClientDashboardPage(),
          ),
          GoRoute(
            path: '/debts',
            name: 'client-debts',
            builder: (context, state) => const DebtListPage(isAdmin: false),
            routes: [
              GoRoute(
                path: '/:id',
                name: 'client-debt-details',
                builder: (context, state) {
                  final debtId = state.pathParameters['id']!;
                  return DebtDetailsPage(debtId: debtId, isAdmin: false);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/profile',
            name: 'client-profile',
            builder: (context, state) => const ProfilePage(isAdmin: false),
          ),
          GoRoute(
            path: '/settings',
            name: 'client-settings',
            builder: (context, state) => const SettingsPage(isAdmin: false),
          ),
        ],
      ),
      
      // Hardware Shock Route (can be accessed from anywhere)
      GoRoute(
        path: '/hardware-shock',
        name: 'hardware-shock',
        builder: (context, state) {
          final clientName = state.uri.queryParameters['clientName'] ?? 'Mijoz';
          final amount = double.tryParse(state.uri.queryParameters['amount'] ?? '0') ?? 0;
          final vibrationPattern = state.uri.queryParameters['vibrationPattern'];
          final ttsMessage = state.uri.queryParameters['ttsMessage'];
          
          return HardwareShockPage(
            clientName: clientName,
            amount: amount,
            vibrationPattern: vibrationPattern,
            ttsMessage: ttsMessage,
          );
        },
      ),
      
      // Universal Routes (accessible by both roles)
      GoRoute(
        path: '/profile',
        name: 'profile',
        builder: (context, state) {
          final isAdmin = authState.user?.role == AppConstants.superAdminRole;
          return ProfilePage(isAdmin: isAdmin);
        },
      ),
      
      GoRoute(
        path: '/settings',
        name: 'settings',
        builder: (context, state) {
          final isAdmin = authState.user?.role == AppConstants.superAdminRole;
          return SettingsPage(isAdmin: isAdmin);
        },
      ),
    ],
    
    errorBuilder: (context, state) => AppErrorWidget(
      error: state.error,
      onRetry: () => context.go('/splash'),
    ),
    
    loadingBuilder: (context, state) => const LoadingWidget(),
  );
});

class AppRouter {
  static GoRouter get router => routerProvider;
  
  // Navigation helpers
  static void goToSplash(BuildContext context) {
    context.go('/splash');
  }
  
  static void goToLogin(BuildContext context) {
    context.go('/auth/login');
  }
  
  static void goToRegister(BuildContext context) {
    context.go('/auth/register');
  }
  
  static void goToAdminDashboard(BuildContext context) {
    context.go('/admin/dashboard');
  }
  
  static void goToClientDashboard(BuildContext context) {
    context.go('/client/dashboard');
  }
  
  static void goToDebts(BuildContext context, {bool isAdmin = false}) {
    final route = isAdmin ? '/admin/debts' : '/client/debts';
    context.go(route);
  }
  
  static void goToCreateDebt(BuildContext context) {
    context.go('/admin/debts/create');
  }
  
  static void goToDebtDetails(BuildContext context, String debtId, {bool isAdmin = false}) {
    final route = isAdmin ? '/admin/debts/$debtId' : '/client/debts/$debtId';
    context.go(route);
  }
  
  static void goToHardwareShock(
    BuildContext context, {
    required String clientName,
    required double amount,
    String? vibrationPattern,
    String? ttsMessage,
  }) {
    final queryParams = <String, String>{
      'clientName': clientName,
      'amount': amount.toString(),
    };
    
    if (vibrationPattern != null) {
      queryParams['vibrationPattern'] = vibrationPattern;
    }
    
    if (ttsMessage != null) {
      queryParams['ttsMessage'] = ttsMessage;
    }
    
    context.go('/hardware-shock', extra: queryParams);
  }
  
  static void goToProfile(BuildContext context) {
    context.go('/profile');
  }
  
  static void goToSettings(BuildContext context) {
    context.go('/settings');
  }
  
  static void goToAuditLogs(BuildContext context) {
    context.go('/admin/audit-logs');
  }
  
  static void pop(BuildContext context) {
    context.pop();
  }
  
  static void popToRoot(BuildContext context) {
    while (context.canPop()) {
      context.pop();
    }
  }
  
  static String? currentRoute(BuildContext context) {
    return GoRouterState.of(context).location;
  }
  
  static bool canPop(BuildContext context) {
    return context.canPop();
  }
  
  // Route guards
  static bool isAdminRoute(String route) {
    return route.startsWith('/admin');
  }
  
  static bool isClientRoute(String route) {
    return route.startsWith('/client');
  }
  
  static bool isAuthRoute(String route) {
    return route.startsWith('/auth');
  }
  
  static bool isPublicRoute(String route) {
    return route == '/splash' || isAuthRoute(route) || route == '/hardware-shock';
  }
  
  // Navigation utilities
  static Future<T?> pushNamed<T>(
    BuildContext context,
    String name, {
    Object? extra,
    Map<String, String>? pathParameters,
    Map<String, String>? queryParameters,
  }) {
    return context.pushNamed<T>(
      name,
      extra: extra,
      pathParameters: pathParameters,
      queryParameters: queryParameters,
    );
  }
  
  static Future<T?> pushNamedAndClearStack<T>(
    BuildContext context,
    String name, {
    Object? extra,
    Map<String, String>? pathParameters,
    Map<String, String>? queryParameters,
  }) {
    while (context.canPop()) {
      context.pop();
    }
    
    return context.pushNamed<T>(
      name,
      extra: extra,
      pathParameters: pathParameters,
      queryParameters: queryParameters,
    );
  }
  
  static void pushReplacementNamed(
    BuildContext context,
    String name, {
    Object? extra,
    Map<String, String>? pathParameters,
    Map<String, String>? queryParameters,
  }) {
    context.pushReplacementNamed(
      name,
      extra: extra,
      pathParameters: pathParameters,
      queryParameters: queryParameters,
    );
  }
  
  static void goNamed(
    BuildContext context,
    String name, {
    Object? extra,
    Map<String, String>? pathParameters,
    Map<String, String>? queryParameters,
  }) {
    context.goNamed(
      name,
      extra: extra,
      pathParameters: pathParameters,
      queryParameters: queryParameters,
    );
  }
}
