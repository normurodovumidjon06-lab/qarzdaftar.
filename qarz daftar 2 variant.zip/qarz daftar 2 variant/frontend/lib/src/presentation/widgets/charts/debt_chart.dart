import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class DebtChart extends StatelessWidget {
  final int totalDebts;
  final int activeDebts;
  final int paidDebts;
  final int defaultedDebts;

  const DebtChart({
    super.key,
    required this.totalDebts,
    required this.activeDebts,
    required this.paidDebts,
    required this.defaultedDebts,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.5,
      child: PieChart(
        PieChartData(
          sectionsSpace: 2,
          centerSpaceRadius: 60,
          centerSpaceColor: Colors.transparent,
          sections: [
            // Active Debts
            PieChartSectionData(
              color: Colors.orange,
              value: activeDebts.toDouble(),
              title: 'Faol',
              radius: 50,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              badgeWidget: _Badge(
                text: activeDebts.toString(),
                color: Colors.orange,
              ),
              badgePositionPercentageOffset: .98,
            ),
            
            // Paid Debts
            PieChartSectionData(
              color: Colors.green,
              value: paidDebts.toDouble(),
              title: 'To\'langan',
              radius: 50,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              badgeWidget: _Badge(
                text: paidDebts.toString(),
                color: Colors.green,
              ),
              badgePositionPercentageOffset: .98,
            ),
            
            // Defaulted Debts
            PieChartSectionData(
              color: Colors.red,
              value: defaultedDebts.toDouble(),
              title: 'Muddati o\'tgan',
              radius: 50,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              badgeWidget: _Badge(
                text: defaultedDebts.toString(),
                color: Colors.red,
              ),
              badgePositionPercentageOffset: .98,
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;

  const _Badge({
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      padding: const EdgeInsets.all(4),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
