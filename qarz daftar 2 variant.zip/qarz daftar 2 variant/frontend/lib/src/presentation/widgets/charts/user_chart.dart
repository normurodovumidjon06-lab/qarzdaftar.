import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class UserChart extends StatelessWidget {
  final int totalUsers;
  final int activeUsers;
  final int clientUsers;
  final int adminUsers;

  const UserChart({
    super.key,
    required this.totalUsers,
    required this.activeUsers,
    required this.clientUsers,
    required this.adminUsers,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.5,
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: totalUsers.toDouble() * 1.2,
          barTouchData: BarTouchData(
            touchTooltipData: BarTouchTooltipData(
              getTooltipColor: ((group) => Colors.grey),
              getTooltipItem: (group, rodIndex, rodIndex) {
                final category = _getCategory(rodIndex);
                final value = group.toYValue(rodIndex);
                return BarTooltipItem(
                  text: '$category: ${value?.toInt() ?? 0}',
                );
              },
            ),
          ),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const style = TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  );
                  
                  switch (value.toInt()) {
                    case 0:
                      return const Text('Jami', style: style);
                    case 1:
                      return const Text('Faol', style: style);
                    case 2:
                      return const Text('Mijoz', style: style);
                    case 3:
                      return const Text('Admin', style: style);
                    default:
                      return const Text('', style: style);
                  }
                },
                reservedSize: 38,
                margin: 8,
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 40,
                interval: 1,
                getTitlesWidget: (value, meta) {
                  const style = TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  );
                  
                  return Text(
                    value.toInt().toString(),
                    style: style,
                    textAlign: TextAlign.left,
                  );
                },
              ),
            ),
          ),
          borderData: FlBorderData(
            show: false,
          ),
          barGroups: [
            // Total Users
            BarChartGroupData(
              x: 0,
              barRods: [
                BarChartRodData(
                  toY: totalUsers.toDouble(),
                  color: Colors.blue,
                  width: 22,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(4),
                    bottom: Radius.circular(4),
                  ),
                ),
              ],
            ),
            
            // Active Users
            BarChartGroupData(
              x: 1,
              barRods: [
                BarChartRodData(
                  toY: activeUsers.toDouble(),
                  color: Colors.green,
                  width: 22,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(4),
                    bottom: Radius.circular(4),
                  ),
                ),
              ],
            ),
            
            // Client Users
            BarChartGroupData(
              x: 2,
              barRods: [
                BarChartRodData(
                  toY: clientUsers.toDouble(),
                  color: Colors.orange,
                  width: 22,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(4),
                    bottom: Radius.circular(4),
                  ),
                ),
              ],
            ),
            
            // Admin Users
            BarChartGroupData(
              x: 3,
              barRods: [
                BarChartRodData(
                  toY: adminUsers.toDouble(),
                  color: Colors.purple,
                  width: 22,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(4),
                    bottom: Radius.circular(4),
                  ),
                ),
              ],
            ),
          ],
          gridData: FlGridData(
            show: true,
            drawVerticalLine: true,
            getDrawingHorizontalLine: (value) => FlLine(
              color: Colors.grey.withOpacity(0.3),
              strokeWidth: 1,
            ),
            getDrawingVerticalLine: (value) => FlLine(
              color: Colors.grey.withOpacity(0.3),
              strokeWidth: 1,
            ),
          ),
        ),
      ),
    );
  }

  String _getCategory(int index) {
    switch (index) {
      case 0:
        return 'Jami Foydalanuvchilar';
      case 1:
        return 'Faol Foydalanuvchilar';
      case 2:
        return 'Mijozlar';
      case 3:
        return 'Adminlar';
      default:
        return '';
    }
  }
}
