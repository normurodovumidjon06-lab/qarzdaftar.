import '../datasources/remote/api_service.dart';
import '../datasources/local/database_helper.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/logger.dart';
import '../../domain/entities/debt.dart';
import '../../domain/repositories/debt_repository.dart';

class DebtRepositoryImpl implements DebtRepository {
  final ApiService _apiService;
  final DatabaseHelper _databaseHelper;

  DebtRepositoryImpl({
    ApiService? apiService,
    DatabaseHelper? databaseHelper,
  })  : _apiService = apiService ?? ApiService(),
        _databaseHelper = databaseHelper ?? DatabaseHelper.instance;

  @override
  Future<Map<String, dynamic>> getDebts({
    int page = 1,
    int limit = 50,
    String? clientId,
    String? status,
    String? search,
    String? dateFrom,
    String? dateTo,
  }) async {
    try {
      Logger.database('Fetching debts: page=$page, limit=$limit');
      
      final response = await _apiService.getDebts(
        page: page,
        limit: limit,
        clientId: clientId,
        status: status,
        search: search,
        dateFrom: dateFrom,
        dateTo: dateTo,
      );

      if (response['success'] == true) {
        final debtsData = response['data'];
        final debts = debtsData['debts'] as List;
        
        // Cache debts locally
        await _cacheDebtsLocally(debts);
        
        Logger.database('Debts fetched and cached: ${debts.length}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch debts: $e');
      
      // Try to return cached data if API fails
      return _getCachedDebts(
        page: page,
        limit: limit,
        clientId: clientId,
        status: status,
        search: search,
        dateFrom: dateFrom,
        dateTo: dateTo,
      );
    }
  }

  @override
  Future<Map<String, dynamic>> getMyDebts() async {
    try {
      Logger.database('Fetching my debts');
      
      final response = await _apiService.getMyDebts();

      if (response['success'] == true) {
        final debtsData = response['data'];
        final debts = debtsData['debts'] as List;
        
        // Cache debts locally
        await _cacheDebtsLocally(debts);
        
        Logger.database('My debts fetched and cached: ${debts.length}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch my debts: $e');
      
      // Try to return cached data
      return _getCachedMyDebts();
    }
  }

  @override
  Future<Map<String, dynamic>> getDebt(String debtId) async {
    try {
      Logger.database('Fetching debt: $debtId');
      
      final response = await _apiService.getDebt(debtId);

      if (response['success'] == true) {
        final debtData = response['data'];
        
        // Cache debt locally
        await _cacheDebtLocally(debtData);
        
        Logger.database('Debt fetched and cached: $debtId');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch debt: $e');
      
      // Try to return cached data
      return _getCachedDebt(debtId);
    }
  }

  @override
  Future<Map<String, dynamic>> createDebt({
    required String clientId,
    required List items,
    required double totalAmount,
    required String dateIssued,
    required String dueDate,
  }) async {
    try {
      Logger.database('Creating debt for client: $clientId');
      
      final response = await _apiService.createDebt(
        clientId: clientId,
        items: items,
        totalAmount: totalAmount,
        dateIssued: dateIssued,
        dueDate: dueDate,
      );

      if (response['success'] == true) {
        final debtData = response['data'];
        
        // Cache debt locally
        await _cacheDebtLocally(debtData);
        
        Logger.database('Debt created and cached: ${debtData['id']}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to create debt: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> updateDebt(
    String debtId, {
    String? clientId,
    List? items,
    double? totalAmount,
    String? dateIssued,
    String? dueDate,
    String? status,
  }) async {
    try {
      Logger.database('Updating debt: $debtId');
      
      final response = await _apiService.updateDebt(
        debtId,
        clientId: clientId,
        items: items,
        totalAmount: totalAmount,
        dateIssued: dateIssued,
        dueDate: dueDate,
        status: status,
      );

      if (response['success'] == true) {
        final debtData = response['data'];
        
        // Update cached debt
        await _cacheDebtLocally(debtData);
        
        Logger.database('Debt updated and cached: $debtId');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to update debt: $e');
      
      // Queue update for sync when online
      await _queueDebtUpdate(debtId, {
        'clientId': clientId,
        'items': items,
        'totalAmount': totalAmount,
        'dateIssued': dateIssued,
        'dueDate': dueDate,
        'status': status,
      });
      
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> markDebtAsPaid(String debtId) async {
    try {
      Logger.database('Marking debt as paid: $debtId');
      
      final response = await _apiService.markDebtAsPaid(debtId);

      if (response['success'] == true) {
        // Update local status
        await _updateDebtStatusLocally(debtId, AppConstants.debtStatusPaid);
        
        Logger.database('Debt marked as paid locally: $debtId');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to mark debt as paid: $e');
      
      // Queue status update for sync
      await _queueDebtStatusUpdate(debtId, AppConstants.debtStatusPaid);
      
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> markDebtAsDefaulted(String debtId) async {
    try {
      Logger.database('Marking debt as defaulted: $debtId');
      
      final response = await _apiService.markDebtAsDefaulted(debtId);

      if (response['success'] == true) {
        // Update local status
        await _updateDebtStatusLocally(debtId, AppConstants.debtStatusDefaulted);
        
        Logger.database('Debt marked as defaulted locally: $debtId');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to mark debt as defaulted: $e');
      
      // Queue status update for sync
      await _queueDebtStatusUpdate(debtId, AppConstants.debtStatusDefaulted);
      
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> triggerHardwareShock(String debtId) async {
    try {
      Logger.database('Triggering hardware shock for debt: $debtId');
      
      final response = await _apiService.triggerHardwareShock(debtId);
      
      if (response['success'] == true) {
        Logger.database('Hardware shock triggered: $debtId');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to trigger hardware shock: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> getDebtStats() async {
    try {
      Logger.database('Fetching debt statistics');
      
      final response = await _apiService.getDebtStats();
      
      if (response['success'] == true) {
        Logger.database('Debt statistics fetched');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch debt statistics: $e');
      
      // Return local statistics
      return _getLocalDebtStats();
    }
  }

  @override
  Future<Map<String, dynamic>> getOverdueDebts() async {
    try {
      Logger.database('Fetching overdue debts');
      
      final response = await _apiService.getOverdueDebts();

      if (response['success'] == true) {
        final debts = response['data'] as List;
        
        // Cache overdue debts
        await _cacheDebtsLocally(debts);
        
        Logger.database('Overdue debts fetched: ${debts.length}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch overdue debts: $e');
      
      // Return local overdue debts
      return _getLocalOverdueDebts();
    }
  }

  @override
  Future<Map<String, dynamic>> getDebtsDueIn7Days() async {
    try {
      Logger.database('Fetching debts due in 7 days');
      
      final response = await _apiService.getDebtsDueIn7Days();

      if (response['success'] == true) {
        final debts = response['data'] as List;
        
        // Cache debts
        await _cacheDebtsLocally(debts);
        
        Logger.database('Debts due in 7 days fetched: ${debts.length}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch debts due in 7 days: $e');
      
      // Return local debts due in 7 days
      return _getLocalDebtsDueIn7Days();
    }
  }

  @override
  Future<Map<String, dynamic>> getDebtsByClient(String clientId) async {
    try {
      Logger.database('Fetching debts for client: $clientId');
      
      final response = await _apiService.getDebtsByClient(clientId);

      if (response['success'] == true) {
        final debts = response['data'] as List;
        
        // Cache debts
        await _cacheDebtsLocally(debts);
        
        Logger.database('Client debts fetched: ${debts.length}');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch client debts: $e');
      
      // Return local client debts
      return _getLocalDebtsByClient(clientId);
    }
  }

  // Private helper methods for local caching
  Future<void> _cacheDebtsLocally(List debts) async {
    try {
      await _databaseHelper.batch((batch) async {
        for (final debtData in debts) {
          final debt = Debt.fromJson(debtData);
          await batch.insert(
            DatabaseTables.debts,
            debt.toJson(),
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      });
    } catch (e) {
      Logger.error('Failed to cache debts locally: $e');
    }
  }

  Future<void> _cacheDebtLocally(Map<String, dynamic> debtData) async {
    try {
      final debt = Debt.fromJson(debtData);
      
      await _databaseHelper.insert(
        DatabaseTables.debts,
        debt.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      Logger.error('Failed to cache debt locally: $e');
    }
  }

  Future<void> _updateDebtStatusLocally(String debtId, String status) async {
    try {
      await _databaseHelper.update(
        DatabaseTables.debts,
        {'status': status, 'updatedAt': DateTime.now().toIso8601String()},
        where: 'id = ?',
        whereArgs: [debtId],
      );
    } catch (e) {
      Logger.error('Failed to update debt status locally: $e');
    }
  }

  Future<void> _queueDebtUpdate(String debtId, Map<String, dynamic> updateData) async {
    try {
      await _databaseHelper.insert(DatabaseTables.syncQueue, {
        'endpoint': '${ApiEndpoints.debts}/$debtId',
        'method': 'PATCH',
        'data': updateData.toString(),
        'status': 'pending',
        'createdAt': DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      Logger.error('Failed to queue debt update: $e');
    }
  }

  Future<void> _queueDebtStatusUpdate(String debtId, String status) async {
    try {
      final endpoint = status == AppConstants.debtStatusPaid 
          ? '${ApiEndpoints.debts}/$debtId/mark-paid'
          : '${ApiEndpoints.debts}/$debtId/mark-defaulted';
      
      await _databaseHelper.insert(DatabaseTables.syncQueue, {
        'endpoint': endpoint,
        'method': 'PATCH',
        'status': 'pending',
        'createdAt': DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      Logger.error('Failed to queue debt status update: $e');
    }
  }

  // Offline data retrieval methods
  Future<Map<String, dynamic>> _getCachedDebts({
    int page = 1,
    int limit = 50,
    String? clientId,
    String? status,
    String? search,
    String? dateFrom,
    String? dateTo,
  }) async {
    try {
      String whereClause = '1=1';
      List<dynamic> whereArgs = [];

      if (clientId != null) {
        whereClause += ' AND clientId = ?';
        whereArgs.add(clientId);
      }

      if (status != null) {
        whereClause += ' AND status = ?';
        whereArgs.add(status);
      }

      if (search != null) {
        whereClause += ' AND (items LIKE ? OR id LIKE ?)';
        whereArgs.addAll(['%$search%', '%$search%']);
      }

      if (dateFrom != null) {
        whereClause += ' AND dateIssued >= ?';
        whereArgs.add(dateFrom);
      }

      if (dateTo != null) {
        whereClause += ' AND dateIssued <= ?';
        whereArgs.add(dateTo);
      }

      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: whereClause,
        whereArgs: whereArgs,
        orderBy: 'createdAt DESC',
        limit: limit,
        offset: (page - 1) * limit,
      );

      return {
        'success': true,
        'data': {
          'debts': debts,
          'pagination': {
            'page': page,
            'limit': limit,
            'total': debts.length,
            'pages': (debts.length / limit).ceil(),
          },
        },
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get cached debts: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }

  Future<Map<String, dynamic>> _getCachedMyDebts() async {
    try {
      final userId = await StorageService.getCurrentUserId();
      
      if (userId == null) {
        return {'success': false, 'message': 'User not logged in'};
      }

      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: 'clientId = ?',
        whereArgs: [userId],
        orderBy: 'createdAt DESC',
      );

      return {
        'success': true,
        'data': {'debts': debts},
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get cached my debts: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }

  Future<Map<String, dynamic>> _getCachedDebt(String debtId) async {
    try {
      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: 'id = ?',
        whereArgs: [debtId],
      );

      if (debts.isNotEmpty) {
        return {
          'success': true,
          'data': debts.first,
          'cached': true,
        };
      }

      return {'success': false, 'message': 'Debt not found locally'};
    } catch (e) {
      Logger.error('Failed to get cached debt: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }

  Future<Map<String, dynamic>> _getLocalDebtStats() async {
    try {
      final totalDebts = await _databaseHelper.getTableCount(DatabaseTables.debts);
      
      final activeDebts = await _databaseHelper.query(
        DatabaseTables.debts,
        columns: ['COUNT(*) as count'],
        where: 'status = ?',
        whereArgs: [AppConstants.debtStatusActive],
      );
      
      final paidDebts = await _databaseHelper.query(
        DatabaseTables.debts,
        columns: ['COUNT(*) as count'],
        where: 'status = ?',
        whereArgs: [AppConstants.debtStatusPaid],
      );
      
      final defaultedDebts = await _databaseHelper.query(
        DatabaseTables.debts,
        columns: ['COUNT(*) as count'],
        where: 'status = ?',
        whereArgs: [AppConstants.debtStatusDefaulted],
      );

      final totalAmountResult = await _databaseHelper.query(
        DatabaseTables.debts,
        columns: ['SUM(totalAmount) as total'],
      );

      return {
        'success': true,
        'data': {
          'totalDebts': totalDebts,
          'activeDebts': activeDebts.first['count'],
          'paidDebts': paidDebts.first['count'],
          'defaultedDebts': defaultedDebts.first['count'],
          'totalAmount': totalAmountResult.first['total'] ?? 0.0,
        },
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get local debt stats: $e');
      return {'success': false, 'message': 'Failed to load local statistics'};
    }
  }

  Future<Map<String, dynamic>> _getLocalOverdueDebts() async {
    try {
      final now = DateTime.now().toIso8601String();
      
      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: 'dueDate < ? AND status = ?',
        whereArgs: [now, AppConstants.debtStatusActive],
        orderBy: 'dueDate ASC',
      );

      return {
        'success': true,
        'data': debts,
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get local overdue debts: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }

  Future<Map<String, dynamic>> _getLocalDebtsDueIn7Days() async {
    try {
      final now = DateTime.now();
      final sevenDaysFromNow = now.add(const Duration(days: 7)).toIso8601String();
      
      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: 'dueDate >= ? AND dueDate <= ? AND status = ?',
        whereArgs: [now.toIso8601String(), sevenDaysFromNow, AppConstants.debtStatusActive],
        orderBy: 'dueDate ASC',
      );

      return {
        'success': true,
        'data': debts,
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get local debts due in 7 days: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }

  Future<Map<String, dynamic>> _getLocalDebtsByClient(String clientId) async {
    try {
      final debts = await _databaseHelper.query(
        DatabaseTables.debts,
        where: 'clientId = ?',
        whereArgs: [clientId],
        orderBy: 'createdAt DESC',
      );

      return {
        'success': true,
        'data': debts,
        'cached': true,
      };
    } catch (e) {
      Logger.error('Failed to get local client debts: $e');
      return {'success': false, 'message': 'Failed to load cached data'};
    }
  }
}
