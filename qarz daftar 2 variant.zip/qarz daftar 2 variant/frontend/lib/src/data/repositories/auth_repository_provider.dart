import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'auth_repository.dart';

// Provider for AuthRepository
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepositoryImpl();
});

// Provider for AuthRepository with custom dependencies (for testing)
final authRepositoryProviderWithDeps = Provider.family<AuthRepository, AuthRepositoryDependencies>(
  (ref, deps) {
    return AuthRepositoryImpl(
      apiService: deps.apiService,
      databaseHelper: deps.databaseHelper,
    );
  },
);

class AuthRepositoryDependencies {
  final ApiService? apiService;
  final DatabaseHelper? databaseHelper;

  const AuthRepositoryDependencies({
    this.apiService,
    this.databaseHelper,
  });
}
