import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'debt_repository.dart';

// Provider for DebtRepository
final debtRepositoryProvider = Provider<DebtRepository>((ref) {
  return DebtRepositoryImpl();
});

// Provider for DebtRepository with custom dependencies (for testing)
final debtRepositoryProviderWithDeps = Provider.family<DebtRepository, DebtRepositoryDependencies>(
  (ref, deps) {
    return DebtRepositoryImpl(
      apiService: deps.apiService,
      databaseHelper: deps.databaseHelper,
    );
  },
);

class DebtRepositoryDependencies {
  final ApiService? apiService;
  final DatabaseHelper? databaseHelper;

  const DebtRepositoryDependencies({
    this.apiService,
    this.databaseHelper,
  });
}
