import '../datasources/remote/api_service.dart';
import '../datasources/local/storage_service.dart';
import '../datasources/local/database_helper.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/logger.dart';
import '../../domain/entities/user.dart';
import '../../domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final ApiService _apiService;
  final DatabaseHelper _databaseHelper;

  AuthRepositoryImpl({
    ApiService? apiService,
    DatabaseHelper? databaseHelper,
  })  : _apiService = apiService ?? ApiService(),
        _databaseHelper = databaseHelper ?? DatabaseHelper.instance;

  @override
  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
    String? deviceToken,
  }) async {
    try {
      Logger.auth('Attempting login for phone: $phone');
      
      final response = await _apiService.login(
        phone: phone,
        password: password,
        deviceToken: deviceToken,
      );

      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        
        // Save user to local database
        await _saveUserLocally(user);
        
        Logger.auth('Login successful for user: ${user['id']}');
      }

      return response;
    } catch (e) {
      Logger.error('Login failed: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> register({
    required String phone,
    required String password,
    required String fullName,
    String? mahalla,
    String? role,
  }) async {
    try {
      Logger.auth('Attempting registration for phone: $phone');
      
      final response = await _apiService.register(
        phone: phone,
        password: password,
        fullName: fullName,
        mahalla: mahalla,
        role: role ?? AppConstants.clientRole,
      );

      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        
        // Save user to local database
        await _saveUserLocally(user);
        
        Logger.auth('Registration successful for user: ${user['id']}');
      }

      return response;
    } catch (e) {
      Logger.error('Registration failed: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> refreshToken(String refreshToken) async {
    try {
      Logger.auth('Attempting token refresh');
      
      final response = await _apiService.refreshToken(refreshToken);

      if (response['success'] == true) {
        final userData = response['data'];
        final user = userData['user'];
        
        // Update user in local database
        await _saveUserLocally(user);
        
        Logger.auth('Token refresh successful for user: ${user['id']}');
      }

      return response;
    } catch (e) {
      Logger.error('Token refresh failed: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> logout() async {
    try {
      Logger.auth('Attempting logout');
      
      // Call logout API
      final response = await _apiService.logout();
      
      // Clear local data
      await _clearLocalData();
      
      Logger.auth('Logout completed');
      return response;
    } catch (e) {
      Logger.error('Logout API call failed: $e');
      // Even if API call fails, clear local data
      await _clearLocalData();
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> getProfile() async {
    try {
      Logger.auth('Fetching user profile');
      
      final response = await _apiService.getProfile();

      if (response['success'] == true) {
        final user = response['data'];
        
        // Update user in local database
        await _saveUserLocally(user);
        
        Logger.auth('Profile fetched successfully');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to fetch profile: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> updateProfile({
    required String userId,
    String? fullName,
    String? mahalla,
  }) async {
    try {
      Logger.auth('Updating profile for user: $userId');
      
      final response = await _apiService.updateProfile(
        userId: userId,
        fullName: fullName,
        mahalla: mahalla,
      );

      if (response['success'] == true) {
        final updatedUser = response['data'];
        
        // Update user in local database
        await _saveUserLocally(updatedUser);
        
        Logger.auth('Profile updated successfully');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to update profile: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      Logger.auth('Changing password');
      
      final response = await _apiService.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );

      if (response['success'] == true) {
        Logger.auth('Password changed successfully');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to change password: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> validateTokens() async {
    try {
      Logger.auth('Validating tokens');
      
      final response = await _apiService.validateTokens();
      
      if (response['success'] == true) {
        Logger.auth('Tokens are valid');
      } else {
        Logger.auth('Tokens are invalid');
      }

      return response;
    } catch (e) {
      Logger.error('Token validation failed: $e');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> updateDeviceToken(String deviceToken) async {
    try {
      Logger.auth('Updating device token');
      
      final response = await _apiService.updateDeviceToken(deviceToken);

      if (response['success'] == true) {
        // Save FCM token locally
        await StorageService.saveFCMToken(deviceToken);
        Logger.auth('Device token updated successfully');
      }

      return response;
    } catch (e) {
      Logger.error('Failed to update device token: $e');
      rethrow;
    }
  }

  @override
  Future<User?> getCurrentUser() async {
    try {
      final userId = await StorageService.getCurrentUserId();
      
      if (userId == null) {
        Logger.auth('No current user found');
        return null;
      }

      // Try to get user from local database first
      final localUsers = await _databaseHelper.query(
        DatabaseTables.users,
        where: 'id = ?',
        whereArgs: [userId],
      );

      if (localUsers.isNotEmpty) {
        final userData = localUsers.first;
        Logger.auth('Current user loaded from local database');
        return User.fromJson(userData);
      }

      // If not found locally, try to fetch from API
      Logger.auth('User not found locally, fetching from API');
      final response = await getProfile();
      
      if (response['success'] == true) {
        return User.fromJson(response['data']);
      }

      return null;
    } catch (e) {
      Logger.error('Failed to get current user: $e');
      return null;
    }
  }

  @override
  Future<bool> isLoggedIn() async {
    try {
      final isLoggedIn = await StorageService.isLoggedIn();
      Logger.auth('Login status check: $isLoggedIn');
      return isLoggedIn;
    } catch (e) {
      Logger.error('Failed to check login status: $e');
      return false;
    }
  }

  @override
  Future<String?> getCurrentUserId() async {
    try {
      return await StorageService.getCurrentUserId();
    } catch (e) {
      Logger.error('Failed to get current user ID: $e');
      return null;
    }
  }

  @override
  Future<String?> getCurrentUserRole() async {
    try {
      return await StorageService.getCurrentUserRole();
    } catch (e) {
      Logger.error('Failed to get current user role: $e');
      return null;
    }
  }

  @override
  Future<void> clearAuthData() async {
    try {
      await _clearLocalData();
      Logger.auth('Auth data cleared');
    } catch (e) {
      Logger.error('Failed to clear auth data: $e');
      rethrow;
    }
  }

  // Private helper methods
  Future<void> _saveUserLocally(Map<String, dynamic> userData) async {
    try {
      final user = User.fromJson(userData);
      
      await _databaseHelper.insert(
        DatabaseTables.users,
        user.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      
      Logger.database('User saved locally: ${user.id}');
    } catch (e) {
      Logger.error('Failed to save user locally: $e');
      // Don't rethrow here as this is not critical for the main operation
    }
  }

  Future<void> _clearLocalData() async {
    try {
      // Clear secure storage
      await StorageService.clearAuthTokens();
      
      // Clear user data from local database
      await _databaseHelper.delete(DatabaseTables.users);
      
      Logger.auth('Local auth data cleared');
    } catch (e) {
      Logger.error('Failed to clear local auth data: $e');
      // Don't rethrow here as we want to continue with logout
    }
  }

  // Offline support methods
  Future<void> cacheAuthData(Map<String, dynamic> authData) async {
    try {
      final user = authData['user'];
      if (user != null) {
        await _saveUserLocally(user);
      }
      
      Logger.auth('Auth data cached for offline use');
    } catch (e) {
      Logger.error('Failed to cache auth data: $e');
    }
  }

  Future<Map<String, dynamic>?> getCachedAuthData() async {
    try {
      final userId = await StorageService.getCurrentUserId();
      
      if (userId == null) {
        return null;
      }

      final localUsers = await _databaseHelper.query(
        DatabaseTables.users,
        where: 'id = ?',
        whereArgs: [userId],
      );

      if (localUsers.isNotEmpty) {
        return {'user': localUsers.first};
      }

      return null;
    } catch (e) {
      Logger.error('Failed to get cached auth data: $e');
      return null;
    }
  }
}
