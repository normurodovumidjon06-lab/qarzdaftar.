import 'package:dio/dio.dart';
import '../../../core/utils/logger.dart';

class LoggingInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    Logger.network(
      '${options.method} ${options.uri}',
      options.headers['Authorization']?.toString().replaceAll(RegExp(r'Bearer\s+'), 'Bearer ***') ?? 'No Auth',
    );
    
    if (options.data != null) {
      Logger.network('Request Data: ${options.data}');
    }
    
    if (options.queryParameters.isNotEmpty) {
      Logger.network('Query Parameters: ${options.queryParameters}');
    }
    
    handler.next(options);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    Logger.network(
      'Response: ${response.statusCode} ${response.requestOptions.method} ${response.requestOptions.uri}',
    );
    
    // Log response data only in debug mode and if it's not too large
    if (AppConstants.enableDebugLogs && response.data != null) {
      final dataString = response.data.toString();
      if (dataString.length < 1000) {
        Logger.network('Response Data: ${response.data}');
      } else {
        Logger.network('Response Data: [Large data - ${dataString.length} characters]');
      }
    }
    
    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    Logger.network(
      'Error: ${err.response?.statusCode ?? 'No Status'} ${err.requestOptions.method} ${err.requestOptions.uri}',
    );
    
    if (err.response?.data != null) {
      Logger.network('Error Response: ${err.response?.data}');
    }
    
    Logger.network('Error Message: ${err.message}');
    
    handler.next(err);
  }
}
