import 'package:dio/dio.dart';
import '../../../core/utils/logger.dart';
import '../../../core/constants/app_constants.dart';

class ErrorInterceptor extends Interceptor {
  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    String errorMessage = 'An unexpected error occurred';
    
    switch (err.type) {
      case DioExceptionType.connectionTimeout:
        errorMessage = AppConstants.networkErrorMessage;
        break;
      case DioExceptionType.sendTimeout:
        errorMessage = AppConstants.networkErrorMessage;
        break;
      case DioExceptionType.receiveTimeout:
        errorMessage = AppConstants.networkErrorMessage;
        break;
      case DioExceptionType.badResponse:
        errorMessage = _handleHttpError(err.response?.statusCode ?? 0, err.response?.data);
        break;
      case DioExceptionType.cancel:
        errorMessage = 'Request was cancelled';
        break;
      case DioExceptionType.connectionError:
        errorMessage = AppConstants.networkErrorMessage;
        break;
      case DioExceptionType.badCertificate:
        errorMessage = 'SSL Certificate error';
        break;
      case DioExceptionType.unknown:
        errorMessage = err.message ?? 'Unknown error occurred';
        break;
    }
    
    Logger.error('API Error: $errorMessage');
    Logger.error('Error details: ${err.toString()}');
    
    // Create a custom error response with user-friendly message
    final customError = DioException(
      requestOptions: err.requestOptions,
      response: err.response?.copyWith(
        data: {
          'success': false,
          'message': errorMessage,
          'error': err.type.toString(),
          'statusCode': err.response?.statusCode,
        },
      ),
      type: err.type,
      message: errorMessage,
    );
    
    handler.reject(customError);
  }
  
  String _handleHttpError(int statusCode, dynamic responseData) {
    switch (statusCode) {
      case 400:
        return responseData?['message'] ?? AppConstants.validationErrorMessage;
      case 401:
        return responseData?['message'] ?? AppConstants.unauthorizedErrorMessage;
      case 403:
        return responseData?['message'] ?? AppConstants.forbiddenErrorMessage;
      case 404:
        return responseData?['message'] ?? AppConstants.notFoundErrorMessage;
      case 422:
        return responseData?['message'] ?? AppConstants.validationErrorMessage;
      case 429:
        return 'Too many requests. Please try again later.';
      case 500:
        return AppConstants.serverErrorMessage;
      case 502:
        return AppConstants.serverErrorMessage;
      case 503:
        return AppConstants.serverErrorMessage;
      case 504:
        return 'Request timeout. Please try again.';
      default:
        if (responseData is Map<String, dynamic>) {
          return responseData['message'] ?? responseData['error'] ?? 'Server error occurred';
        }
        return 'HTTP Error: $statusCode';
    }
  }
}
