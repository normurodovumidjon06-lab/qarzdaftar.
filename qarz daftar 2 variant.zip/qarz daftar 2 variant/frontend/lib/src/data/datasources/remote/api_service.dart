import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/logger.dart';
import '../local/storage_service.dart';
import 'interceptors/auth_interceptor.dart';
import 'interceptors/error_interceptor.dart';
import 'interceptors/logging_interceptor.dart';

class ApiService {
  late Dio _dio;
  static final ApiService _instance = ApiService._internal();
  
  factory ApiService() => _instance;
  ApiService._internal() {
    _initializeDio();
  }

  void _initializeDio() {
    _dio = Dio(BaseOptions(
      baseUrl: AppConstants.apiBaseUrl,
      connectTimeout: AppConstants.apiTimeout,
      receiveTimeout: AppConstants.apiTimeout,
      sendTimeout: AppConstants.apiTimeout,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ));

    // Add interceptors
    _dio.interceptors.add(AuthInterceptor());
    _dio.interceptors.add(ErrorInterceptor());
    
    // Add logging interceptor in debug mode
    if (AppConstants.enableDebugLogs) {
      _dio.interceptors.add(PrettyDioLogger(
        requestHeader: true,
        requestBody: true,
        responseHeader: true,
        responseBody: true,
        error: true,
        compact: true,
        maxWidth: 90,
      ));
    }
    
    Logger.network('API Service initialized');
  }

  // Generic HTTP methods
  Future<Map<String, dynamic>> get(
    String path, {
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.get(
        path,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('GET', path, response.statusCode, response.data);
      return _handleResponse(response);
    } catch (e) {
      Logger.error('GET request failed: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> post(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.post(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('POST', path, response.statusCode, response.data);
      return _handleResponse(response);
    } catch (e) {
      Logger.error('POST request failed: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> put(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.put(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('PUT', path, response.statusCode, response.data);
      return _handleResponse(response);
    } catch (e) {
      Logger.error('PUT request failed: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> patch(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.patch(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('PATCH', path, response.statusCode, response.data);
      return _handleResponse(response);
    } catch (e) {
      Logger.error('PATCH request failed: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> delete(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.delete(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('DELETE', path, response.statusCode, response.data);
      return _handleResponse(response);
    } catch (e) {
      Logger.error('DELETE request failed: $e');
      rethrow;
    }
  }

  Future<Response> download(
    String urlPath,
    String savePath, {
    ProgressCallback? onReceiveProgress,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.download(
        urlPath,
        savePath,
        onReceiveProgress: onReceiveProgress,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('DOWNLOAD', urlPath, response.statusCode, 'File downloaded');
      return response;
    } catch (e) {
      Logger.error('DOWNLOAD request failed: $e');
      rethrow;
    }
  }

  Future<Response> upload(
    String path,
    FormData formData, {
    ProgressCallback? onSendProgress,
    Map<String, dynamic>? queryParameters,
    Options? options,
  }) async {
    try {
      final response = await _dio.post(
        path,
        data: formData,
        onSendProgress: onSendProgress,
        queryParameters: queryParameters,
        options: options,
      );
      
      Logger.network('UPLOAD', path, response.statusCode, response.data);
      return response;
    } catch (e) {
      Logger.error('UPLOAD request failed: $e');
      rethrow;
    }
  }

  Map<String, dynamic> _handleResponse(Response response) {
    if (response.statusCode! >= 200 && response.statusCode! < 300) {
      return response.data is Map<String, dynamic> 
          ? response.data 
          : {'data': response.data, 'success': true};
    } else {
      throw DioException(
        requestOptions: response.requestOptions,
        response: response,
        message: 'Request failed with status ${response.statusCode}',
      );
    }
  }

  // Authentication methods
  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
    String? deviceToken,
  }) async {
    return post(
      ApiEndpoints.login,
      data: {
        'phone': phone,
        'password': password,
        if (deviceToken != null) 'deviceToken': deviceToken,
      },
    );
  }

  Future<Map<String, dynamic>> register({
    required String phone,
    required String password,
    required String fullName,
    String? mahalla,
    String? role,
  }) async {
    return post(
      ApiEndpoints.register,
      data: {
        'phone': phone,
        'password': password,
        'fullName': fullName,
        if (mahalla != null) 'mahalla': mahalla,
        if (role != null) 'role': role,
      },
    );
  }

  Future<Map<String, dynamic>> refreshToken(String refreshToken) async {
    return post(
      ApiEndpoints.refreshToken,
      data: {'refreshToken': refreshToken},
    );
  }

  Future<Map<String, dynamic>> logout() async {
    return post(ApiEndpoints.logout);
  }

  Future<Map<String, dynamic>> getProfile() async {
    return get(ApiEndpoints.profile);
  }

  Future<Map<String, dynamic>> updateProfile({
    required String userId,
    String? fullName,
    String? mahalla,
  }) async {
    return patch(
      '${ApiEndpoints.users}/$userId',
      data: {
        if (fullName != null) 'fullName': fullName,
        if (mahalla != null) 'mahalla': mahalla,
      },
    );
  }

  Future<Map<String, dynamic>> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    return post(
      '${ApiEndpoints.auth}/change-password',
      data: {
        'currentPassword': currentPassword,
        'newPassword': newPassword,
      },
    );
  }

  Future<Map<String, dynamic>> validateTokens() async {
    return get(ApiEndpoints.profile);
  }

  Future<Map<String, dynamic>> updateDeviceToken(String deviceToken) async {
    return post(
      '${ApiEndpoints.auth}/update-device-token',
      data: {'deviceToken': deviceToken},
    );
  }

  // User management methods (Admin only)
  Future<Map<String, dynamic>> getUsers({
    int page = 1,
    int limit = 50,
    String? role,
    String? search,
    bool? isActive,
  }) async {
    return get(
      ApiEndpoints.users,
      queryParameters: {
        'page': page,
        'limit': limit,
        if (role != null) 'role': role,
        if (search != null) 'search': search,
        if (isActive != null) 'isActive': isActive,
      },
    );
  }

  Future<Map<String, dynamic>> getUserStats() async {
    return get('${ApiEndpoints.users}/stats');
  }

  Future<Map<String, dynamic>> createUser({
    required String phone,
    required String password,
    required String fullName,
    String? mahalla,
    String? role,
  }) async {
    return post(
      ApiEndpoints.users,
      data: {
        'phone': phone,
        'password': password,
        'fullName': fullName,
        if (mahalla != null) 'mahalla': mahalla,
        if (role != null) 'role': role,
      },
    );
  }

  Future<Map<String, dynamic>> updateUser(
    String userId, {
    String? phone,
    String? fullName,
    String? mahalla,
    String? role,
    bool? isActive,
  }) async {
    return patch(
      '${ApiEndpoints.users}/$userId',
      data: {
        if (phone != null) 'phone': phone,
        if (fullName != null) 'fullName': fullName,
        if (mahalla != null) 'mahalla': mahalla,
        if (role != null) 'role': role,
        if (isActive != null) 'isActive': isActive,
      },
    );
  }

  Future<Map<String, dynamic>> deactivateUser(String userId) async {
    return patch('${ApiEndpoints.users}/$userId/deactivate');
  }

  Future<Map<String, dynamic>> activateUser(String userId) async {
    return patch('${ApiEndpoints.users}/$userId/activate');
  }

  // Debt management methods
  Future<Map<String, dynamic>> getDebts({
    int page = 1,
    int limit = 50,
    String? clientId,
    String? status,
    String? search,
    String? dateFrom,
    String? dateTo,
  }) async {
    return get(
      ApiEndpoints.debts,
      queryParameters: {
        'page': page,
        'limit': limit,
        if (clientId != null) 'clientId': clientId,
        if (status != null) 'status': status,
        if (search != null) 'search': search,
        if (dateFrom != null) 'dateFrom': dateFrom,
        if (dateTo != null) 'dateTo': dateTo,
      },
    );
  }

  Future<Map<String, dynamic>> getMyDebts() async {
    return get(ApiEndpoints.myDebts);
  }

  Future<Map<String, dynamic>> getDebt(String debtId) async {
    return get('${ApiEndpoints.debts}/$debtId');
  }

  Future<Map<String, dynamic>> createDebt({
    required String clientId,
    required List items,
    required double totalAmount,
    required String dateIssued,
    required String dueDate,
  }) async {
    return post(
      ApiEndpoints.debts,
      data: {
        'clientId': clientId,
        'items': items,
        'totalAmount': totalAmount,
        'dateIssued': dateIssued,
        'dueDate': dueDate,
      },
    );
  }

  Future<Map<String, dynamic>> updateDebt(
    String debtId, {
    String? clientId,
    List? items,
    double? totalAmount,
    String? dateIssued,
    String? dueDate,
    String? status,
  }) async {
    return patch(
      '${ApiEndpoints.debts}/$debtId',
      data: {
        if (clientId != null) 'clientId': clientId,
        if (items != null) 'items': items,
        if (totalAmount != null) 'totalAmount': totalAmount,
        if (dateIssued != null) 'dateIssued': dateIssued,
        if (dueDate != null) 'dueDate': dueDate,
        if (status != null) 'status': status,
      },
    );
  }

  Future<Map<String, dynamic>> markDebtAsPaid(String debtId) async {
    return patch('${ApiEndpoints.debts}/$debtId/mark-paid');
  }

  Future<Map<String, dynamic>> markDebtAsDefaulted(String debtId) async {
    return patch('${ApiEndpoints.debts}/$debtId/mark-defaulted');
  }

  Future<Map<String, dynamic>> triggerHardwareShock(String debtId) async {
    return post('${ApiEndpoints.debts}/$debtId/trigger-hardware-shock');
  }

  Future<Map<String, dynamic>> getDebtStats() async {
    return get(ApiEndpoints.debtStats);
  }

  Future<Map<String, dynamic>> getOverdueDebts() async {
    return get(ApiEndpoints.overdueDebts);
  }

  Future<Map<String, dynamic>> getDebtsDueIn7Days() async {
    return get(ApiEndpoints.debtsDueIn7Days);
  }

  Future<Map<String, dynamic>> getDebtsByClient(String clientId) async {
    return get('${ApiEndpoints.debts}/client/$clientId');
  }

  // Collection methods
  Future<Map<String, dynamic>> triggerCollectionPipeline({int daysAhead = 7}) async {
    return post(
      ApiEndpoints.triggerCollection,
      queryParameters: {'daysAhead': daysAhead},
    );
  }

  Future<Map<String, dynamic>> getCollectionStats() async {
    return get(ApiEndpoints.collectionStats);
  }

  // Admin methods
  Future<Map<String, dynamic>> getAdminDashboard() async {
    return get(ApiEndpoints.adminDashboard);
  }

  Future<Map<String, dynamic>> getAuditLogs({
    int page = 1,
    int limit = 50,
    String? userId,
    String? entity,
    String? entityId,
  }) async {
    return get(
      ApiEndpoints.adminAuditLogs,
      queryParameters: {
        'page': page,
        'limit': limit,
        if (userId != null) 'userId': userId,
        if (entity != null) 'entity': entity,
        if (entityId != null) 'entityId': entityId,
      },
    );
  }

  Future<Map<String, dynamic>> triggerPanicButton() async {
    return post(ApiEndpoints.adminPanicButton);
  }

  Future<Map<String, dynamic>> getSystemHealth() async {
    return get(ApiEndpoints.adminHealth);
  }

  // Utility methods
  void cancelRequests() {
    _dio.close(force: true);
    Logger.network('All requests cancelled');
  }

  Dio get dio => _dio;
}
