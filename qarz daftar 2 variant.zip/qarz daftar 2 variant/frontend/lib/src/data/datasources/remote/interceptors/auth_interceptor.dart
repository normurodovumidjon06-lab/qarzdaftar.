import 'package:dio/dio.dart';
import '../../../core/utils/logger.dart';
import '../../../data/datasources/local/storage_service.dart';
import '../../../core/constants/app_constants.dart';
import '../api_service.dart';

class AuthInterceptor extends Interceptor {
  final ApiService _apiService = ApiService();
  bool _isRefreshing = false;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    // Add authorization header if token exists
    final token = StorageService.getSecureString(AppConstants.accessTokenKey);
    
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
      Logger.auth('Auth header added to request');
    }
    
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    // Check if error is 401 Unauthorized
    if (err.response?.statusCode == 401 && !_isRefreshing) {
      Logger.auth('Received 401, attempting token refresh');
      
      // Try to refresh the token
      final refreshToken = await StorageService.getSecureString(AppConstants.refreshTokenKey);
      
      if (refreshToken != null) {
        try {
          _isRefreshing = true;
          
          // Call refresh token endpoint
          final response = await _apiService.refreshToken(refreshToken);
          
          if (response['success'] == true) {
            final userData = response['data'];
            final user = userData['user'];
            final tokens = userData;
            
            // Save new tokens
            await StorageService.saveAuthTokens(
              accessToken: tokens['accessToken'],
              refreshToken: tokens['refreshToken'],
              userId: user['id'],
              userRole: user['role'],
            );
            
            Logger.auth('Token refreshed successfully');
            
            // Retry the original request with new token
            final newToken = tokens['accessToken'];
            err.requestOptions.headers['Authorization'] = 'Bearer $newToken';
            
            try {
              final response = await _apiService._dio.fetch(err.requestOptions);
              handler.resolve(response);
              return;
            } catch (retryError) {
              Logger.error('Retry failed after token refresh: $retryError');
            }
          } else {
            Logger.warning('Token refresh failed: ${response['message']}');
          }
        } catch (refreshError) {
          Logger.error('Error during token refresh: $refreshError');
        } finally {
          _isRefreshing = false;
        }
      }
      
      // If refresh failed or no refresh token, clear auth and redirect to login
      await StorageService.clearAuthTokens();
      Logger.auth('Authentication cleared due to failed refresh');
      
      // Create a new DioException with a custom message
      final authError = DioException(
        requestOptions: err.requestOptions,
        response: err.response,
        type: DioExceptionType.unknown,
        message: 'Authentication failed. Please login again.',
      );
      
      handler.reject(authError);
      return;
    }
    
    // For other errors, just pass them through
    handler.next(err);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    // Check if response contains new tokens (after login/refresh)
    if (response.data is Map<String, dynamic>) {
      final data = response.data as Map<String, dynamic>;
      
      // Handle login/register responses
      if (data.containsKey('accessToken') && data.containsKey('refreshToken')) {
        Logger.auth('New tokens received in response');
        
        // Tokens are handled by the auth provider, so we just log here
      }
      
      // Handle token refresh responses
      if (data['data']?['accessToken'] != null) {
        Logger.auth('Token refresh response received');
      }
    }
    
    handler.next(response);
  }
}
