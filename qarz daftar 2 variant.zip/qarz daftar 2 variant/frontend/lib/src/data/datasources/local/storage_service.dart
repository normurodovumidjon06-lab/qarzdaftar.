import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/logger.dart';
import '../../core/constants/app_constants.dart';

class StorageService {
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage();
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      Logger.database('Storage service initialized');
    } catch (e) {
      Logger.error('Failed to initialize storage service: $e');
      rethrow;
    }
  }

  // Secure Storage Methods (for sensitive data)
  static Future<void> setSecureString(String key, String value) async {
    try {
      await _secureStorage.write(key: key, value: value);
      Logger.database('Secure storage set: $key');
    } catch (e) {
      Logger.error('Failed to set secure string for key $key: $e');
      rethrow;
    }
  }

  static Future<String?> getSecureString(String key) async {
    try {
      final value = await _secureStorage.read(key: key);
      Logger.database('Secure storage get: $key');
      return value;
    } catch (e) {
      Logger.error('Failed to get secure string for key $key: $e');
      return null;
    }
  }

  static Future<void> removeSecure(String key) async {
    try {
      await _secureStorage.delete(key: key);
      Logger.database('Secure storage removed: $key');
    } catch (e) {
      Logger.error('Failed to remove secure key $key: $e');
    }
  }

  static Future<void> clearSecure() async {
    try {
      await _secureStorage.deleteAll();
      Logger.database('Secure storage cleared');
    } catch (e) {
      Logger.error('Failed to clear secure storage: $e');
    }
  }

  // Shared Preferences Methods (for non-sensitive data)
  static Future<void> setString(String key, String value) async {
    try {
      await _prefs?.setString(key, value);
      Logger.database('Shared preferences set: $key');
    } catch (e) {
      Logger.error('Failed to set string for key $key: $e');
    }
  }

  static Future<String?> getString(String key) async {
    try {
      final value = _prefs?.getString(key);
      Logger.database('Shared preferences get: $key');
      return value;
    } catch (e) {
      Logger.error('Failed to get string for key $key: $e');
      return null;
    }
  }

  static Future<void> setBool(String key, bool value) async {
    try {
      await _prefs?.setBool(key, value);
      Logger.database('Shared preferences set bool: $key = $value');
    } catch (e) {
      Logger.error('Failed to set bool for key $key: $e');
    }
  }

  static Future<bool?> getBool(String key) async {
    try {
      final value = _prefs?.getBool(key);
      Logger.database('Shared preferences get bool: $key = $value');
      return value;
    } catch (e) {
      Logger.error('Failed to get bool for key $key: $e');
      return null;
    }
  }

  static Future<void> setInt(String key, int value) async {
    try {
      await _prefs?.setInt(key, value);
      Logger.database('Shared preferences set int: $key = $value');
    } catch (e) {
      Logger.error('Failed to set int for key $key: $e');
    }
  }

  static Future<int?> getInt(String key) async {
    try {
      final value = _prefs?.getInt(key);
      Logger.database('Shared preferences get int: $key = $value');
      return value;
    } catch (e) {
      Logger.error('Failed to get int for key $key: $e');
      return null;
    }
  }

  static Future<void> setDouble(String key, double value) async {
    try {
      await _prefs?.setDouble(key, value);
      Logger.database('Shared preferences set double: $key = $value');
    } catch (e) {
      Logger.error('Failed to set double for key $key: $e');
    }
  }

  static Future<double?> getDouble(String key) async {
    try {
      final value = _prefs?.getDouble(key);
      Logger.database('Shared preferences get double: $key = $value');
      return value;
    } catch (e) {
      Logger.error('Failed to get double for key $key: $e');
      return null;
    }
  }

  static Future<void> setStringList(String key, List<String> value) async {
    try {
      await _prefs?.setStringList(key, value);
      Logger.database('Shared preferences set string list: $key');
    } catch (e) {
      Logger.error('Failed to set string list for key $key: $e');
    }
  }

  static Future<List<String>?> getStringList(String key) async {
    try {
      final value = _prefs?.getStringList(key);
      Logger.database('Shared preferences get string list: $key');
      return value;
    } catch (e) {
      Logger.error('Failed to get string list for key $key: $e');
      return null;
    }
  }

  static Future<void> remove(String key) async {
    try {
      await _prefs?.remove(key);
      Logger.database('Shared preferences removed: $key');
    } catch (e) {
      Logger.error('Failed to remove key $key: $e');
    }
  }

  static Future<void> clear() async {
    try {
      await _prefs?.clear();
      Logger.database('Shared preferences cleared');
    } catch (e) {
      Logger.error('Failed to clear shared preferences: $e');
    }
  }

  // Authentication specific methods
  static Future<void> saveAuthTokens({
    required String accessToken,
    required String refreshToken,
    required String userId,
    required String userRole,
  }) async {
    try {
      await setSecureString(AppConstants.accessTokenKey, accessToken);
      await setSecureString(AppConstants.refreshTokenKey, refreshToken);
      await setString(AppConstants.userIdKey, userId);
      await setString(AppConstants.userRoleKey, userRole);
      await setBool(AppConstants.isLoggedInKey, true);
      
      Logger.auth('Auth tokens saved successfully');
    } catch (e) {
      Logger.error('Failed to save auth tokens: $e');
      rethrow;
    }
  }

  static Future<Map<String, String?>> getAuthTokens() async {
    try {
      final accessToken = await getSecureString(AppConstants.accessTokenKey);
      final refreshToken = await getSecureString(AppConstants.refreshTokenKey);
      final userId = await getString(AppConstants.userIdKey);
      final userRole = await getString(AppConstants.userRoleKey);
      
      return {
        'accessToken': accessToken,
        'refreshToken': refreshToken,
        'userId': userId,
        'userRole': userRole,
      };
    } catch (e) {
      Logger.error('Failed to get auth tokens: $e');
      return {};
    }
  }

  static Future<void> clearAuthTokens() async {
    try {
      await removeSecure(AppConstants.accessTokenKey);
      await removeSecure(AppConstants.refreshTokenKey);
      await remove(AppConstants.userIdKey);
      await remove(AppConstants.userRoleKey);
      await setBool(AppConstants.isLoggedInKey, false);
      
      Logger.auth('Auth tokens cleared successfully');
    } catch (e) {
      Logger.error('Failed to clear auth tokens: $e');
    }
  }

  static Future<bool> isLoggedIn() async {
    try {
      final isLoggedIn = await getBool(AppConstants.isLoggedInKey);
      final accessToken = await getSecureString(AppConstants.accessTokenKey);
      
      return isLoggedIn == true && accessToken != null;
    } catch (e) {
      Logger.error('Failed to check login status: $e');
      return false;
    }
  }

  static Future<String?> getCurrentUserId() async {
    return await getString(AppConstants.userIdKey);
  }

  static Future<String?> getCurrentUserRole() async {
    return await getString(AppConstants.userRoleKey);
  }

  // FCM Token methods
  static Future<void> saveFCMToken(String token) async {
    await setSecureString(AppConstants.fcmTokenKey, token);
    Logger.fcm('FCM token saved');
  }

  static Future<String?> getFCMToken() async {
    return await getSecureString(AppConstants.fcmTokenKey);
  }

  // Sync methods
  static Future<void> setLastSync(DateTime syncTime) async {
    await setString(AppConstants.lastSyncKey, syncTime.toIso8601String());
  }

  static Future<DateTime?> getLastSync() async {
    final syncString = await getString(AppConstants.lastSyncKey);
    if (syncString != null) {
      return DateTime.parse(syncString);
    }
    return null;
  }

  // Kiosk mode methods
  static Future<void> setKioskMode(bool enabled) async {
    await setBool(AppConstants.kioskModeKey, enabled);
    Logger.hardware('Kiosk mode set to: $enabled');
  }

  static Future<bool> isKioskModeEnabled() async {
    return await getBool(AppConstants.kioskModeKey) ?? false;
  }

  // App settings methods
  static Future<void> setThemeMode(String themeMode) async {
    await setString(SharedPreferencesKeys.themeMode, themeMode);
  }

  static Future<String?> getThemeMode() async {
    return await getString(SharedPreferencesKeys.themeMode);
  }

  static Future<void> setLanguage(String language) async {
    await setString(SharedPreferencesKeys.language, language);
  }

  static Future<String?> getLanguage() async {
    return await getString(SharedPreferencesKeys.language);
  }

  static Future<void> setNotificationsEnabled(bool enabled) async {
    await setBool(SharedPreferencesKeys.notificationsEnabled, enabled);
  }

  static Future<bool> isNotificationsEnabled() async {
    return await getBool(SharedPreferencesKeys.notificationsEnabled) ?? true;
  }

  static Future<void> setVibrationEnabled(bool enabled) async {
    await setBool(SharedPreferencesKeys.vibrationEnabled, enabled);
  }

  static Future<bool> isVibrationEnabled() async {
    return await getBool(SharedPreferencesKeys.vibrationEnabled) ?? true;
  }

  static Future<void> setTTSEnabled(bool enabled) async {
    await setBool(SharedPreferencesKeys.ttsEnabled, enabled);
  }

  static Future<bool> isTTSEnabled() async {
    return await getBool(SharedPreferencesKeys.ttsEnabled) ?? true;
  }

  // Utility methods
  static Future<Map<String, dynamic>> getAllSecureData() async {
    try {
      final allData = await _secureStorage.readAll();
      return allData;
    } catch (e) {
      Logger.error('Failed to get all secure data: $e');
      return {};
    }
  }

  static Future<Map<String, dynamic>> getAllSharedData() async {
    try {
      final allData = _prefs?.getKeys().map((key) => MapEntry(key, _prefs?.get(key)));
      return Map.fromEntries(allData ?? []);
    } catch (e) {
      Logger.error('Failed to get all shared data: $e');
      return {};
    }
  }

  static Future<void> printAllData() async {
    try {
      final secureData = await getAllSecureData();
      final sharedData = await getAllSharedData();
      
      Logger.database('=== SECURE DATA ===');
      secureData.forEach((key, value) {
        Logger.database('$key: ${key.contains('token') ? '***REDACTED***' : value}');
      });
      
      Logger.database('=== SHARED DATA ===');
      sharedData.forEach((key, value) {
        Logger.database('$key: $value');
      });
    } catch (e) {
      Logger.error('Failed to print all data: $e');
    }
  }
}
