import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../../core/utils/logger.dart';
import '../../../core/constants/app_constants.dart';

class DatabaseHelper {
  static DatabaseHelper? _instance;
  static Database? _database;

  DatabaseHelper._internal();

  static DatabaseHelper get instance {
    _instance ??= DatabaseHelper._internal();
    return _instance!;
  }

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    try {
      final databasesPath = await getDatabasesPath();
      final path = join(databasesPath, AppConstants.databaseName);

      Logger.database('Initializing database at: $path');

      return await openDatabase(
        path,
        version: 1,
        onCreate: _createDatabase,
        onUpgrade: _onUpgrade,
        onOpen: _onDatabaseOpen,
      );
    } catch (e) {
      Logger.error('Failed to initialize database: $e');
      rethrow;
    }
  }

  Future<void> _createDatabase(Database db, int version) async {
    try {
      Logger.database('Creating database tables...');

      // Create users table
      await db.execute('''
        CREATE TABLE ${DatabaseTables.users} (
          id TEXT PRIMARY KEY,
          phone TEXT UNIQUE NOT NULL,
          fullName TEXT NOT NULL,
          mahalla TEXT,
          role TEXT NOT NULL,
          isActive INTEGER NOT NULL DEFAULT 1,
          createdAt TEXT NOT NULL,
          updatedAt TEXT NOT NULL
        )
      ''');

      // Create debts table
      await db.execute('''
        CREATE TABLE ${DatabaseTables.debts} (
          id TEXT PRIMARY KEY,
          clientId TEXT NOT NULL,
          items TEXT NOT NULL,
          totalAmount REAL NOT NULL,
          dateIssued TEXT NOT NULL,
          dueDate TEXT NOT NULL,
          status TEXT NOT NULL,
          createdAt TEXT NOT NULL,
          updatedAt TEXT NOT NULL,
          FOREIGN KEY (clientId) REFERENCES ${DatabaseTables.users} (id)
        )
      ''');

      // Create audit_logs table
      await db.execute('''
        CREATE TABLE ${DatabaseTables.auditLogs} (
          id TEXT PRIMARY KEY,
          userId TEXT NOT NULL,
          action TEXT NOT NULL,
          entity TEXT NOT NULL,
          entityId TEXT NOT NULL,
          oldValues TEXT,
          newValues TEXT,
          ipAddress TEXT,
          userAgent TEXT,
          createdAt TEXT NOT NULL,
          FOREIGN KEY (userId) REFERENCES ${DatabaseTables.users} (id)
        )
      ''');

      // Create notifications table
      await db.execute('''
        CREATE TABLE ${DatabaseTables.notifications} (
          id TEXT PRIMARY KEY,
          userId TEXT NOT NULL,
          title TEXT NOT NULL,
          body TEXT NOT NULL,
          type TEXT NOT NULL,
          data TEXT,
          isRead INTEGER NOT NULL DEFAULT 0,
          createdAt TEXT NOT NULL,
          FOREIGN KEY (userId) REFERENCES ${DatabaseTables.users} (id)
        )
      ''');

      // Create sync_queue table
      await db.execute('''
        CREATE TABLE ${DatabaseTables.syncQueue} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          endpoint TEXT NOT NULL,
          method TEXT NOT NULL,
          data TEXT,
          headers TEXT,
          attempts INTEGER NOT NULL DEFAULT 0,
          lastAttempt TEXT,
          status TEXT NOT NULL DEFAULT 'pending',
          createdAt TEXT NOT NULL,
          updatedAt TEXT NOT NULL
        )
      ''');

      // Create indexes for better performance
      await db.execute('CREATE INDEX idx_debts_clientId ON ${DatabaseTables.debts}(clientId)');
      await db.execute('CREATE INDEX idx_debts_status ON ${DatabaseTables.debts}(status)');
      await db.execute('CREATE INDEX idx_debts_dueDate ON ${DatabaseTables.debts}(dueDate)');
      await db.execute('CREATE INDEX idx_auditLogs_userId ON ${DatabaseTables.auditLogs}(userId)');
      await db.execute('CREATE INDEX idx_notifications_userId ON ${DatabaseTables.notifications}(userId)');
      await db.execute('CREATE INDEX idx_notifications_isRead ON ${DatabaseTables.notifications}(isRead)');
      await db.execute('CREATE INDEX idx_syncQueue_status ON ${DatabaseTables.syncQueue}(status)');

      Logger.database('Database tables created successfully');
    } catch (e) {
      Logger.error('Failed to create database tables: $e');
      rethrow;
    }
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    try {
      Logger.database('Upgrading database from version $oldVersion to $newVersion');

      // Handle database upgrades here
      if (oldVersion < 2) {
        // Add new columns or tables for version 2
      }

      Logger.database('Database upgraded successfully');
    } catch (e) {
      Logger.error('Failed to upgrade database: $e');
      rethrow;
    }
  }

  Future<void> _onDatabaseOpen(Database db) async {
    Logger.database('Database opened successfully');
    
    // Enable foreign key constraints
    await db.execute('PRAGMA foreign_keys = ON');
    
    // Set WAL mode for better performance
    await db.execute('PRAGMA journal_mode = WAL');
    
    // Set synchronous mode to NORMAL for better performance
    await db.execute('PRAGMA synchronous = NORMAL');
  }

  // Generic CRUD operations
  Future<int> insert(String table, Map<String, dynamic> data) async {
    try {
      final db = await database;
      final result = await db.insert(table, data);
      Logger.database('Inserted into $table: $data');
      return result;
    } catch (e) {
      Logger.error('Failed to insert into $table: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> query(
    String table, {
    bool? distinct,
    List<String>? columns,
    String? where,
    List<dynamic>? whereArgs,
    String? groupBy,
    String? having,
    String? orderBy,
    int? limit,
    int? offset,
  }) async {
    try {
      final db = await database;
      final result = await db.query(
        table,
        distinct: distinct,
        columns: columns,
        where: where,
        whereArgs: whereArgs,
        groupBy: groupBy,
        having: having,
        orderBy: orderBy,
        limit: limit,
        offset: offset,
      );
      Logger.database('Queried $table: ${result.length} results');
      return result;
    } catch (e) {
      Logger.error('Failed to query $table: $e');
      rethrow;
    }
  }

  Future<int> update(
    String table,
    Map<String, dynamic> values, {
    String? where,
    List<dynamic>? whereArgs,
  }) async {
    try {
      final db = await database;
      final result = await db.update(table, values, where: where, whereArgs: whereArgs);
      Logger.database('Updated $table: $result rows affected');
      return result;
    } catch (e) {
      Logger.error('Failed to update $table: $e');
      rethrow;
    }
  }

  Future<int> delete(
    String table, {
    String? where,
    List<dynamic>? whereArgs,
  }) async {
    try {
      final db = await database;
      final result = await db.delete(table, where: where, whereArgs: whereArgs);
      Logger.database('Deleted from $table: $result rows affected');
      return result;
    } catch (e) {
      Logger.error('Failed to delete from $table: $e');
      rethrow;
    }
  }

  Future<int> rawInsert(String sql, [List<dynamic>? arguments]) async {
    try {
      final db = await database;
      final result = await db.rawInsert(sql, arguments);
      Logger.database('Raw insert executed: $sql');
      return result;
    } catch (e) {
      Logger.error('Failed to execute raw insert: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> rawQuery(String sql, [List<dynamic>? arguments]) async {
    try {
      final db = await database;
      final result = await db.rawQuery(sql, arguments);
      Logger.database('Raw query executed: $sql');
      return result;
    } catch (e) {
      Logger.error('Failed to execute raw query: $e');
      rethrow;
    }
  }

  Future<int> rawUpdate(String sql, [List<dynamic>? arguments]) async {
    try {
      final db = await database;
      final result = await db.rawUpdate(sql, arguments);
      Logger.database('Raw update executed: $sql');
      return result;
    } catch (e) {
      Logger.error('Failed to execute raw update: $e');
      rethrow;
    }
  }

  Future<int> rawDelete(String sql, [List<dynamic>? arguments]) async {
    try {
      final db = await database;
      final result = await db.rawDelete(sql, arguments);
      Logger.database('Raw delete executed: $sql');
      return result;
    } catch (e) {
      Logger.error('Failed to execute raw delete: $e');
      rethrow;
    }
  }

  // Batch operations
  Future<void> batch(void Function(Batch batch) operations) async {
    try {
      final db = await database;
      final batch = db.batch();
      operations(batch);
      await batch.commit(noResult: true);
      Logger.database('Batch operations completed');
    } catch (e) {
      Logger.error('Failed to execute batch operations: $e');
      rethrow;
    }
  }

  // Transaction operations
  Future<T> transaction<T>(Future<T> Function(Transaction txn) action) async {
    try {
      final db = await database;
      final result = await db.transaction(action);
      Logger.database('Transaction completed successfully');
      return result;
    } catch (e) {
      Logger.error('Transaction failed: $e');
      rethrow;
    }
  }

  // Utility methods
  Future<void> clearTable(String table) async {
    try {
      final db = await database;
      await db.delete(table);
      Logger.database('Cleared table: $table');
    } catch (e) {
      Logger.error('Failed to clear table $table: $e');
      rethrow;
    }
  }

  Future<void> clearAllTables() async {
    try {
      final db = await database;
      await db.transaction((txn) async {
        await txn.delete(DatabaseTables.users);
        await txn.delete(DatabaseTables.debts);
        await txn.delete(DatabaseTables.auditLogs);
        await txn.delete(DatabaseTables.notifications);
        await txn.delete(DatabaseTables.syncQueue);
      });
      Logger.database('All tables cleared');
    } catch (e) {
      Logger.error('Failed to clear all tables: $e');
      rethrow;
    }
  }

  Future<int> getTableCount(String table) async {
    try {
      final result = await rawQuery('SELECT COUNT(*) as count FROM $table');
      return result.first['count'] as int;
    } catch (e) {
      Logger.error('Failed to get count for table $table: $e');
      return 0;
    }
  }

  Future<Map<String, int>> getAllTableCounts() async {
    try {
      final Map<String, int> counts = {};
      
      for (final table in [
        DatabaseTables.users,
        DatabaseTables.debts,
        DatabaseTables.auditLogs,
        DatabaseTables.notifications,
        DatabaseTables.syncQueue,
      ]) {
        counts[table] = await getTableCount(table);
      }
      
      return counts;
    } catch (e) {
      Logger.error('Failed to get all table counts: $e');
      return {};
    }
  }

  Future<void> vacuumDatabase() async {
    try {
      final db = await database;
      await db.execute('VACUUM');
      Logger.database('Database vacuumed');
    } catch (e) {
      Logger.error('Failed to vacuum database: $e');
    }
  }

  Future<void> analyzeDatabase() async {
    try {
      final db = await database;
      await db.execute('ANALYZE');
      Logger.database('Database analyzed');
    } catch (e) {
      Logger.error('Failed to analyze database: $e');
    }
  }

  Future<void> closeDatabase() async {
    try {
      if (_database != null) {
        await _database!.close();
        _database = null;
        Logger.database('Database closed');
      }
    } catch (e) {
      Logger.error('Failed to close database: $e');
    }
  }

  Future<void> deleteDatabase() async {
    try {
      final databasesPath = await getDatabasesPath();
      final path = join(databasesPath, AppConstants.databaseName);
      
      await closeDatabase();
      await deleteDatabase(path);
      Logger.database('Database deleted');
    } catch (e) {
      Logger.error('Failed to delete database: $e');
      rethrow;
    }
  }
}
