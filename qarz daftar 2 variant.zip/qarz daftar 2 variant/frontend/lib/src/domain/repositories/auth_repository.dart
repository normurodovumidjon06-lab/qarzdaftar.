import '../entities/user.dart';

abstract class AuthRepository {
  // Authentication methods
  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
    String? deviceToken,
  });

  Future<Map<String, dynamic>> register({
    required String phone,
    required String password,
    required String fullName,
    String? mahalla,
    String? role,
  });

  Future<Map<String, dynamic>> refreshToken(String refreshToken);

  Future<Map<String, dynamic>> logout();

  Future<Map<String, dynamic>> getProfile();

  Future<Map<String, dynamic>> updateProfile({
    required String userId,
    String? fullName,
    String? mahalla,
  });

  Future<Map<String, dynamic>> changePassword({
    required String currentPassword,
    required String newPassword,
  });

  Future<Map<String, dynamic>> validateTokens();

  Future<Map<String, dynamic>> updateDeviceToken(String deviceToken);

  // User data methods
  Future<User?> getCurrentUser();

  Future<bool> isLoggedIn();

  Future<String?> getCurrentUserId();

  Future<String?> getCurrentUserRole();

  Future<void> clearAuthData();

  // Offline support methods
  Future<void> cacheAuthData(Map<String, dynamic> authData);

  Future<Map<String, dynamic>?> getCachedAuthData();
}
