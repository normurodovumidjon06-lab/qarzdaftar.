import '../entities/debt.dart';

abstract class DebtRepository {
  // Debt CRUD operations
  Future<Map<String, dynamic>> getDebts({
    int page = 1,
    int limit = 50,
    String? clientId,
    String? status,
    String? search,
    String? dateFrom,
    String? dateTo,
  });

  Future<Map<String, dynamic>> getMyDebts();

  Future<Map<String, dynamic>> getDebt(String debtId);

  Future<Map<String, dynamic>> createDebt({
    required String clientId,
    required List items,
    required double totalAmount,
    required String dateIssued,
    required String dueDate,
  });

  Future<Map<String, dynamic>> updateDebt(
    String debtId, {
    String? clientId,
    List? items,
    double? totalAmount,
    String? dateIssued,
    String? dueDate,
    String? status,
  });

  Future<Map<String, dynamic>> markDebtAsPaid(String debtId);

  Future<Map<String, dynamic>> markDebtAsDefaulted(String debtId);

  Future<Map<String, dynamic>> triggerHardwareShock(String debtId);

  // Statistics and reporting
  Future<Map<String, dynamic>> getDebtStats();

  Future<Map<String, dynamic>> getOverdueDebts();

  Future<Map<String, dynamic>> getDebtsDueIn7Days();

  Future<Map<String, dynamic>> getDebtsByClient(String clientId);
}
