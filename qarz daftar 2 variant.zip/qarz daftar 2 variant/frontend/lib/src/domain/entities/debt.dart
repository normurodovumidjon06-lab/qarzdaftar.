import 'package:freezed_annotation/freezed_annotation.dart';

part 'debt.freezed.dart';
part 'debt.g.dart';

@freezed
class Debt with _$Debt {
  const factory Debt({
    required String id,
    required String clientId,
    required List<DebtItem> items,
    required double totalAmount,
    required DateTime dateIssued,
    required DateTime dueDate,
    @Default(DebtStatus.active) DebtStatus status,
    required DateTime createdAt,
    required DateTime updatedAt,
    User? client,
  }) = _Debt;

  factory Debt.fromJson(Map<String, dynamic> json) => _$DebtFromJson(json);

  const Debt._();

  // Getters for convenience
  bool get isActive => status == DebtStatus.active;
  bool get isPaid => status == DebtStatus.paid;
  bool get isDefaulted => status == DebtStatus.defaulted;
  
  bool get isOverdue => DateTime.now().isAfter(dueDate) && isActive;
  bool get isDueSoon {
    final now = DateTime.now();
    final sevenDaysFromNow = now.add(const Duration(days: 7));
    return dueDate.isBefore(sevenDaysFromNow) && dueDate.isAfter(now) && isActive;
  }
  
  int get daysUntilDue {
    final now = DateTime.now();
    if (dueDate.isBefore(now)) return -1;
    return dueDate.difference(now).inDays;
  }
  
  String get formattedTotalAmount => totalAmount.toStringAsFixed(2);
  String get formattedDateIssued => dateIssued.toIso8601String().split('T')[0];
  String get formattedDueDate => dueDate.toIso8601String().split('T')[0];
  
  String get statusDisplay {
    switch (status) {
      case DebtStatus.active:
        return isOverdue ? 'Overdue' : 'Active';
      case DebtStatus.paid:
        return 'Paid';
      case DebtStatus.defaulted:
        return 'Defaulted';
    }
  }

  // Serialization for database storage
  Map<String, dynamic> toJsonForDb() {
    return {
      'id': id,
      'clientId': clientId,
      'items': items.map((item) => item.toJson()).toString(),
      'totalAmount': totalAmount,
      'dateIssued': dateIssued.toIso8601String(),
      'dueDate': dueDate.toIso8601String(),
      'status': status.name,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory Debt.fromJsonDb(Map<String, dynamic> json) {
    return Debt(
      id: json['id'],
      clientId: json['clientId'],
      items: _parseItems(json['items']),
      totalAmount: (json['totalAmount'] as num).toDouble(),
      dateIssued: DateTime.parse(json['dateIssued']),
      dueDate: DateTime.parse(json['dueDate']),
      status: DebtStatus.values.firstWhere(
        (status) => status.name == json['status'],
        orElse: () => DebtStatus.active,
      ),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
    );
  }

  static List<DebtItem> _parseItems(String itemsString) {
    try {
      if (itemsString.startsWith('[')) {
        // Parse as JSON array
        final List<dynamic> itemsList = List<dynamic>.from(
          List<dynamic>.from(Object?.toString() as String? ?? '[]')
        );
        return itemsList.map((item) => DebtItem.fromJson(item)).toList();
      } else {
        // Parse as JSON string
        final List<dynamic> itemsList = List<dynamic>.from(
          Object?.toString() as String? ?? '[]'
        );
        return itemsList.map((item) => DebtItem.fromJson(item)).toList();
      }
    } catch (e) {
      return [];
    }
  }
}

@freezed
class DebtItem with _$DebtItem {
  const factory DebtItem({
    required String name,
    required int quantity,
    required double price,
  }) = _DebtItem;

  factory DebtItem.fromJson(Map<String, dynamic> json) => _$DebtItemFromJson(json);

  const DebtItem._();

  double get total => quantity * price;
  String get formattedPrice => price.toStringAsFixed(2);
  String get formattedTotal => total.toStringAsFixed(2);
}

enum DebtStatus {
  active,
  paid,
  defaulted;

  String get name {
    switch (this) {
      case DebtStatus.active:
        return 'ACTIVE';
      case DebtStatus.paid:
        return 'PAID';
      case DebtStatus.defaulted:
        return 'DEFAULTED';
    }
  }

  static DebtStatus fromString(String status) {
    switch (status.toUpperCase()) {
      case 'ACTIVE':
        return DebtStatus.active;
      case 'PAID':
        return DebtStatus.paid;
      case 'DEFAULTED':
        return DebtStatus.defaulted;
      default:
        return DebtStatus.active;
    }
  }
}
