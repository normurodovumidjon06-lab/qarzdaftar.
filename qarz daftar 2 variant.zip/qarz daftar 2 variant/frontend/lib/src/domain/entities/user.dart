import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.freezed.dart';
part 'user.g.dart';

@freezed
class User with _$User {
  const factory User({
    required String id,
    required String phone,
    required String fullName,
    String? mahalla,
    required String role,
    @Default(true) bool isActive,
    required DateTime createdAt,
    required DateTime updatedAt,
    String? deviceToken,
  }) = _User;

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);

  const User._();

  // Getters for convenience
  bool get isSuperAdmin => role == 'SUPER_ADMIN';
  bool get isClient => role == 'CLIENT';
  
  String get displayName => fullName;
  String get maskedPhone {
    if (phone.length <= 6) return phone;
    return '${phone.substring(0, 4)}****${phone.substring(phone.length - 2)}';
  }

  // Serialization for database storage
  Map<String, dynamic> toJsonForDb() {
    return {
      'id': id,
      'phone': phone,
      'fullName': fullName,
      'mahalla': mahalla,
      'role': role,
      'isActive': isActive ? 1 : 0,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'deviceToken': deviceToken,
    };
  }

  factory User.fromJsonDb(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      phone: json['phone'],
      fullName: json['fullName'],
      mahalla: json['mahalla'],
      role: json['role'],
      isActive: (json['isActive'] as int) == 1,
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      deviceToken: json['deviceToken'],
    );
  }
}
