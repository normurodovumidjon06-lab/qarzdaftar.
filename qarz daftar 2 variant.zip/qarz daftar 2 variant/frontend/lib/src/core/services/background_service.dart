import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../utils/logger.dart';
import '../../data/datasources/local/database_helper.dart';
import '../../data/datasources/remote/api_service.dart';
import '../constants/app_constants.dart';

class BackgroundService {
  static const String _channelId = 'qarz_daftari_background_service';
  static const String _channelName = 'Qarz Daftari Background Service';
  static const String _channelDescription = 'Monitors debts and sends notifications';

  static Future<void> initialize() async {
    final service = FlutterBackgroundService();
    
    await service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onStart,
        isForegroundMode: true,
        autoStart: true,
        notificationChannelId: _channelId,
        initialNotificationTitle: 'Qarz Daftari',
        initialNotificationContent: 'Background service started',
        foregroundServiceNotificationId: 888,
      ),
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: onStart,
        onBackground: onIosBackground,
      ),
    );

    Logger.info('Background service configured');
  }

  static Future<void> start() async {
    final service = FlutterBackgroundService();
    bool isRunning = await service.isRunning();
    
    if (!isRunning) {
      await service.startService();
      Logger.info('Background service started');
    } else {
      Logger.info('Background service already running');
    }
  }

  static Future<void> stop() async {
    final service = FlutterBackgroundService();
    await service.stopService();
    Logger.info('Background service stopped');
  }

  @pragma('vm:entry-point')
  static Future<bool> onIosBackground(ServiceInstance service) async {
    Logger.info('iOS background service started');
    return true;
  }

  @pragma('vm:entry-point')
  static void onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();
    
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final DatabaseHelper dbHelper = DatabaseHelper();
    
    Logger.background('Service started');

    if (service is AndroidServiceInstance) {
      service.on('stopService').listen((event) {
        service.stopSelf();
        Logger.background('Service stop requested');
      });
    }

    service.on('setAsForeground').listen((event) {
      Logger.background('Set as foreground requested');
    });

    service.on('setAsBackground').listen((event) {
      Logger.background('Set as background requested');
    });

    // Main service loop
    Timer.periodic(const Duration(minutes: 15), (timer) async {
      Logger.background('Service tick: ${DateTime.now()}');
      
      try {
        // Check connectivity
        final connectivityResult = await Connectivity().checkConnectivity();
        
        if (connectivityResult != ConnectivityResult.none) {
          // Online - sync with backend
          await _syncWithBackend(prefs, dbHelper);
        } else {
          // Offline - check local debts
          await _checkLocalDebts(dbHelper);
        }

        // Update notification
        await _updateNotification(service);

      } catch (e) {
        Logger.error('Background service error: $e');
      }
    });

    // Initial check
    await _checkLocalDebts(dbHelper);
  }

  static Future<void> _checkLocalDebts(DatabaseHelper dbHelper) async {
    try {
      final db = await dbHelper.database;
      final now = DateTime.now();
      
      // Check for debts due in 7 days
      final sevenDaysFromNow = now.add(const Duration(days: 7));
      final debtsDueIn7Days = await db.query(
        'debts',
        where: 'dueDate >= ? AND dueDate <= ? AND status = ?',
        whereArgs: [
          now.toIso8601String(),
          sevenDaysFromNow.toIso8601String(),
          'ACTIVE',
        ],
      );

      // Check for overdue debts
      final overdueDebts = await db.query(
        'debts',
        where: 'dueDate < ? AND status = ?',
        whereArgs: [now.toIso8601String(), 'ACTIVE'],
      );

      Logger.background('Found ${debtsDueIn7Days.length} debts due in 7 days');
      Logger.background('Found ${overdueDebts.length} overdue debts');

      // Store counts for notification
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('debts_due_7_days', debtsDueIn7Days.length);
      await prefs.setInt('overdue_debts', overdueDebts.length);

    } catch (e) {
      Logger.error('Error checking local debts: $e');
    }
  }

  static Future<void> _syncWithBackend(
    SharedPreferences prefs,
    DatabaseHelper dbHelper,
  ) async {
    try {
      final token = prefs.getString('access_token');
      if (token == null) {
        Logger.warning('No access token available for sync');
        return;
      }

      final apiService = ApiService();
      
      // Sync user debts
      final debtsResponse = await apiService.getMyDebts();
      if (debtsResponse['success'] == true) {
        final debts = debtsResponse['data']['debts'];
        await _saveDebtsLocally(dbHelper, debts);
        Logger.background('Synced ${debts.length} debts from backend');
      }

      // Update last sync time
      await prefs.setString('last_sync', DateTime.now().toIso8601String());

    } catch (e) {
      Logger.error('Error syncing with backend: $e');
    }
  }

  static Future<void> _saveDebtsLocally(DatabaseHelper dbHelper, List debts) async {
    final db = await dbHelper.database;
    final batch = db.batch();

    // Clear existing debts
    batch.delete('debts');

    // Insert new debts
    for (final debt in debts) {
      batch.insert('debts', {
        'id': debt['id'],
        'clientId': debt['clientId'],
        'items': debt['items'],
        'totalAmount': debt['totalAmount'],
        'dateIssued': debt['dateIssued'],
        'dueDate': debt['dueDate'],
        'status': debt['status'],
        'createdAt': debt['createdAt'],
        'updatedAt': debt['updatedAt'],
      });
    }

    await batch.commit(noResult: true);
  }

  static Future<void> _updateNotification(ServiceInstance service) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final debtsDueIn7Days = prefs.getInt('debts_due_7_days') ?? 0;
      final overdueDebts = prefs.getInt('overdue_debts') ?? 0;

      String content = 'Service running';
      if (overdueDebts > 0) {
        content = '$overdueDebts overdue debt(s)';
      } else if (debtsDueIn7Days > 0) {
        content = '$debtsDueIn7Days debt(s) due soon';
      }

      if (service is AndroidServiceInstance) {
        service.setForegroundNotificationInfo(
          title: 'Qarz Daftari',
          content: content,
        );
      }

    } catch (e) {
      Logger.error('Error updating notification: $e');
    }
  }

  // Public methods for manual triggering
  static Future<void> checkDueDebts() async {
    try {
      final dbHelper = DatabaseHelper();
      await _checkLocalDebts(dbHelper);
      Logger.background('Manual debt check completed');
    } catch (e) {
      Logger.error('Manual debt check failed: $e');
    }
  }

  static Future<void> syncWithBackend() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final dbHelper = DatabaseHelper();
      await _syncWithBackend(prefs, dbHelper);
      Logger.background('Manual sync completed');
    } catch (e) {
      Logger.error('Manual sync failed: $e');
    }
  }

  static Future<bool> isRunning() async {
    final service = FlutterBackgroundService();
    return await service.isRunning();
  }

  static Future<Map<String, dynamic>> getServiceStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final isRunning = await FlutterBackgroundService().isRunning();
    final lastSync = prefs.getString('last_sync');
    final debtsDueIn7Days = prefs.getInt('debts_due_7_days') ?? 0;
    final overdueDebts = prefs.getInt('overdue_debts') ?? 0;

    return {
      'isRunning': isRunning,
      'lastSync': lastSync,
      'debtsDueIn7Days': debtsDueIn7Days,
      'overdueDebts': overdueDebts,
    };
  }
}
