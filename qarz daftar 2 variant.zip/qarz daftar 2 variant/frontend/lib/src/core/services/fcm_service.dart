import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/logger.dart';
import '../services/hardware_shock_service.dart';
import '../../data/datasources/remote/api_service.dart';
import '../constants/app_constants.dart';

class FCMService {
  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage();
  static String? _fcmToken;

  static Future<void> initialize() async {
    try {
      // Request notification permission
      await _requestPermission();

      // Get FCM token
      await _getFCMToken();

      // Set up message handlers
      await _setupMessageHandlers();

      // Subscribe to topics
      await _subscribeToTopics();

      Logger.fcm('FCM service initialized');
    } catch (e) {
      Logger.error('Failed to initialize FCM service: $e');
    }
  }

  static Future<void> _requestPermission() async {
    final settings = await _messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      Logger.fcm('Notification permission granted');
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      Logger.fcm('Provisional notification permission granted');
    } else {
      Logger.warning('Notification permission denied');
    }
  }

  static Future<void> requestNotificationPermission() async {
    await _requestPermission();
  }

  static Future<void> _getFCMToken() async {
    try {
      String? token = await _messaging.getToken();
      
      if (token != null) {
        _fcmToken = token;
        Logger.fcm('FCM Token: $token');
        
        // Save token to secure storage
        await _secureStorage.write(key: 'fcm_token', value: token);
        
        // Send token to backend if user is logged in
        await _sendTokenToBackend(token);
      } else {
        Logger.warning('Failed to get FCM token');
      }

      // Listen for token refresh
      _messaging.onTokenRefresh.listen((newToken) {
        _fcmToken = newToken;
        Logger.fcm('FCM Token refreshed: $newToken');
        _secureStorage.write(key: 'fcm_token', value: newToken);
        _sendTokenToBackend(newToken);
      });

    } catch (e) {
      Logger.error('Error getting FCM token: $e');
    }
  }

  static Future<void> _sendTokenToBackend(String token) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('is_logged_in') ?? false;
      
      if (isLoggedIn) {
        final apiService = ApiService();
        await apiService.updateDeviceToken(token);
        Logger.fcm('FCM token sent to backend');
      }
    } catch (e) {
      Logger.error('Error sending FCM token to backend: $e');
    }
  }

  static Future<void> _setupMessageHandlers() async {
    // Handle messages when app is in foreground
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Handle messages when app is in background but opened
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);

    // Handle messages when app is completely closed
    final initialMessage = await FirebaseMessaging.getInitialMessage();
    if (initialMessage != null) {
      _handleMessageOpenedApp(initialMessage);
    }
  }

  static Future<void> _handleForegroundMessage(RemoteMessage message) async {
    Logger.fcm('Received foreground message: ${message.messageId}');
    Logger.fcm('Message data: ${message.data}');
    
    // Handle hardware shock messages
    if (message.data['type'] == 'HARDWARE_SHOCK') {
      await HardwareShockService.executeHardwareShock(
        clientName: message.data['clientName'] ?? 'Mijoz',
        amount: double.tryParse(message.data['amount'] ?? '0') ?? 0,
        vibrationPattern: message.data['vibrationPattern'],
        ttsMessage: message.data['ttsMessage'],
      );
    }

    // Show notification for regular messages
    _showNotification(message);
  }

  static Future<void> _handleMessageOpenedApp(RemoteMessage message) async {
    Logger.fcm('Message opened app: ${message.messageId}');
    
    // Handle navigation based on message type
    if (message.data['type'] == 'HARDWARE_SHOCK') {
      // Navigate to debt details
      // This would be handled by the navigation service
    }
  }

  static void _showNotification(RemoteMessage message) {
    // This would integrate with a local notification plugin
    // For now, we'll just log it
    Logger.fcm('Notification: ${message.notification?.title} - ${message.notification?.body}');
  }

  static Future<void> _subscribeToTopics() async {
    try {
      // Subscribe to general topic
      await _messaging.subscribeToTopic('all_users');
      
      // Subscribe to role-specific topics
      final prefs = await SharedPreferences.getInstance();
      final userRole = prefs.getString('user_role');
      
      if (userRole != null) {
        await _messaging.subscribeToTopic('${userRole}_users');
      }

      Logger.fcm('Subscribed to notification topics');
    } catch (e) {
      Logger.error('Error subscribing to topics: $e');
    }
  }

  static Future<String?> getToken() async {
    if (_fcmToken == null) {
      _fcmToken = await _messaging.getToken();
    }
    return _fcmToken;
  }

  static Future<void> subscribeToTopic(String topic) async {
    try {
      await _messaging.subscribeToTopic(topic);
      Logger.fcm('Subscribed to topic: $topic');
    } catch (e) {
      Logger.error('Error subscribing to topic $topic: $e');
    }
  }

  static Future<void> unsubscribeFromTopic(String topic) async {
    try {
      await _messaging.unsubscribeFromTopic(topic);
      Logger.fcm('Unsubscribed from topic: $topic');
    } catch (e) {
      Logger.error('Error unsubscribing from topic $topic: $e');
    }
  }

  static Future<void> deleteToken() async {
    try {
      await _messaging.deleteToken();
      await _secureStorage.delete(key: 'fcm_token');
      _fcmToken = null;
      Logger.fcm('FCM token deleted');
    } catch (e) {
      Logger.error('Error deleting FCM token: $e');
    }
  }

  static Future<Map<String, dynamic>> getNotificationSettings() async {
    final settings = await _messaging.getNotificationSettings();
    return {
      'authorizationStatus': settings.authorizationStatus.toString(),
      'isProvisional': settings.authorizationStatus == AuthorizationStatus.provisional,
    };
  }

  // Test method for development
  static Future<void> sendTestNotification() async {
    if (kDebugMode) {
      Logger.fcm('Test notification would be sent here');
      // In development, you might want to simulate a notification
    }
  }
}
