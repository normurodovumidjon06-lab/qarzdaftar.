import 'dart:async';
import 'package:flutter/material.dart';
import 'package:vibration/vibration.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../utils/logger.dart';

class HardwareShockService {
  static FlutterTts? _flutterTts;
  static bool _isInitialized = false;
  static bool _isExecuting = false;

  static Future<void> initialize() async {
    try {
      _flutterTts = FlutterTts();
      
      // Configure TTS
      await _flutterTts!.setLanguage('uz-UZ'); // Uzbek language
      await _flutterTts!.setSpeechRate(0.8); // Slightly slower for clarity
      await _flutterTts!.setVolume(1.0); // Maximum volume
      await _flutterTts!.setPitch(1.0);
      
      // Set completion handler
      _flutterTts!.setCompletionHandler(() {
        Logger.hardware('TTS speech completed');
      });
      
      // Set error handler
      _flutterTts!.setErrorHandler((msg) {
        Logger.error('TTS Error: $msg');
      });
      
      // Set start handler
      _flutterTts!.setStartHandler(() {
        Logger.hardware('TTS speech started');
      });

      _isInitialized = true;
      Logger.hardware('Hardware shock service initialized');
    } catch (e) {
      Logger.error('Failed to initialize hardware shock service: $e');
    }
  }

  static Future<void> executeHardwareShock({
    required String clientName,
    required double amount,
    String? vibrationPattern,
    String? ttsMessage,
  }) async {
    if (!_isInitialized) {
      Logger.warning('Hardware shock service not initialized');
      return;
    }

    if (_isExecuting) {
      Logger.warning('Hardware shock already executing');
      return;
    }

    _isExecuting = true;
    
    try {
      Logger.hardware('Executing hardware shock for $clientName');

      // Step 1: Vibration
      await _executeVibration(vibrationPattern);

      // Step 2: TTS Message
      await _executeTTS(ttsMessage ?? _getDefaultTTSMessage(clientName, amount));

      // Step 3: System alert (if possible)
      await _executeSystemAlert();

      Logger.hardware('Hardware shock completed successfully');
    } catch (e) {
      Logger.error('Error executing hardware shock: $e');
    } finally {
      _isExecuting = false;
    }
  }

  static Future<void> _executeVibration(String? patternString) async {
    try {
      // Check if device has vibrator
      bool? hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator != true) {
        Logger.hardware('Device does not have vibrator');
        return;
      }

      List<int> pattern = _parseVibrationPattern(patternString);
      
      if (pattern.isEmpty) {
        // Default pattern: 1s on, 0.5s off, 1s on, 0.5s off, 2s on
        pattern = [1000, 500, 1000, 500, 2000];
      }

      Logger.hardware('Executing vibration pattern: $pattern');
      
      // Vibrate with pattern
      await Vibration.vibrate(pattern: pattern);
      
      // Wait for vibration to complete
      int totalDuration = pattern.reduce((a, b) => a + b);
      await Future.delayed(Duration(milliseconds: totalDuration));
      
    } catch (e) {
      Logger.error('Error executing vibration: $e');
    }
  }

  static List<int> _parseVibrationPattern(String? patternString) {
    if (patternString == null || patternString.isEmpty) {
      return [];
    }

    try {
      // Parse pattern like "1000,500,1000,500,2000"
      return patternString
          .split(',')
          .map((s) => int.tryParse(s.trim()) ?? 0)
          .where((duration) => duration > 0)
          .toList();
    } catch (e) {
      Logger.error('Error parsing vibration pattern: $e');
      return [];
    }
  }

  static Future<void> _executeTTS(String message) async {
    try {
      if (_flutterTts == null) {
        Logger.warning('TTS not initialized');
        return;
      }

      Logger.hardware('Speaking TTS message: $message');

      // Set maximum system volume (if possible)
      await _setMaxVolume();

      // Speak the message
      await _flutterTts!.speak(message);

      // Wait for speech to complete (with timeout)
      await _waitForSpeechCompletion();

    } catch (e) {
      Logger.error('Error executing TTS: $e');
    }
  }

  static Future<void> _setMaxVolume() async {
    try {
      // This is a platform-specific implementation
      // On Android, we would need to use platform channels to set volume
      
      // For now, we'll just log that we're attempting to set volume
      Logger.hardware('Attempting to set maximum volume');
      
      // In a real implementation, you would use MethodChannel:
      // const platform = MethodChannel('qarz_daftari/volume');
      // await platform.invokeMethod('setMaxVolume');
      
    } catch (e) {
      Logger.error('Error setting max volume: $e');
    }
  }

  static Future<void> _waitForSpeechCompletion() async {
    // Wait for TTS to complete with a timeout
    const maxWaitTime = Duration(seconds: 10);
    const checkInterval = Duration(milliseconds: 100);
    
    int elapsed = 0;
    
    while (elapsed < maxWaitTime.inMilliseconds) {
      // Check if TTS is still speaking
      bool? isSpeaking = await _flutterTts?.isSpeaking;
      
      if (isSpeaking != true) {
        Logger.hardware('TTS speech completed naturally');
        return;
      }
      
      await Future.delayed(checkInterval);
      elapsed += checkInterval.inMilliseconds;
    }
    
    // If we reach here, speech didn't complete in time
    Logger.warning('TTS speech timeout, stopping manually');
    await _flutterTts?.stop();
  }

  static Future<void> _executeSystemAlert() async {
    try {
      // Check for system alert window permission
      bool hasPermission = await Permission.systemAlertWindow.isGranted;
      
      if (!hasPermission) {
        Logger.hardware('System alert window permission not granted');
        return;
      }

      // In a real implementation, you would show a system overlay
      // This would require a platform channel implementation
      Logger.hardware('System alert would be shown here');
      
      // For now, we'll just vibrate briefly to indicate system alert
      await Vibration.vibrate(duration: 200);
      
    } catch (e) {
      Logger.error('Error executing system alert: $e');
    }
  }

  static String _getDefaultTTSMessage(String clientName, double amount) {
    return 'Hurmatli $clientName, iltimos qarzlaringizni to\'lab qo\'ying. Sizning ${amount.toStringAsFixed(0)} so\'m qarzingiz mavjud.';
  }

  static Future<void> testVibration() async {
    try {
      bool? hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator == true) {
        await Vibration.vibrate(duration: 1000);
        Logger.hardware('Test vibration executed');
      } else {
        Logger.hardware('Device does not have vibrator');
      }
    } catch (e) {
      Logger.error('Error testing vibration: $e');
    }
  }

  static Future<void> testTTS() async {
    try {
      if (_flutterTts != null) {
        await _flutterTts!.speak('Bu sinov xabari. Qarz Daftari tizimi ishlamoqda.');
        Logger.hardware('Test TTS executed');
      } else {
        Logger.warning('TTS not initialized for testing');
      }
    } catch (e) {
      Logger.error('Error testing TTS: $e');
    }
  }

  static Future<void> testFullHardwareShock() async {
    await executeHardwareShock(
      clientName: 'Test User',
      amount: 1000000,
      vibrationPattern: '500,200,500,200,500',
      ttsMessage: 'Bu sinov ogohlantirishi. Tizim to\'g\'ri ishlamoqda.',
    );
  }

  static bool get isInitialized => _isInitialized;
  static bool get isExecuting => _isExecuting;

  static Future<Map<String, dynamic>> getHardwareCapabilities() async {
    bool? hasVibrator = await Vibration.hasVibrator();
    bool hasSystemAlertPermission = await Permission.systemAlertWindow.isGranted;
    
    return {
      'hasVibrator': hasVibrator ?? false,
      'hasSystemAlertPermission': hasSystemAlertPermission,
      'isTTSInitialized': _isInitialized,
      'isCurrentlyExecuting': _isExecuting,
    };
  }
}
