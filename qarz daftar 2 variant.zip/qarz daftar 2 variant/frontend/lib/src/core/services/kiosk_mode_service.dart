import 'dart:async';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/logger.dart';

class KioskModeService {
  static const MethodChannel _channel = MethodChannel('qarz_daftari/kiosk');
  static const String _kioskModeKey = 'kiosk_mode_enabled';
  static bool _isKioskMode = false;

  static Future<void> initialize() async {
    try {
      // Check current kiosk mode status
      await _checkKioskModeStatus();
      
      Logger.hardware('Kiosk mode service initialized');
    } catch (e) {
      Logger.error('Failed to initialize kiosk mode service: $e');
    }
  }

  static Future<void> _checkKioskModeStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isKioskMode = prefs.getBool(_kioskModeKey) ?? false;
      
      // Also check with native side
      bool? nativeStatus = await _channel.invokeMethod<bool>('isKioskModeActive');
      if (nativeStatus != null) {
        _isKioskMode = nativeStatus;
        await prefs.setBool(_kioskModeKey, _isKioskMode);
      }
      
      Logger.hardware('Kiosk mode status: $_isKioskMode');
    } catch (e) {
      Logger.error('Error checking kiosk mode status: $e');
    }
  }

  static Future<bool> requestDeviceAdminPermission() async {
    try {
      // Check if we already have device admin permission
      bool hasPermission = await Permission.systemAlertWindow.isGranted;
      
      if (!hasPermission) {
        Logger.hardware('Requesting system alert window permission');
        final result = await Permission.systemAlertWindow.request();
        hasPermission = result.isGranted;
      }

      if (hasPermission) {
        // Request device admin permission through native code
        bool? granted = await _channel.invokeMethod<bool>('requestDeviceAdmin');
        Logger.hardware('Device admin permission granted: $granted');
        return granted ?? false;
      }

      return false;
    } catch (e) {
      Logger.error('Error requesting device admin permission: $e');
      return false;
    }
  }

  static Future<bool> enableKioskMode() async {
    try {
      if (_isKioskMode) {
        Logger.hardware('Kiosk mode already enabled');
        return true;
      }

      // Check if we have necessary permissions
      bool hasDeviceAdmin = await _hasDeviceAdminPermission();
      if (!hasDeviceAdmin) {
        Logger.warning('Device admin permission not granted');
        return false;
      }

      // Enable kiosk mode through native code
      bool? success = await _channel.invokeMethod<bool>('enableKioskMode');
      
      if (success == true) {
        _isKioskMode = true;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool(_kioskModeKey, true);
        Logger.hardware('Kiosk mode enabled successfully');
        return true;
      }

      Logger.warning('Failed to enable kiosk mode');
      return false;
    } catch (e) {
      Logger.error('Error enabling kiosk mode: $e');
      return false;
    }
  }

  static Future<bool> disableKioskMode() async {
    try {
      if (!_isKioskMode) {
        Logger.hardware('Kiosk mode already disabled');
        return true;
      }

      // Disable kiosk mode through native code
      bool? success = await _channel.invokeMethod<bool>('disableKioskMode');
      
      if (success == true) {
        _isKioskMode = false;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool(_kioskModeKey, false);
        Logger.hardware('Kiosk mode disabled successfully');
        return true;
      }

      Logger.warning('Failed to disable kiosk mode');
      return false;
    } catch (e) {
      Logger.error('Error disabling kiosk mode: $e');
      return false;
    }
  }

  static Future<bool> _hasDeviceAdminPermission() async {
    try {
      bool? hasPermission = await _channel.invokeMethod<bool>('hasDeviceAdminPermission');
      return hasPermission ?? false;
    } catch (e) {
      Logger.error('Error checking device admin permission: $e');
      return false;
    }
  }

  static Future<bool> startLockTask() async {
    try {
      bool? success = await _channel.invokeMethod<bool>('startLockTask');
      Logger.hardware('Lock task started: $success');
      return success ?? false;
    } catch (e) {
      Logger.error('Error starting lock task: $e');
      return false;
    }
  }

  static Future<bool> stopLockTask() async {
    try {
      bool? success = await _channel.invokeMethod<bool>('stopLockTask');
      Logger.hardware('Lock task stopped: $success');
      return success ?? false;
    } catch (e) {
      Logger.error('Error stopping lock task: $e');
      return false;
    }
  }

  static Future<void> setAppAsHomeApp() async {
    try {
      await _channel.invokeMethod('setAppAsHomeApp');
      Logger.hardware('Set app as home app');
    } catch (e) {
      Logger.error('Error setting app as home app: $e');
    }
  }

  static Future<void> disableStatusBar() async {
    try {
      await _channel.invokeMethod('disableStatusBar');
      Logger.hardware('Status bar disabled');
    } catch (e) {
      Logger.error('Error disabling status bar: $e');
    }
  }

  static Future<void> enableStatusBar() async {
    try {
      await _channel.invokeMethod('enableStatusBar');
      Logger.hardware('Status bar enabled');
    } catch (e) {
      Logger.error('Error enabling status bar: $e');
    }
  }

  static Future<void> preventRecentApps() async {
    try {
      await _channel.invokeMethod('preventRecentApps');
      Logger.hardware('Recent apps prevention enabled');
    } catch (e) {
      Logger.error('Error preventing recent apps: $e');
    }
  }

  static Future<void> allowRecentApps() async {
    try {
      await _channel.invokeMethod('allowRecentApps');
      Logger.hardware('Recent apps prevention disabled');
    } catch (e) {
      Logger.error('Error allowing recent apps: $e');
    }
  }

  static Future<Map<String, dynamic>> getKioskModeStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      bool hasDeviceAdmin = await _hasDeviceAdminPermission();
      bool hasSystemAlert = await Permission.systemAlertWindow.isGranted;
      
      return {
        'isKioskModeEnabled': _isKioskMode,
        'hasDeviceAdminPermission': hasDeviceAdmin,
        'hasSystemAlertPermission': hasSystemAlert,
        'canEnableKioskMode': hasDeviceAdmin && hasSystemAlert,
        'lastUpdated': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      Logger.error('Error getting kiosk mode status: $e');
      return {
        'isKioskModeEnabled': false,
        'hasDeviceAdminPermission': false,
        'hasSystemAlertPermission': false,
        'canEnableKioskMode': false,
        'error': e.toString(),
      };
    }
  }

  static Future<void> enableFullKioskMode() async {
    try {
      Logger.hardware('Enabling full kiosk mode...');
      
      // Step 1: Enable kiosk mode
      await enableKioskMode();
      
      // Step 2: Start lock task
      await startLockTask();
      
      // Step 3: Disable status bar
      await disableStatusBar();
      
      // Step 4: Prevent recent apps
      await preventRecentApps();
      
      // Step 5: Set app as home app (optional)
      await setAppAsHomeApp();
      
      Logger.hardware('Full kiosk mode enabled successfully');
    } catch (e) {
      Logger.error('Error enabling full kiosk mode: $e');
    }
  }

  static Future<void> disableFullKioskMode() async {
    try {
      Logger.hardware('Disabling full kiosk mode...');
      
      // Step 1: Allow recent apps
      await allowRecentApps();
      
      // Step 2: Enable status bar
      await enableStatusBar();
      
      // Step 3: Stop lock task
      await stopLockTask();
      
      // Step 4: Disable kiosk mode
      await disableKioskMode();
      
      Logger.hardware('Full kiosk mode disabled successfully');
    } catch (e) {
      Logger.error('Error disabling full kiosk mode: $e');
    }
  }

  static bool get isKioskModeActive => _isKioskMode;

  // Method to handle emergency exit (for development/testing)
  static Future<void> emergencyExit() async {
    try {
      Logger.hardware('Emergency exit triggered');
      await disableFullKioskMode();
    } catch (e) {
      Logger.error('Error during emergency exit: $e');
    }
  }

  // Listen for kiosk mode changes from native side
  static void setupKioskModeListener() {
    _channel.setMethodCallHandler((call) async {
      switch (call.method) {
        case 'onKioskModeChanged':
          bool isEnabled = call.arguments['isEnabled'] ?? false;
          _isKioskMode = isEnabled;
          
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool(_kioskModeKey, isEnabled);
          
          Logger.hardware('Kiosk mode changed to: $isEnabled');
          break;
          
        case 'onKioskModeExitRequested':
          // Handle exit request (could show confirmation dialog)
          Logger.hardware('Kiosk mode exit requested');
          break;
      }
    });
  }
}
