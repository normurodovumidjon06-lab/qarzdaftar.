import 'dart:developer' as developer;

class Logger {
  static const String _tag = 'QarzDaftari';

  static void debug(String message, [Object? error, StackTrace? stackTrace]) {
    if (const bool.fromEnvironment('dart.vm.product') == false) {
      developer.log(
        '🔍 DEBUG: $message',
        name: _tag,
        error: error,
        stackTrace: stackTrace,
      );
    }
  }

  static void info(String message, [Object? error, StackTrace? stackTrace]) {
    developer.log(
      'ℹ️ INFO: $message',
      name: _tag,
      error: error,
      stackTrace: stackTrace,
    );
  }

  static void warning(String message, [Object? error, StackTrace? stackTrace]) {
    developer.log(
      '⚠️ WARNING: $message',
      name: _tag,
      error: error,
      stackTrace: stackTrace,
    );
  }

  static void error(String message, [Object? error, StackTrace? stackTrace]) {
    developer.log(
      '❌ ERROR: $message',
      name: _tag,
      error: error,
      stackTrace: stackTrace,
    );
  }

  static void critical(String message, [Object? error, StackTrace? stackTrace]) {
    developer.log(
      '🚨 CRITICAL: $message',
      name: _tag,
      error: error,
      stackTrace: stackTrace,
    );
  }

  static void network(String method, String url, [int? statusCode, dynamic response]) {
    developer.log(
      '🌐 NETWORK: $method $url${statusCode != null ? ' -> $statusCode' : ''}',
      name: _tag,
    );
    if (response != null) {
      developer.log(
        '📦 RESPONSE: $response',
        name: _tag,
      );
    }
  }

  static void auth(String message) {
    developer.log(
      '🔐 AUTH: $message',
      name: _tag,
    );
  }

  static void database(String operation, String table, [String? details]) {
    developer.log(
      '💾 DATABASE: $operation $table${details != null ? ' - $details' : ''}',
      name: _tag,
    );
  }

  static void fcm(String event, [String? details]) {
    developer.log(
      '📱 FCM: $event${details != null ? ' - $details' : ''}',
      name: _tag,
    );
  }

  static void hardware(String component, String action) {
    developer.log(
      '🔧 HARDWARE: $component - $action',
      name: _tag,
    );
  }

  static void background(String task, [String? details]) {
    developer.log(
      '🔄 BACKGROUND: $task${details != null ? ' - $details' : ''}',
      name: _tag,
    );
  }
}
