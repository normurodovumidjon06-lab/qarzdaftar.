class AppConstants {
  // App Information
  static const String appName = 'Qarz Daftari';
  static const String appVersion = '1.0.0';
  
  // API Configuration
  static const String apiBaseUrl = 'https://your-backend-url.com/api';
  static const Duration apiTimeout = Duration(seconds: 30);
  static const int apiRetryAttempts = 3;
  
  // Storage Keys
  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userIdKey = 'user_id';
  static const String userRoleKey = 'user_role';
  static const String isLoggedInKey = 'is_logged_in';
  static const String fcmTokenKey = 'fcm_token';
  static const String lastSyncKey = 'last_sync';
  static const String kioskModeKey = 'kiosk_mode_enabled';
  
  // User Roles
  static const String superAdminRole = 'SUPER_ADMIN';
  static const String clientRole = 'CLIENT';
  
  // Debt Status
  static const String debtStatusActive = 'ACTIVE';
  static const String debtStatusPaid = 'PAID';
  static const String debtStatusDefaulted = 'DEFAULTED';
  
  // Notification Types
  static const String notificationTypeHardwareShock = 'HARDWARE_SHOCK';
  static const String notificationTypeDebtReminder = 'DEBT_REMINDER';
  static const String notificationTypePaymentConfirmation = 'PAYMENT_CONFIRMATION';
  
  // Background Service Configuration
  static const String backgroundServiceChannelId = 'qarz_daftari_background_service';
  static const String backgroundServiceChannelName = 'Qarz Daftari Background Service';
  static const String backgroundServiceChannelDescription = 'Monitors debts and sends notifications';
  static const int backgroundServiceNotificationId = 888;
  
  // WorkManager Tasks
  static const String debtCheckTask = 'debtCheckTask';
  static const String syncTask = 'syncTask';
  
  // Vibration Patterns
  static const List<int> defaultVibrationPattern = [1000, 500, 1000, 500, 2000];
  static const List<int> urgentVibrationPattern = [2000, 200, 2000, 200, 2000];
  static const List<int> notificationVibrationPattern = [500, 200, 500];
  
  // TTS Configuration
  static const String ttsLanguage = 'uz-UZ';
  static const double ttsSpeechRate = 0.8;
  static const double ttsVolume = 1.0;
  static const double ttsPitch = 1.0;
  
  // UI Constants
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
  static const double borderRadius = 12.0;
  static const double buttonHeight = 48.0;
  
  // Colors
  static const int primaryRedValue = 0xFFE53935;
  static const int primaryDarkRedValue = 0xFFC62828;
  static const int successGreenValue = 0xFF4CAF50;
  static const int warningOrangeValue = 0xFFFF9800;
  static const int errorRedValue = 0xFFF44336;
  
  // Animation Durations
  static const Duration shortAnimationDuration = Duration(milliseconds: 200);
  static const Duration mediumAnimationDuration = Duration(milliseconds: 300);
  static const Duration longAnimationDuration = Duration(milliseconds: 500);
  
  // Pagination
  static const int defaultPageSize = 20;
  static const int maxPageSize = 100;
  
  // Cache Configuration
  static const Duration cacheExpiration = Duration(hours: 1);
  static const int maxCacheSize = 100; // MB
  
  // Security
  static const int maxLoginAttempts = 5;
  static const Duration lockoutDuration = Duration(minutes: 15);
  static const Duration sessionTimeout = Duration(hours: 24);
  
  // File Paths
  static const String databaseName = 'qarz_daftari.db';
  static const String databasePath = 'databases/qarz_daftari.db';
  
  // Validation
  static const int minPasswordLength = 6;
  static const int maxPasswordLength = 100;
  static const int maxFullNameLength = 100;
  static const int maxMahallaLength = 100;
  static const String phoneRegex = r'^\+998\d{9}$';
  
  // Hardware Shock Configuration
  static const int maxHardwareShockRetries = 3;
  static const Duration hardwareShockTimeout = Duration(seconds: 30);
  static const Duration vibrationTimeout = Duration(seconds: 10);
  static const Duration ttsTimeout = Duration(seconds: 15);
  
  // Kiosk Mode Configuration
  static const Duration kioskModeCheckInterval = Duration(seconds: 30);
  static const String kioskModePassword = 'admin123'; // Change in production
  
  // Development
  static const bool enableDebugLogs = true;
  static const bool enableMockData = false;
  
  // Error Messages
  static const String networkErrorMessage = 'Internet aloqasi mavjud emas';
  static const String serverErrorMessage = 'Server xatosi. Iltimos, keyinroq urinib ko\'ring';
  static const String unauthorizedErrorMessage = 'Avtorizatsiya xatosi';
  static const String forbiddenErrorMessage = 'Ruxsat yo\'q';
  static const String notFoundErrorMessage = 'Ma\'lumot topilmadi';
  static const String validationErrorMessage = 'Ma\'lumotlar noto\'g\'ri kiritilgan';
  
  // Success Messages
  static const String loginSuccessMessage = 'Tizimga muvaffaqiyatli kirdingiz';
  static const String logoutSuccessMessage = 'Tizimdan chiqdingiz';
  static const String saveSuccessMessage = 'Ma\'lumotlar saqlandi';
  static const String deleteSuccessMessage = 'Ma\'lumotlar o\'chirildi';
  static const String updateSuccessMessage = 'Ma\'lumotlar yangilandi';
  
  // Hardware Shock Messages
  static const String defaultTTSMessage = 'Hurmatli mijoz, iltimos qarzlaringizni to\'lab qo\'ying.';
  static const String urgentTTSMessage = 'Ehtiyot bering! Qarzingiz muddati yaqinlashmoqda!';
  static const String paymentConfirmationTTSMessage = 'To\'lovingiz muvaffaqiyatli amalga oshirildi. Rahmat!';
  
  // Notification Channels
  static const String defaultNotificationChannelId = 'default_channel';
  static const String defaultNotificationChannelName = 'Default Notifications';
  static const String urgentNotificationChannelId = 'urgent_channel';
  static const String urgentNotificationChannelName = 'Urgent Notifications';
  static const String serviceNotificationChannelId = 'service_channel';
  static const String serviceNotificationChannelName = 'Service Notifications';
}

class ApiEndpoints {
  // Auth
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String refreshToken = '/auth/refresh';
  static const String logout = '/auth/logout';
  static const String profile = '/auth/profile';
  
  // Users
  static const String users = '/users';
  static const String userStats = '/users/stats';
  
  // Debts
  static const String debts = '/debts';
  static const String debtStats = '/debts/stats';
  static const String overdueDebts = '/debts/overdue';
  static const String debtsDueIn7Days = '/debts/due-in-7-days';
  static const String myDebts = '/debts/my-debts';
  
  // Collection
  static const String collection = '/collection';
  static const String triggerCollection = '/collection/trigger';
  static const String collectionStats = '/collection/stats';
  
  // Admin
  static const String adminDashboard = '/admin/dashboard';
  static const String adminAuditLogs = '/admin/audit-logs';
  static const String adminPanicButton = '/admin/panic-button';
  static const String adminHealth = '/admin/health';
}

class DatabaseTables {
  static const String users = 'users';
  static const String debts = 'debts';
  static const String auditLogs = 'audit_logs';
  static const String notifications = 'notifications';
  static const String syncQueue = 'sync_queue';
}

class SharedPreferencesKeys {
  static const String firstLaunch = 'first_launch';
  static const String onboardingCompleted = 'onboarding_completed';
  static const String themeMode = 'theme_mode';
  static const String language = 'language';
  static const String notificationsEnabled = 'notifications_enabled';
  static const String vibrationEnabled = 'vibration_enabled';
  static const String ttsEnabled = 'tts_enabled';
  static const String kioskModeEnabled = 'kiosk_mode_enabled';
  static const String lastDebtCheck = 'last_debt_check';
  static const String lastSyncAttempt = 'last_sync_attempt';
  static const String loginAttempts = 'login_attempts';
  static const String lastLoginAttempt = 'last_login_attempt';
  static const String deviceRegistered = 'device_registered';
}
