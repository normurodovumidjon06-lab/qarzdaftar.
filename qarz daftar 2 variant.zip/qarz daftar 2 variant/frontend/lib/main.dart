import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:workmanager/workmanager.dart';
import 'package:vibration/vibration.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import 'src/core/utils/logger.dart';
import 'src/core/services/background_service.dart';
import 'src/core/services/fcm_service.dart';
import 'src/core/services/hardware_shock_service.dart';
import 'src/core/services/kiosk_mode_service.dart';
import 'src/presentation/router/app_router.dart';
import 'src/presentation/providers/theme_provider.dart';
import 'src/presentation/providers/auth_provider.dart';
import 'src/data/datasources/local/storage_service.dart';
import 'firebase_options.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    Logger.info('WorkManager task executed: $task');
    
    switch (task) {
      case 'debtCheckTask':
        // Check for due debts locally
        await BackgroundService.checkDueDebts();
        break;
      case 'syncTask':
        // Sync data with backend
        await BackgroundService.syncWithBackend();
        break;
    }
    
    return Future.value(true);
  });
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  Logger.info('Handling a background message: ${message.messageId}');
  
  // Handle hardware shock in background
  if (message.data['type'] == 'HARDWARE_SHOCK') {
    await HardwareShockService.executeHardwareShock(
      clientName: message.data['clientName'] ?? 'Mijoz',
      amount: double.tryParse(message.data['amount'] ?? '0') ?? 0,
      vibrationPattern: message.data['vibrationPattern'],
      ttsMessage: message.data['ttsMessage'],
    );
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  
  // Set up background message handler
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  
  // Initialize WorkManager
  await Workmanager().initialize(
    callbackDispatcher,
    isInDebugMode: kDebugMode,
  );
  
  // Initialize secure storage
  await StorageService.init();
  
  // Initialize services
  await BackgroundService.initialize();
  await FCMService.initialize();
  await HardwareShockService.initialize();
  await KioskModeService.initialize();
  
  // Request permissions
  await _requestPermissions();
  
  // Start background service
  await BackgroundService.start();
  
  // Schedule periodic tasks
  await _schedulePeriodicTasks();
  
  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Set system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  
  Logger.info('Application initialized successfully');
  
  runApp(
    const ProviderScope(
      child: QarzDaftariApp(),
    ),
  );
}

Future<void> _requestPermissions() async {
  try {
    // Request notification permission
    await FCMService.requestNotificationPermission();
    
    // Request vibration permission
    await Vibration.hasVibrator();
    
    // Request overlay permission for kiosk mode
    await Permission.systemAlertWindow.request();
    
    // Request admin permissions
    await KioskModeService.requestDeviceAdminPermission();
    
    // Request storage permissions
    await Permission.storage.request();
    
    Logger.info('All permissions requested');
  } catch (e) {
    Logger.error('Error requesting permissions: $e');
  }
}

Future<void> _schedulePeriodicTasks() async {
  try {
    // Schedule debt check every 30 minutes
    await Workmanager().registerPeriodicTask(
      'debtCheckTask',
      'debtCheckTask',
      frequency: const Duration(minutes: 30),
      constraints: Constraints(
        networkType: NetworkType.connected,
        requiresCharging: false,
        requiresDeviceIdle: false,
      ),
    );
    
    // Schedule sync every 4 hours
    await Workmanager().registerPeriodicTask(
      'syncTask',
      'syncTask',
      frequency: const Duration(hours: 4),
      constraints: Constraints(
        networkType: NetworkType.connected,
        requiresCharging: false,
        requiresDeviceIdle: true,
      ),
    );
    
    Logger.info('Periodic tasks scheduled');
  } catch (e) {
    Logger.error('Error scheduling periodic tasks: $e');
  }
}

class QarzDaftariApp extends ConsumerWidget {
  const QarzDaftariApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeProvider);
    final authState = ref.watch(authProvider);
    
    return MaterialApp.router(
      title: 'Qarz Daftari',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE53935), // Red for debt urgency
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.black,
          systemOverlayStyle: SystemUiOverlayStyle.dark,
        ),
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE53935),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          systemOverlayStyle: SystemUiOverlayStyle.light,
        ),
        cardTheme: CardTheme(
          elevation: 4,
          color: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      themeMode: themeMode,
      routerConfig: AppRouter.router,
      builder: (context, child) {
        return MediaQuery(
          // Ensure text scale factor doesn't exceed reasonable limits
          data: MediaQuery.of(context).copyWith(
            textScaleFactor: MediaQuery.of(context).textScaleFactor.clamp(0.8, 1.2),
          ),
          child: child!,
        );
      },
    );
  }
}

// Connectivity listener to handle network changes
class ConnectivityListener extends ConsumerStatefulWidget {
  const ConnectivityListener({super.key});

  @override
  ConsumerState<ConnectivityListener> createState() => _ConnectivityListenerState();
}

class _ConnectivityListenerState extends ConsumerState<ConnectivityListener> {
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;

  @override
  void initState() {
    super.initState();
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((result) {
      if (result == ConnectivityResult.none) {
        // Show offline mode
        ref.read(authProvider.notifier).setOfflineMode(true);
      } else {
        // Try to sync when back online
        ref.read(authProvider.notifier).setOfflineMode(false);
        BackgroundService.syncWithBackend();
      }
    });
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}
