package com.example.qarz_daftari

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.annotation.NonNull
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val KIOSK_CHANNEL = "qarz_daftari/kiosk"
    private val VOLUME_CHANNEL = "qarz_daftari/volume"
    private var isKioskMode = false

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        // Setup kiosk mode channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, KIOSK_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "enableKioskMode" -> {
                    enableKioskMode()
                    result.success(true)
                }
                "disableKioskMode" -> {
                    disableKioskMode()
                    result.success(true)
                }
                "isKioskModeActive" -> {
                    result.success(isKioskMode)
                }
                "requestDeviceAdmin" -> {
                    val success = requestDeviceAdminPermission()
                    result.success(success)
                }
                "hasDeviceAdminPermission" -> {
                    val hasPermission = hasDeviceAdminPermission()
                    result.success(hasPermission)
                }
                "startLockTask" -> {
                    startLockTaskMode()
                    result.success(true)
                }
                "stopLockTask" -> {
                    stopLockTaskMode()
                    result.success(true)
                }
                "setAppAsHomeApp" -> {
                    setAppAsHomeApp()
                    result.success(true)
                }
                "disableStatusBar" -> {
                    disableStatusBar()
                    result.success(true)
                }
                "enableStatusBar" -> {
                    enableStatusBar()
                    result.success(true)
                }
                "preventRecentApps" -> {
                    preventRecentApps()
                    result.success(true)
                }
                "allowRecentApps" -> {
                    allowRecentApps()
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        // Setup volume control channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, VOLUME_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "setMaxVolume" -> {
                    setMaxVolume()
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun enableKioskMode() {
        try {
            // Hide navigation bar and status bar
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )

            // Set screen to always on
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            // Disable system bars
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }

            isKioskMode = true

            // Start lock task mode if we have device admin permission
            if (hasDeviceAdminPermission()) {
                startLockTaskMode()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun disableKioskMode() {
        try {
            // Show navigation bar and status bar
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

            // Remove keep screen on flag
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            // Stop lock task mode
            stopLockTaskMode()

            isKioskMode = false

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun requestDeviceAdminPermission(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_ADD_DEVICE_ADMIN)
            intent.putExtra(Settings.EXTRA_DEVICE_ADMIN, DeviceAdminReceiver.getComponentName(this))
            intent.putExtra(Settings.EXTRA_ADD_EXPLANATION, "Qarz Daftari needs device admin permissions for kiosk mode")
            startActivity(intent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun hasDeviceAdminPermission(): Boolean {
        return try {
            val devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            val componentName = DeviceAdminReceiver.getComponentName(this)
            devicePolicyManager.isAdminActive(componentName)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun startLockTaskMode() {
        try {
            if (hasDeviceAdminPermission()) {
                startLockTask()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopLockTaskMode() {
        try {
            stopLockTask()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setAppAsHomeApp() {
        try {
            // This would require additional configuration and permissions
            // For now, we'll just log the attempt
            android.util.Log.d("MainActivity", "Set as home app requested")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun disableStatusBar() {
        try {
            // Hide status bar
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
                    View.SYSTEM_UI_FLAG_FULLSCREEN
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun enableStatusBar() {
        try {
            // Show status bar
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility and
                    View.SYSTEM_UI_FLAG_FULLSCREEN.inv()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun preventRecentApps() {
        try {
            // Exclude from recent apps
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val taskDescription = android.app.ActivityManager.TaskDescription(
                    "Qarz Daftari",
                    R.mipmap.ic_launcher,
                    ContextCompat.getColor(this, android.R.color.darker_gray)
                )
                setTaskDescription(taskDescription)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun allowRecentApps() {
        try {
            // Reset task description to allow in recent apps
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val taskDescription = android.app.ActivityManager.TaskDescription(
                    "Qarz Daftari",
                    R.mipmap.ic_launcher
                )
                setTaskDescription(taskDescription)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setMaxVolume() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            
            // Set maximum volume for music stream
            val maxVolume = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, maxVolume, 0)
            
            // Set maximum volume for ringtone stream
            val maxRingVolume = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_RING)
            audioManager.setStreamVolume(android.media.AudioManager.STREAM_RING, maxRingVolume, 0)
            
            // Set maximum volume for alarm stream
            val maxAlarmVolume = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(android.media.AudioManager.STREAM_ALARM, maxAlarmVolume, 0)
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBackPressed() {
        // Prevent back button in kiosk mode
        if (isKioskMode) {
            return
        }
        super.onBackPressed()
    }

    override fun onUserLeaveHint() {
        // Handle home button press in kiosk mode
        if (isKioskMode) {
            // Bring app back to front
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }
        super.onUserLeaveHint()
    }

    override fun onResume() {
        super.onResume()
        // Restore kiosk mode if needed
        if (isKioskMode) {
            enableKioskMode()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Check if kiosk mode was previously enabled
        val prefs = getSharedPreferences("qarz_daftari_prefs", Context.MODE_PRIVATE)
        isKioskMode = prefs.getBoolean("kiosk_mode_enabled", false)
        
        if (isKioskMode) {
            enableKioskMode()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        
        // Save kiosk mode state
        val prefs = getSharedPreferences("qarz_daftari_prefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putBoolean("kiosk_mode_enabled", isKioskMode)
        editor.apply()
    }
}
