package com.example.qarz_daftari

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

class BackgroundService : Service() {
    
    private val TAG = "BackgroundService"
    private val NOTIFICATION_CHANNEL_ID = "qarz_daftari_background_service"
    private val NOTIFICATION_ID = 888
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Background service created")
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Background service started")
        
        when (intent?.action) {
            "START_SERVICE" -> {
                startForegroundService()
            }
            "STOP_SERVICE" -> {
                stopForegroundService()
            }
            else -> {
                startForegroundService()
            }
        }
        
        return START_STICKY // Service will be restarted if killed
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Background service destroyed")
    }
    
    private fun startForegroundService() {
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)
        Log.d(TAG, "Foreground service started")
    }
    
    private fun stopForegroundService() {
        stopForeground(true)
        stopSelf()
        Log.d(TAG, "Foreground service stopped")
    }
    
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Qarz Daftari")
            .setContentText("Background service is running")
            .setSmallIcon(R.mipmap.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Qarz Daftari Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors debts and sends notifications"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    companion object {
        fun startService(context: Context) {
            val intent = Intent(context, BackgroundService::class.java).apply {
                action = "START_SERVICE"
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        fun stopService(context: Context) {
            val intent = Intent(context, BackgroundService::class.java).apply {
                action = "STOP_SERVICE"
            }
            context.startService(intent)
        }
    }
}
