package com.example.qarz_daftari

import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FCMService : FirebaseMessagingService() {
    
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d("FCMService", "Message received: ${remoteMessage.messageId}")
        
        // Handle different types of messages
        when (remoteMessage.data["type"]) {
            "HARDWARE_SHOCK" -> {
                handleHardwareShock(remoteMessage)
            }
            "DEBT_REMINDER" -> {
                handleDebtReminder(remoteMessage)
            }
            "PAYMENT_CONFIRMATION" -> {
                handlePaymentConfirmation(remoteMessage)
            }
            else -> {
                handleDefaultMessage(remoteMessage)
            }
        }
    }
    
    override fun onNewToken(token: String) {
        Log.d("FCMService", "FCM Token refreshed: $token")
        // Send token to Flutter app
        // This will be handled by the Flutter FCM plugin
    }
    
    private fun handleHardwareShock(remoteMessage: RemoteMessage) {
        Log.d("FCMService", "Handling hardware shock message")
        
        val clientName = remoteMessage.data["clientName"] ?: "Mijoz"
        val amount = remoteMessage.data["amount"] ?: "0"
        val vibrationPattern = remoteMessage.data["vibrationPattern"]
        val ttsMessage = remoteMessage.data["ttsMessage"]
        
        // Show high-priority notification
        showNotification(
            title = "Qarz Daftari - Muhim Ogohlantirish!",
            body = "$clientName, sizning $amount so\'m qarzingiz muddati yaqinlashmoqda!",
            priority = NotificationCompat.PRIORITY_HIGH,
            channelId = "urgent_channel"
        )
        
        // Send data to Flutter app
        // The Flutter FCM plugin will handle this automatically
    }
    
    private fun handleDebtReminder(remoteMessage: RemoteMessage) {
        Log.d("FCMService", "Handling debt reminder message")
        
        val clientName = remoteMessage.data["clientName"] ?: "Mijoz"
        val amount = remoteMessage.data["amount"] ?: "0"
        val dueDate = remoteMessage.data["dueDate"] ?: ""
        
        showNotification(
            title = "Qarz Daftari - Eslatma",
            body = "$clientName, sizning $amount so\'m qarzingiz $dueDate sanasigacha to\'lanishi kerak.",
            priority = NotificationCompat.PRIORITY_DEFAULT,
            channelId = "default_channel"
        )
    }
    
    private fun handlePaymentConfirmation(remoteMessage: RemoteMessage) {
        Log.d("FCMService", "Handling payment confirmation message")
        
        val clientName = remoteMessage.data["clientName"] ?: "Mijoz"
        val amount = remoteMessage.data["amount"] ?: "0"
        
        showNotification(
            title = "Qarz Daftari - To\'lov Tasdiqlandi",
            body = "$clientName, $amount so\'m qarzingiz muvaffaqiyatli to\'landi!",
            priority = NotificationCompat.PRIORITY_DEFAULT,
            channelId = "default_channel"
        )
    }
    
    private fun handleDefaultMessage(remoteMessage: RemoteMessage) {
        Log.d("FCMService", "Handling default message")
        
        val title = remoteMessage.notification?.title ?: "Qarz Daftari"
        val body = remoteMessage.notification?.body ?: "Yangi xabar"
        
        showNotification(
            title = title,
            body = body,
            priority = NotificationCompat.PRIORITY_DEFAULT,
            channelId = "default_channel"
        )
    }
    
    private fun showNotification(
        title: String,
        body: String,
        priority: Int,
        channelId: String
    ) {
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(priority)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
        
        val notificationManager = NotificationManagerCompat.from(this)
        
        // Create notification channels for Android O and above
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                channelId,
                when (channelId) {
                    "urgent_channel" -> "Urgent Notifications"
                    "default_channel" -> "Default Notifications"
                    else -> "General Notifications"
                },
                android.app.NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }
        
        try {
            notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
        } catch (e: Exception) {
            Log.e("FCMService", "Error showing notification: ${e.message}")
        }
    }
}
